<?php
/*
Plugin Name: Wholesale Customer Plugin
Description: Features created for Wholesale Customer site
Version: 2.8.6
Author: Gabriel Caroprese
Author URI: https://mailto:gabriel.caroprese@gmail.com
Requires at least: 5.3
Requires PHP: 7.3
*/ 

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$ik_hatton_core_Dir = dirname( __FILE__ );
$ik_hatton_corePublicDir = plugin_dir_url(__FILE__ );
define( 'IK_HATTON_CORE_DIR', $ik_hatton_core_Dir);
define( 'IK_HATTON_CORE_PUBLIC', $ik_hatton_corePublicDir);

require_once($ik_hatton_core_Dir . '/include/init.php');
register_activation_hook( __FILE__, 'ik_hatton_core_create_tables_folders' );

//add credits
add_action( 'wp_head', 'ik_hn_head_credits');
function ik_hn_head_credits() {
	echo '<!-- Powered | Website Development by Inforket LLC | Gabriel Caroprese - https://inforket.com -->';
}

?>