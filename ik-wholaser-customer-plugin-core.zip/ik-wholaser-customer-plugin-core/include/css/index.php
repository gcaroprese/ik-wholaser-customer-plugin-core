<?pho

/*
Silence is great 
*/

?>