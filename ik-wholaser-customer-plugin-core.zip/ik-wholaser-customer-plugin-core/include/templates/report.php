<?php
/*

Wholesale Customer Core Wholesale Customer Reports Template
Created: 20/11/2022
Update: 07/10/2023
Author: Gabriel Caroprese

*/

if ( ! defined( 'ABSPATH' ) ) {
    return;
}

// Amount of customers I'm gonna show per page
$customersListed = 1000;

if ($_SERVER['REQUEST_METHOD'] == 'POST' ){
        
        $keyword = sanitize_text_field($_POST["seach_customer"]);
        $searchPlaceholder = $keyword;
		echo '<script>
					window.location.replace("'.$ik_customerrep_adminURL.'&search='.$keyword.'");
				</script>';
        
    } else {
        
        if (isset($_GET['search'])){
            $keywordCustomer = sanitize_text_field($_GET['search']);
            $searchValue = 'value="'.$keywordCustomer.'"';

        } else{
            $show_average = 1;
            $searchValue = '';
        }

    // I get the value from the pagination number from URL if that exists
    if (isset($_GET["list"])){
        // I check if value is integer to avoid errors
        if (strval($_GET["list"]) == strval(intval($_GET["list"])) && $_GET["list"] > 0){
            $paged = intval($_GET["list"]);
        } else {
            $paged = 1;
        }
    } else {
         $paged = 1;
    }
 
    
    // I create this variable to check the page number
    $offset = ($paged - 1) * $customersListed;
    
    $userRole =  (get_option('HN_WHOLESALE_ROLE')) ? sanitize_text_field(get_option('HN_WHOLESALE_ROLE')) : 'default_wholesaler';

    
    //If there's a search this is the only thing it will be shown
    if (isset($keywordCustomer)){
                
        $args_customer = array(
            'role__in' => $userRole,
            'offset'=> $offset,
            'number'=>$customersListed,
            'orderby' => 'name',
            'order' => 'DESC',
                'update_post_meta_cache' => false,
            'meta_query' => array(
                'relation' => 'OR',
                  array(
                    'key' => 'first_name',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
                array(
                    'key' => 'last_name',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
                array(
                    'key' => 'email',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
                array(
                    'key' => 'nickname',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
            )
        );  
        
        $args_customerTotal  = array(
            'role__in' => $userRole,
            'orderby' => 'name',
            'order' => 'DESC',
            'meta_query' => array(
                'relation' => 'OR',
                  array(
                    'key' => 'first_name',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
                array(
                    'key' => 'last_name',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
                array(
                    'key' => 'email',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),                
                  array(
                    'key' => 'nickname',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
                   array(
                    'key' => 'display_name',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),    
                    array(
                    'key' => 'user_login',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
                  array(
                    'key' => 'billing_company',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
                    array(
                    'key' => 'billing_phone',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
                  array(
                    'key' => 'billing_city',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
                   array(
                    'key' => 'address_15_16',
                    'value' => $keywordCustomer,
                    'compare' => 'LIKE'
                  ),
            )
        );  

        
    } else {
         $args_customer = array(
            'role__in' => $userRole,
            'offset'=> $offset,
            'number'=>$customersListed,
            'orderby' => 'name',
            'order' => 'DESC',
            'update_post_meta_cache' => false,
        );  
        
        $args_customerTotal = array(
            'role__in' => $userRole,
            'offset'=> $offset,
            'number'=>$customersListed,
            'orderby' => 'name',
            'order' => 'DESC',
            'update_post_meta_cache' => false,
        );  
    }
        
    $customersListQuery = get_users( $args_customer );  
    $customersTotalQuery = get_users( $args_customerTotal );  
    $totalCustomersFound = count($customersTotalQuery);
    
    //The total of customers to show to paginate is equal to the search
    $queryTotal = $totalCustomersFound;
      

    //I create the query
    // I count the amount of customers
        
        $total_customers = ik_customerrep_getcount_userrole($queryTotal);

    //I get the total of pages to list based on $customersListed
    if (is_int(($total_customers / $customersListed))){
        $total_pages = intval($total_customers / $customersListed);
    } else {
        $total_pages = intval($total_customers / $customersListed) + 1;
    }

    if ($total_customers > 0){
        // User Search
        echo '<div id="ik_customers_list">
        <form action="" method="post" class="ik_search_customers">
                <input type="text" required name="seach_customer" placeholder="search customer" '.$searchValue.'">
                <input type="submit" class="button button-primary" value="search">
        </form>';
        
        //I create the export to CSV name 
        if (isset($_GET['assinatura']) && isset($customersListQuery[0]->ID)) {
            $exportName = "dados-do-customers-".ik_customerrep_showStudentRoles($customersListQuery[0]->ID, NULL, $ik_customerrep_adminURL).".csv";
        }else if (isset($_GET['search'])){
            $exportName = "report-customers-".$keywordCustomer.date('m-d-Y').".csv";
        } else{
            $exportName = "report-customers-".date('m-d-Y').".csv";
        }
        echo '<button id="ik_exportar_csv" class="button button-primary" onclick="exportTableToCSV(\''.$exportName.'\')">Export to CSV</button>';

        // Array of WP_User objects.
        echo '
        <style>
        #ik_customers_list{
            padding: 2%;
        }
        #ik_customers_list th, #ik_customers_list td{
            border: 1px solid;
            padding: 2px 3px;
            text-align: center;
            text-transform: capitalize;
            min-width: 70px;
        }
        #ik_customers_list th {
            cursor: pointer;
        }
        .customers-lists{
            margin: 20px 0;
        }
        .ik_search_customers {
            max-width: 500px;
            display: initial;
        }
        .ik_search_customers input[type=submit]{
            position: relative;
            left: -5px;
        }
        #ik_exportar_csv {
            float: right;
        }
        .phone_customer{
			min-width: 125px! important;
		}
        </style>
        <table class="customers-lists">
          <thead>
                  <tr>
                    <th data-column="0" class="ik_customerrep_export">Name</th> 
                    <th data-column="1" class="ik_customerrep_export">Username</th> 
                    <th data-column="2" class="ik_customerrep_export">Company</th> 
                    <th data-column="3" class="ik_customerrep_export">Last Active</th> 
                    <th data-column="4" class="ik_customerrep_export">Date Registerd</th> 
                    <th data-column="5" class="ik_customerrep_export">Email</th> 
                    <th data-column="6" class="ik_customerrep_export">Phone</th> 
                    <th data-column="7" class="ik_customerrep_export">Orders</th> 
                    <th data-column="8" class="ik_customerrep_export">Total Spend</th> 
                    <th data-column="9" class="ik_customerrep_export">City</th> 
                    <th data-column="10" class="ik_customerrep_export">State / Province</th> 
                    <th data-column="11" class="ik_customerrep_export">ZIP</th>
                    <th data-column="12" class="ik_customerrep_export">Tax ID</th>
                  </tr>
            </thead>
            <tbody>';
                  
        foreach ( $customersListQuery as $user ) {
    	
                echo '<tr>';
                echo 	'<td class="ik_customerrep_export">'. $user->user_firstname . ' '.$user->user_lastname.'</td>';
                echo 	'<td class="ik_customerrep_export">'. $user->user_login .'</td>';
    			echo 	'<td class="ik_customerrep_export">'.str_replace(',', '', sanitize_text_field(ik_customerrep_get_customer_data($user->ID, 'company-name'))).'</td>'; 
    			echo 	'<td class="ik_customerrep_export">'. ik_customerrep_get_customer_data($user->ID, 'wc_last_active') .'</td>'; 
    			echo 	'<td class="ik_customerrep_export">'. date("d-m-Y", strtotime($user->user_registered)) .'</td>'; 
    			echo 	'<td class="ik_customerrep_export">'. $user->user_email .'</td>'; 
    			echo 	'<td class="ik_customerrep_export phone_customer">'.ik_customerrep_format_phone(ik_customerrep_get_customer_data($user->ID, 'mobile_number')).'</td>'; 
    			echo 	'<td class="ik_customerrep_export">'.ik_customerrep_customer_total_order($user->ID).'</td>'; 
    			echo 	'<td class="ik_customerrep_export">'.str_replace(',', '', ik_customerrep_user_total_spent($user->ID)).'</td>'; 
    			echo 	'<td class="ik_customerrep_export">'.str_replace(',', '', sanitize_text_field(ik_customerrep_get_customer_data($user->ID, 'address_15_16'))).'</td>';
    			echo 	'<td class="ik_customerrep_export">'.str_replace(',', '', sanitize_text_field(ik_customerrep_get_customer_data($user->ID, 'State-Province'))).'</td>'; 
    			echo 	'<td class="ik_customerrep_export">'.ik_customerrep_get_customer_data($user->ID, 'zip-code').'</td>'; 
    			echo 	'<td class="ik_customerrep_export">'.str_replace(',', '', ik_customerrep_get_customer_data($user->ID, 'wwp_wholesaler_tax_id')).'</td>'; 
                echo '</tr>';
        }
        echo '</tbody></table>';
        
        //If filter is active I show the button to clean filter
        if (isset($filtroActivo)){
            echo '<a class="button button-primary" id="ik_customerrep_filter" href="'.$ik_customerrep_adminURL.'">Clean Filter</a>';
        }
        if (isset($keywordCustomer)){
            echo '<a id="all-customers" class="button button-primary" href="'.$ik_customerrep_adminURL.'">Show All Customers</a>';
        }
        echo '</div>
        <script src="'.IK_HATTON_CORE_PUBLIC.'/include/js/convert-to-csv.js"></script>
        <script>
        jQuery(document).ready(function() {
          jQuery(".customers-lists th[data-column]").click(function() {
            var column = parseInt(jQuery(this).data("column"));
            sortTable(column);
          });
        });

        function sortTable(columnIndex) {
          var table, rows, switching, i, x, y, shouldSwitch, sortOrder;
          table = jQuery(".customers-lists");
          if(table.parent().find(".asc").length > 0){
              sortOrder = "asc";
              table.removeClass("asc");
              table.addClass("desc");
            } else {
              sortOrder = "desc";
              table.removeClass("desc");
              table.addClass("asc");
            }

          switching = true;
          while (switching) {
            switching = false;
            rows = table.find("tbody tr").get();
            for (i = 0; i < (rows.length - 1); i++) {
              shouldSwitch = false;
              x = jQuery(rows[i]).find("td").eq(columnIndex);
              y = jQuery(rows[i + 1]).find("td").eq(columnIndex);
              if (sortOrder === "asc") {
                if (x.text().toLowerCase() > y.text().toLowerCase()) {
                  shouldSwitch = true;
                  break;
                }
              } else if (sortOrder === "desc") {
                if (x.text().toLowerCase() < y.text().toLowerCase()) {
                  shouldSwitch = true;
                  break;
                }
              }
            }
            if (shouldSwitch) {
              jQuery(rows[i]).before(rows[i + 1]);
              switching = true;
            }
          }
        }
        </script>';
    } else {
        echo '<table class="customers-lists">No customers to show.</table>';
    }
    
}
?>