<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - //Menu for Messages on Product Page
Created: 07/10/2023
Last Update: 07/19/2023
Author: Gabriel Caroprese
*/

add_action('admin_menu', 'ik_hn_woo_messages_menu');
function ik_hn_woo_messages_menu(){
    add_submenu_page('woocommerce', 'Messages For Pages', 'Messages For Pages', 'manage_options', 'ik_hn_woo_messages_page_editor', 'ik_hn_woo_messages_page_editor');
}

function ik_hn_woo_messages_page_editor(){
	if ($_SERVER['REQUEST_METHOD'] == 'POST'){
		
		if (isset($_POST['message_after_cart'])){
			$message_after_cart = sanitize_text_field($_POST['message_after_cart']);
			update_option('HN_AFTER_CART_TEXT', $message_after_cart);
		}
		if (isset($_POST['message_after_cart_button'])){
			$message_after_cart_button = sanitize_text_field($_POST['message_after_cart_button']);
			update_option('HN_AFTER_CART_TEXT_BTN', $message_after_cart_button);
		}
		if (isset($_POST['message_after_cart_link'])){
			$message_after_cart_link = esc_url_raw($_POST['message_after_cart_link']);
			update_option('HN_AFTER_CART_LINK_BTN', $message_after_cart_link);
		}
		if (isset($_POST['message_after_cart_ws'])){
			$message_after_cart_ws = sanitize_text_field($_POST['message_after_cart_ws']);
			update_option('HN_AFTER_CART_TEXT_WS', $message_after_cart_ws);
		}
		if (isset($_POST['message_after_cart_button_ws'])){
			$message_after_cart_button_ws = sanitize_text_field($_POST['message_after_cart_button_ws']);
			update_option('HN_AFTER_CART_TEXT_BTN_WS', $message_after_cart_button_ws);
		}		
		if (isset($_POST['message_after_cart_link_ws'])){
			$message_after_cart_link_ws = esc_url_raw($_POST['message_after_cart_link_ws']);
			update_option('HN_AFTER_CART_LINK_BTN_WS', $message_after_cart_link_ws);
		}	
		if (isset($_POST['wholesale_user_role'])){
			$wholesale_user_role = sanitize_text_field($_POST['wholesale_user_role']);
			update_option('HN_WHOLESALE_ROLE', $wholesale_user_role);
		}		
		if (isset($_POST['slug_variation'])){
			$slug_variation = sanitize_text_field($_POST['slug_variation']);
			update_option('HN_SLUG_VAR_QTIES', $slug_variation);
		}			
		if (isset($_POST['larger_qties_button'])){
			$larger_qties_button = esc_url_raw($_POST['larger_qties_button']);
			update_option('HN_SLUG_VAR_QTIES_LINK', $larger_qties_button);
		}	
		if (isset($_POST['disable_orders'])){
			update_option('HN_DISABLE_ORDERS', 'yes');
		} else {
			delete_option('HN_DISABLE_ORDERS');
		}
		if (isset($_POST['show_message'])){
			update_option('HN_SHOW_MESSAGE', 'yes');
		} else {
			delete_option('HN_SHOW_MESSAGE');
		}
		if (isset($_POST['message_alert'])){
			$message = stripslashes( esc_textarea($_POST['message_alert']));
			update_option('HN_MESSAGE_TO_SHOW', $message);
		}		
	}

	$after_cart_text = (get_option('HN_AFTER_CART_TEXT')) ? sanitize_text_field(get_option('HN_AFTER_CART_TEXT')) : 'Need larger quantities? Purchasing for a business?';
	$after_cart_text_button = (get_option('HN_AFTER_CART_TEXT_BTN')) ? sanitize_text_field(get_option('HN_AFTER_CART_TEXT_BTN')) : 'Register for a Wholesale Account';
	$after_cart_link_button = (get_option('HN_AFTER_CART_LINK_BTN')) ? esc_url(get_option('HN_AFTER_CART_LINK_BTN')) : home_url('/wholesale/register/');
	$after_cart_text_wholesale = (get_option('HN_AFTER_CART_TEXT_WS')) ? sanitize_text_field(get_option('HN_AFTER_CART_TEXT_WS')) : 'Need more than 200 lbs or a pallet load?';
	$after_cart_text_button_wholesale = (get_option('HN_AFTER_CART_TEXT_BTN_WS')) ? sanitize_text_field(get_option('HN_AFTER_CART_TEXT_BTN_WS')) : 'Request a quote';
	$after_cart_link_button_wholesale = (get_option('HN_AFTER_CART_LINK_BTN_WS')) ? esc_url(get_option('HN_AFTER_CART_LINK_BTN_WS')) : get_site_url().'/request-larger-quantities/';

	$wholesale_role_slug = (get_option('HN_WHOLESALE_ROLE')) ? sanitize_text_field(get_option('HN_WHOLESALE_ROLE')) : 'default_wholesaler';
	$slug_variation_larger_qties = (get_option('HN_SLUG_VAR_QTIES')) ? sanitize_text_field(get_option('HN_SLUG_VAR_QTIES')) : 'select-package';
	$slug_variation_larger_qties_link = (get_option('HN_SLUG_VAR_QTIES_LINK')) ? esc_url(get_option('HN_SLUG_VAR_QTIES_LINK')) : get_site_url().'/request-larger-quantities/';
	$disable_orders = (get_option('HN_DISABLE_ORDERS') == 'yes') ? 'checked' : '';
	$show_message = (get_option('HN_SHOW_MESSAGE') == 'yes') ? 'checked' : '';
	$message_to_show = (get_option('HN_MESSAGE_TO_SHOW')) ? esc_html(get_option('HN_MESSAGE_TO_SHOW')) : '';

	?>
	<style>
		#ik_hatton_panel_form_woo_messages label, #ik_hatton_panel_form_woo_messages span, #ik_hatton_panel_form_woo_messages div, #ik_hatton_panel_form_woo_messages input{
			display: block! important;
		}
		#ik_hatton_panel_form_woo_messages label{
			margin: 25px 0;
		}
		#ik_hatton_panel_form_woo_messages input[type=text], #ik_hatton_panel_form_woo_messages input[type=url]{
			max-width: 400px;
			width: 100%;
			font-size: 12px;
		}
		#ik_hatton_panel_form_woo_messages input[type=checkbox]{
			float: left;
			position: relative;
			top: 5px;
		}
        #ik_hatton_panel_form_woo_messages textarea{
            width: 396px;
            max-width: 90%;
            height: 90px;
        }
	</style>
	<div id="ik_hatton_panel_form_woo_messages">
		<h1>Product Page Messages </h1>
		<form action="" method="post" enctype="multipart/form-data" autocomplete="no">
			<label for="message_after_cart">
				<span>Message After Cart Retail Text</span>
				<input type="text" name="message_after_cart" value="<?php echo $after_cart_text; ?>" />
			</label>
			<label for="message_after_cart_button">
				<span>Message After Cart Retail text button</span>
				<input type="text" name="message_after_cart_button" value="<?php echo $after_cart_text_button; ?>" />
			</label>
			<label for="message_after_cart_button_link">
				<span>Message After Cart Retail URL</span>
				<input type="url" name="message_after_cart_link" value="<?php echo $after_cart_link_button; ?>" />
			</label>
			<label for="message_after_cart_ws">
				<span>Message After Cart Wholesale Text</span>
				<input type="text" name="message_after_cart_ws" value="<?php echo $after_cart_text_wholesale; ?>" />
			</label>
			<label for="message_after_cart_button_ws">
				<span>Message After Cart Wholesale text button</span>
				<input type="text" name="message_after_cart_button_ws" value="<?php echo $after_cart_text_button_wholesale; ?>" />
			</label>
			<label for="message_after_cart_button_link_ws">
				<span>Message After Cart Wholesale URL</span>
				<input type="url" name="message_after_cart_link_ws" value="<?php echo $after_cart_link_button_wholesale; ?>" />
			</label>
			<label for="wholesale_user_role">
				<span>Wholesale User Role Slug</span>
				<input type="text" name="wholesale_user_role" value="<?php echo $wholesale_role_slug; ?>" />
			</label>
			<label for="slug_variation">
				<span>Slug Used For Variations</span>
				<input type="text" name="slug_variation" value="<?php echo $slug_variation_larger_qties; ?>" />
			</label>
			<label for="larger_qties_button">
				<span>Larger Quantities Button URL</span>
				<input type="url" name="larger_qties_button" value="<?php echo $slug_variation_larger_qties_link; ?>" />
			</label>
			<label for="disable_orders">
				<input type="checkbox" name="disable_orders" value="yes" <?php echo $disable_orders; ?> />
				<span>Disable Orders</span>
			</label>
			<label for="show_message">
				<input type="checkbox" name="show_message" value="yes" <?php echo $show_message; ?> />
				<span>Show Message on top for maintenance or announcement</span>
			</label>
			<label for="message_alert">
				<span>Message Text</span>
				<textarea name="message_alert"><?php echo $message_to_show; ?></textarea>
			</label>
			<input type="submit" class="button-primary" value="Save">
		</form>
	</div>
	<script>
	jQuery(document).ready(function($) {
		jQuery('#ik_hatton_field_products_avoid_cert .ik_hatton_field_products_avoid_cert_box .ik_hatton_avoid_cert_product_id').select2({theme: 'classic'});
		jQuery('#ik_hatton_panel_form_cert_logos').on('click', '#ik_hatton_add_productid_select', function(){
			jQuery('#ik_hatton_field_products_avoid_cert').append('<div class="ik_hatton_field_products_avoid_cert_box"><select required class="ik_hatton_avoid_cert_product_id" name="product_id[]"><option>Select Product</option><?php echo ik_hatton_list_options_id(); ?></select><button class="remove_productid_select button">Remove</button></div>');
			jQuery('#ik_hatton_field_products_avoid_cert .ik_hatton_field_products_avoid_cert_box:last-child .ik_hatton_avoid_cert_product_id').select2({theme: 'classic'});
			 return false;
		});
		jQuery('#ik_hatton_panel_form_cert_logos').on('click', '.remove_productid_select', function(){
			 jQuery(this).parent().remove();
			 return false;
		});
	});
	</script>
	<?php	
}

?>