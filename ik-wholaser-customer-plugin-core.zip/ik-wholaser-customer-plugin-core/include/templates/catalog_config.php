<?php
/*

Wholesale Customer Plugin - Catalog Functions Settings page
Created: 03/02/2023
Last Update: 01/08/2024
Author: Gabriel Caroprese
*/

if ( ! defined('ABSPATH')) exit('restricted access');
?>

<?php

//If form submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	//update_option('ik_hn_catalog_organic_logos_img', $organic_logos_img);
    update_option('ik_hn_catalog_message_header', $message_header);
        
}
  
$message_header = sanitize_text_field(get_option('ik_hn_catalog_message_header'));

?>
<style>
#ik_hn_catalog_pdf_config_panel input[type=text], #ik_hn_catalog_pdf_config_panel input[type=url] {
    width: 100%;
    max-width: 570px;
}
</style>
<div id="ik_hn_catalog_pdf_config_panel">
    
    <h2>Config - Wholesale Customer Catalog</h2>
	<p>Create download pdf link by adding ?downloadpricelist at the end of the URL</p>
    <form action="" method="post" enctype="multipart/form-data" autocomplete="no">  
        <label>
			<p>
				<span>Message at header</span><br />
				<input type="text" name="message_header" value="<?php echo $message_header; ?>">
			</p>
		</label>      
        <input type="submit" class="button-primary" value="Save">
    </form>
</div>