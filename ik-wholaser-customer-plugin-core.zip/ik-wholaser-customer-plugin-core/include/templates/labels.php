<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - //Menu for Label Generation
Created: 01/10/2024
Last Update: 01/12/2024
Author: Gabriel Caroprese
*/

$labels = new HN_Labels();
//to upload barcodes
wp_enqueue_media();
?>
<style>
body #setting-error-tgmpa, #setting-error-naturally {
    display: none !important;
}
#ik_hn_label_generator h3, #ik_hn_label_generator h4{
    margin-bottom: 3px;
}
#ik_hn_label_generator label{
    display: block;
}
#ik_hn_label_generator select, #ik_hn_label_generator input{
    width: 100%;
    max-width: 315px;
}
#ik_hn_label_btn_generate, #ik_hn_label_generator a{
    margin-top: 15px;
    display: block;
    text-align: center;
}
#ik_hn_label_form_wrapper, #ik_hn_label_generated{
    display: block;
    max-width: calc(50% - 20px);
    float: left;    
}
#ik_hn_label_form_wrapper {
    min-width: 278px;
    margin-right: 20px;
}
#ik_hn_label_generated{
    margin-left: 20px;
}
#ik_hn_label_generated img{
    width: auto;
    max-height: 486px;
}
#ik_hn_barcode_file{
    max-width: 250px;
    padding: 0;
    margin: 7px 0 -5px;
}
.loading-spinner {
    display: inline-block;
    width: 16px;
    height: 16px;
    position: relative;
    top: 4px;
    border: 2px solid #fff;
    border-radius: 50%;
    border-top: 2px solid #3498db;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

</style>
<h1>Label Generator</h1>
<div id="ik_hn_label_generator">
    <?php echo $labels->get_form(); ?>
</div>
<script>
    jQuery(document).ready(function () {
        // Get the select element
        var ik_hn_label_selected_template = 0;

        // Set up an event listener for the 'change' event
        jQuery('body').on('change', '#ik_hn_label_select_template', function () {
            var generateButton = jQuery('#ik_hn_label_btn_generate');
            generateButton.prop('disabled', true);
            generateButton.html('<span class="loading-spinner"></span>');
            // Update the value of ik_hn_label_selected_template
            ik_hn_label_selected_template = jQuery(this).val();
            var data = {
                action: "ik_hn_label_ajax_update_template",
                "post_type": "post",
                "selected_template": ik_hn_label_selected_template,
            };

            jQuery.post(ajaxurl, data, function (response) {
                if (response) {
                    jQuery('#ik_hn_label_generator').html(response);
                    var generateButton = jQuery('#ik_hn_label_btn_generate');
                    // Enable the button and reset its text
                    generateButton.prop('disabled', false);
                    generateButton.text('Generate');
                }
            });

        });

        jQuery('body').on('submit', '#ik_hn_label_form', function (event) {
            // Disable the button and show loading state
            var generateButton = jQuery('#ik_hn_label_btn_generate');
            generateButton.prop('disabled', true);
            generateButton.html('<span class="loading-spinner"></span>');

            // Prepare the form data
            var formData = jQuery(this).serializeArray();

            var inputFile = parseInt(jQuery('#ik_hn_barcode_image_id').val());
            if (inputFile > 0) {
            }
            var data = {
                action: "ik_hn_label_ajax_process_form",
                "post_type": "post",
                "form_data": formData,
                "barcode_img_id": inputFile,
                "selected_template": ik_hn_label_selected_template,
            };

            jQuery.post(ajaxurl, data, function (response) {
                if (response) {
                    jQuery('#ik_hn_label_generated img').attr('src', response);
                    jQuery('#ik_hn_label_generate_btn').attr('href', response);
                    var generateButton = jQuery('#ik_hn_label_btn_generate');
                    // Enable the button and reset its text
                    generateButton.prop('disabled', false);
                    generateButton.text('Generate');
                }
            });

            event.preventDefault(); // Prevent the form from submitting in the traditional way
        });

        jQuery('body').on('click', '#ik_hn_barcode_upload_img', function(e) {
        e.preventDefault();
        var image_frame;
        if(image_frame){
            image_frame.open();
        }
        // Define image_frame as wp.media object
        image_frame = wp.media({
            title: 'Media',
            multiple : false,
            library : {
                type : 'image',
            }
       });

       image_frame.on('close',function() {
            // On close, get selections and save to the hidden input
            // plus other AJAX stuff to refresh the image preview
            var selection =  image_frame.state().get('selection');
            var gallery_ids = new Array();
            var my_index = 0;
            selection.each(function(attachment) {
                gallery_ids[my_index] = attachment['id'];
                my_index++;
            });
            
            var ids = gallery_ids.join(",");
            jQuery('input#ik_hn_barcode_image_id').val(ids);
            Refresh_Image(ids);
        });

        image_frame.on('open',function() {
            // On open, get the id from the hidden input
            // and select the appropiate images in the media manager
            var selection =  image_frame.state().get('selection');
            var ids = jQuery('input#ik_hn_barcode_image_id').val().split(',');
            ids.forEach(function(id) {
                var attachment = wp.media.attachment(id);
                attachment.fetch();
                selection.add( attachment ? [ attachment ] : [] );
            });
        });
        
        image_frame.open();
     });
     jQuery( "body" ).on( "click", "#ik_hn_labels_button_delete", function() {
        jQuery(this).remove();
        jQuery('#ik_hn_barcode_image_id').val('');
        jQuery('#ik_hn_barcode_file').text('');
    });

    function Refresh_Image(the_id){
        var data = {
            action: 'ik_hn_label_ajax_upload_barcode',
            id: the_id
        };

        jQuery.get(ajaxurl, data, function(response) {
            if(response.success === true) {
                if(response.data){
                    jQuery('#ik_hn_barcode_file').text(response.data);
                    if (jQuery('#ik_hn_labels_button_delete').length < 1){
                        jQuery('<button style="width: 100%; margin-top:4px;background:#f00e0e;border-color:#f00e0e;" class="button-primary" id="ik_hn_labels_button_delete">Delete</button>').insertAfter('#ik_hn_barcode_upload_img');
                    }
                }
            }
        });
    }
});
</script>
