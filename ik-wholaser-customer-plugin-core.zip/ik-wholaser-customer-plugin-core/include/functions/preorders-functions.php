<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Preorders functions
Created: 03/02/2023
Last Update: 24/02/2023
Author: Gabriel Caroprese
*/

/**
*	Start of Pre-orders
*/
// I create a custom post type to add special promotions to preorder
function ik_hnaturals_create_post_type_preorders() {
    register_post_type( 'preorders',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Pre-orders' ),
                'singular_name' => __( 'pre-order ' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'pre-orders'),
            'show_in_rest' => true,
			'supports'            => array( 'title', 'custom-fields', 'excerpt', 'ik_promotional_text', 'editor', 'author', 'thumbnail', 'revisions' ),
        )
    );
}
add_action( 'init', 'ik_hnaturals_create_post_type_preorders' );

//I add post type
function ik_add_post_type_preorder() {
// Set UI labels for Custom Post Type
    $labels = array(
        'name'                => _x( 'pre-orders', 'Post Type General Name', 'twentytwenty' ),
        'singular_name'       => _x( 'pre-order', 'Post Type Singular Name', 'twentytwenty' ),
        'menu_name'           => __( 'pre-orders', 'twentytwenty' ),
        'all_items'           => __( 'All Pre-orders', 'twentytwenty' ),
        'view_item'           => __( 'View Pre-order', 'twentytwenty' ),
        'add_new_item'        => __( 'Add New Pre-order', 'twentytwenty' ),
        'add_new'             => __( 'Add New', 'twentytwenty' ),
        'edit_item'           => __( 'Edit Pre-order', 'twentytwenty' ),
        'update_item'         => __( 'Update Pre-order', 'twentytwenty' ),
        'search_items'        => __( 'Search Pre-orders', 'twentytwenty' ),
        'not_found'           => __( 'Not Found', 'twentytwenty' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentytwenty' ),
    );
     
// Set other options for Custom Post Type
     
    $args = array(
        'label'               => __( 'Pre-orders', 'twentytwenty' ),
        'description'         => __( 'Pre-order Info', 'twentytwenty' ),
        'labels'              => $labels,
        'supports'            => array( 'title', 'custom-fields', 'excerpt', 'ik_promotional_text', 'editor', 'author', 'thumbnail', 'revisions' ),
        'taxonomies'  => array( '' ),
        'thumbnail'         => true,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
        'show_in_rest' => true,
    );
     
    // Registering your Custom Post Type
    register_post_type( 'preorders', $args );
}

add_post_type_support( 'preorders', 'thumbnail' );    

add_action( 'init', 'ik_hnaturals_category_type_of_preorder', 0 );
function ik_hnaturals_category_type_of_preorder() {
	$labels = array(
		'name'              => _x( 'Category of Pre-orders', 'Category of Pre-orders' ),
		'singular_name'     => _x( 'Category of Pre-order', 'Category of Pre-order' ),
		'search_items'      => __( 'Search Category of Pre-orders' ),
		'all_items'         => __( 'All Category of Pre-orders' ),
		'parent_item'       => __( 'Parent Category of Pre-orders' ),
		'parent_item_colon' => __( 'Parent Category of Pre-orders:' ),
		'edit_item'         => __( 'Edit Category of Pre-orders' ), 
		'update_item'       => __( 'Update Category of Pre-orders' ),
		'add_new_item'      => __( 'Add New Category of Pre-orders' ),
		'new_item_name'     => __( 'New Category of Pre-orders' ),
		'menu_name'         => __( 'Categories' ),
	);
	$args = array(
		'labels' 		=> $labels,
		'hierarchical'      	=> true,
		'exclude_from_search' 	=> true,
		'public'            	=> true,
		'show_ui'           	=> true,
		'show_admin_column' 	=> true,
		'show_in_nav_menus' 	=> true,
		'show_in_rest' 		=> true,
		'show_tagcloud'     	=> true,
		'query_var' 		=> true
	);
	register_taxonomy( 'category-of-preorders', 'preorders', $args );
}

// I create the metaboxes for preorder post type
function ik_hnaturals_preorders_data_metaboxes() {
	add_meta_box(
		'ik_preorders_product_data',
		'Product Data',
		'ik_preorders_product_data',
		'preorders',
		'normal',
		'high'
	);
	add_meta_box(
		'ik_preorders_available',
		'Not Available?',
		'ik_preorders_available',
		'preorders',
		'side',
		'default'
	);
	add_meta_box(
		'ik_preorders_hide',
		'Hide from listing?',
		'ik_preorders_hide',
		'preorders',
		'side',
		'default'
	);
	add_meta_box(
		'ik_preorders_is_certified',
		'Certified organic?',
		'ik_preorders_is_certified',
		'preorders',
		'side',
		'default'
	);
	add_meta_box(
		'ik_preorders_pdf',
		'Product Specification Sheet',
		'ik_preorders_pdf',
		'preorders',
		'side',
		'default'
	);
	add_meta_box(
		'ik_preorders_shipment_status',
		'Shipment Status',
		'ik_preorders_shipment_status',
		'preorders',
		'side',
		'default'
	);
	add_meta_box(
		'ik_hnaturals_promotional_text_edit',
		'Promotional Text',
		'ik_hnaturals_promotional_text_edit',
		'preorders',
		'normal',
		'high'
	);
	add_meta_box(
		'ik_hnaturals_enable_wc_checkout',
		'Enable Woocommerce Checkout?',
		'ik_hnaturals_enable_wc_checkout',
		'preorders',
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'ik_hnaturals_preorders_data_metaboxes' );

//I add the editor to add texts about preorders
function ik_hnaturals_promotional_text_edit() {
    global $post;
	wp_nonce_field( basename( __FILE__ ), 'preorders_fields' );
	$promotional_text = get_post_meta( $post->ID, 'ik_promotional_text', true);
	$promotional_text = html_entity_decode($promotional_text);

	wp_editor(
		$promotional_text,
		'ik_promotional_text',
		array(
			'textarea_name' =>  'ik_promotional_text',
			'media_buttons' =>  true,
		)
	);
}

//Option to enable Woocommerce checkout for preorders
function ik_hnaturals_enable_wc_checkout(){
	global $post;
	// Nonce field to validate form request came from current site
	wp_nonce_field( basename( __FILE__ ), 'preorders_fields' );
	$databoxes = get_post_meta( $post->ID, 'use_woocommerce', true );
	// Output the field
	if (sanitize_text_field( $databoxes ) === "yes"){
		$checked_available = "checked"; 
	} else {
		$checked_available = ""; 
	}
	echo '
	<label><input type="checkbox" name="ik_preorders_use_woocommerce" id="ik_preorders_use_woocommerce" ' . esc_textarea($checked_available)  . ' value ="yes" class="'.esc_textarea( $databoxes ).'widefat"> Yes</label>';
}


function ik_preorders_product_data() {
	global $post;
	// Nonce field to validate form request came from current site
	wp_nonce_field( basename( __FILE__ ), 'preorders_fields' );
	$product_variable = get_post_meta( $post->ID, 'ik_preorders_product_variable', true);
	$variable_data_product = get_post_meta( $post->ID, 'ik_preorders_product_variable_data', true );
	$regular_price = get_post_meta( $post->ID, 'ik_preorders_regular_price', true );
	$sale_price = get_post_meta( $post->ID, 'ik_preorders_sale_price', true );
	$shipping_price = get_post_meta( $post->ID, 'ik_preorders_shipping_price', true );
	$weight = get_post_meta( $post->ID, 'ik_preorders_weight', true );
	$dimensions = get_post_meta( $post->ID, 'ik_preorders_dimensions', true );
	$weight = floatval($weight);
	$shipping_price = floatval($shipping_price);
	$dimensions = sanitize_text_field($dimensions);
	$ik_preorders_enable_ups = (intval(get_post_meta($post->ID, 'ik_preorders_enable_ups', true)) == 1) ? 'checked': '';
	$ik_preorders_allow_quantity = (intval(get_post_meta($post->ID, 'ik_preorders_allow_quantity', true))) ? 'checked': '';
	$ik_preorders_max_quantity = intval(get_post_meta($post->ID, 'ik_preorders_max_quantity', true));
	$ik_preorders_max_quantity = ($ik_preorders_max_quantity == 0) ? 5 : $ik_preorders_max_quantity;
	$ik_preorders_quantity_discount = intval(get_post_meta($post->ID, 'ik_preorders_quantity_discount', true));
	$ik_preorders_quantity_discount = ($ik_preorders_quantity_discount == 0) ? 5 : $ik_preorders_quantity_discount;
	$ik_preorders_allow_discount = (intval(get_post_meta($post->ID, 'ik_preorders_allow_discount', true))) ? 'checked': '';
	$ik_preorders_allow_discount_show = ($ik_preorders_allow_discount == 'checked') ? '' : 'style="display:none"';
	$ik_preorders_percentage_discount = floatval(get_post_meta($post->ID, 'ik_preorders_percentage_discount', true));

	if ($product_variable == 'yes'){
		$checkedvariable = 'checked';
		$stylesimple = 'style="display: none"';
		$stylevariable = '';		
	} else {
		$checkedvariable = '';
		$stylevariable = 'style="display: none"';
		$stylesimple = '';		
	}

	// Output the field
	echo '<style>
	#wpfooter{
		display: none;
	}
	#preorder_product_details label{
		display: block;
		margin-bottom: 12px;
	}
	#preorder_product_details input[type=number], #preorder_product_details input[type=text]{
		display: block;
		max-width: 250px;
	}
	#preorder_product_details .data_variation{
		display: flow-root;
		border-top: 1px solid #ccc;
		padding: 12px 0;
	}
	#preorder_product_details .data_variation:first-child{
		display: flow-root;
		border-top: 0px solid #ccc;
	}
	.delete_preorder_product_var{
		background: red! important;
		border-color: red! important;
		float: left;
		position: relative;
		top: 17.5px;
		right: 34px;
	}
	#preorder_product_details .data_variation_secondary .inneroptions{
		display: none;
		background: #ddd;
		padding: 20px;
		min-width: 96%;
	}
	#preorder_product_details .data_variation_secondary label{
		min-width: 150px;
		display: flow-root;
	}
	@media (min-width: 768px){
		#preorder_product_details .variable_product .data_variation_main label{
			width: 20%;
			float: left;
			margin-right: 2%;
			min-width: 200px;
		}
		#preorder_product_details .add_preorder_product_button{
			display: flow-root;
			width: 100%;
		}
	}
	</style>
	<div id="preorder_product_details">
	<label><input type="checkbox" '.$checkedvariable.' name="ik_preorders_product_variable" id="ik_preorders_product_variable" value="yes"> Product has variations</label>
	<div class="simple_product"  '.$stylesimple.'>
		<label>
		<span>Regular Price</span>
			<input type="number" step="0.01" name="ik_preorders_regular_price" class="widefat" id="ik_preorders_regular_price" value="' . esc_textarea( $regular_price )  . '">
		</label>
		<label>
			<span>Sale Price</span>
			<input type="number" step="0.01" name="ik_preorders_sale_price" id="ik_preorders_sale_price" value="' . esc_textarea( $sale_price )  . '" class="widefat">
		</label>
		<label>
			<span>Shipping Price (0 shows lift gate option or UPS rates if enabled)</span>
			<input type="number" step="0.01" name="ik_preorders_shipping_price" id="ik_preorders_shipping_price" value="' . $shipping_price  . '" class="widefat">
		</label>
		<label>
			<span>Weight</span>
			<input type="number" step="0.01" name="ik_preorders_weight" id="ik_preorders_weight" value="'.$weight.'" class="widefat">
		</label>		
		<label>
			<span>Dimensions</span>
			<input type="text" placeholder="Example: 18x18x18" name="ik_preorders_dimensions" value="'.$dimensions.'"  id="ik_preorders_dimensions" class="widefat">
		</label>		
		<label>
			<input type="checkbox" '.$ik_preorders_enable_ups.' name="ik_preorders_enable_ups" id="ik_preorders_enable_ups" value="1" class="widefat"> <span>Enable UPS Shipping</span> 
		</label>
		<label>
			<input type="checkbox" '.$ik_preorders_allow_quantity.' name="ik_preorders_allow_quantity" id="ik_preorders_allow_quantity" value="1"> <span>Allow Quantity Selector</span>
			<p>
				<span>Max. Qty.</span>
				<input type="number" step="1" name="ik_preorders_max_quantity" id="ik_preorders_max_quantity" value="' . $ik_preorders_max_quantity  . '" class="widefat">
			</p>
		</label>
		<label>
			<input type="checkbox" '.$ik_preorders_allow_discount.' class="ik_hnaturals_show_discount_options" name="ik_preorders_allow_discount" id="ik_preorders_allow_discount" value="1"> <span>Allow Discount per Qty.</span>
		</label>
		<p class="ik_hnaturals_show_discount_panel" '.$ik_preorders_allow_discount_show.'>
			<span>Qty for discount</span>
			<input type="number" step="1" name="ik_preorders_quantity_discount" id="ik_preorders_quantity_discount" value="' . $ik_preorders_quantity_discount  . '">
			<span>Discount Percentage</span>
			<input type="number" step="0.01" name="ik_preorders_percentage_discount" id="ik_preorders_percentage_discount" value="' . $ik_preorders_percentage_discount  . '">
		</p>
	</div>
	<div class="variable_product" '.$stylevariable.'>
	';
	if (is_array($variable_data_product)){
		echo '<div class="data_variation_fields">';

		foreach ($variable_data_product as $product_var){	
			$name_var = $product_var['name'];
			$regular_price_var = (isset($product_var['regular_price'])) ? floatval($product_var['regular_price']) : 0;
			$sale_price_var = (isset($product_var['sale_price'])) ? floatval($product_var['sale_price']) : 0;
			$shipping_price_var = (isset($product_var['shipping_price'])) ? floatval($product_var['shipping_price']) : 0;
			
			$enable_ups = (isset($product_var['enable_ups'])) ? intval( $product_var['enable_ups']) : 0;
			$enable_ups_checked = ($enable_ups === 1) ? 'checked' : '';
			$allow_qty = (isset($product_var['allow_qty'])) ? intval( $product_var['allow_qty']) : 0;
			$allow_qty = ($allow_qty == 1) ? 'checked' : '';
			$max_qty = (isset($product_var['max_qty'])) ? intval( $product_var['max_qty']) : 0;
			$allow_qty_discval = (isset($product_var['allow_qty_disc'])) ? intval( $product_var['allow_qty_disc']) : 0;
			$allow_qty_disc = ($allow_qty_discval == 1) ? 'checked' : '';
			$allow_qty_disc_panel_show = ($allow_qty_disc !== 'checked') ? 'style="display: none"' : '';
			$qty_discount = (isset($product_var['qty_discount'])) ? intval( $product_var['qty_discount']) : 0;
			$percent_qty_dic = (isset($product_var['percent_qty_dic'])) ? floatval( $product_var['percent_qty_dic']) : 0;
			$weight = (isset($product_var['weight'])) ? floatval( $product_var['weight']) : 0;
			$dimensions = (isset($product_var['dimensions'])) ? sanitize_text_field( $product_var['dimensions']) : 0;

			echo '<div class="data_variation">
					<div class="data_variation_main">
						<label>
							<span>Name of variation</span>
							<input type="text" name="ik_preorders_name_var[]" class="ik_preorders_name_var" value="' . esc_textarea( $name_var  )  . '">
						</label>
						<label>
							<span>Regular Price</span>
							<input type="number" step="0.01" name="ik_preorders_regular_price_var[]" class="ik_preorders_regular_price_var" value="' . esc_textarea( $regular_price_var )  . '">
						</label>
						<label>
							<span>Sale Price</span>
							<input type="number" step="0.01" name="ik_preorders_sale_price_var[]" class="ik_preorders_sale_price_var" value="' . esc_textarea( $sale_price_var )  . '">
						</label>
						<label>
							<span>Shipping Price *</span>
							<input type="number" step="0.01" name="ik_preorders_shipping_price_var[]" class="ik_preorders_shipping_price_var" value="' . floatval($shipping_price_var)  . '">
						</label>
						<button class="delete_preorder_product_var button-primary">Delete</button>
					</div>
					<div class="data_variation_secondary">
						<label>
							<input type="checkbox" class="ik_preorders_show_variation_options" value="1"> <span>Show additional options</span> 
						</label>
						<div class="inneroptions">
							<label>
								<span>Weight</span>
								<input type="number" step="0.01" name="ik_preorders_weight_var[]" class="ik_preorders_weight_var" value="'.$weight.'">
							</label>		
							<label>
								<span>Dimensions</span>
								<input type="text" placeholder="Example: 18x18x18" name="ik_preorders_dimensions_var[]" value="'.$dimensions.'"  class="ik_preorders_dimensions_var">
							</label>	
							<label>
								<input type="checkbox" '.$enable_ups_checked.' class="ik_preorders_enable_ups_var" value="1"> <span>Enable UPS Shipping</span> 
								<input type="hidden" name="ik_preorders_enable_ups_var[]" class="ik_preorders_enable_ups_val" value="'.$enable_ups.'"> 
							</label>
							<label>
								<input type="checkbox" '.$allow_qty.' name="ik_preorders_allow_quantity_var[]" class="ik_preorders_allow_quantity_var" value="1"> <span>Allow Quantity Selector</span>
								<p>
									<span>Max. Qty.</span>
									<input type="number" step="1" name="ik_preorders_max_quantity_var[]" class="ik_preorders_max_quantity_var" class="widefat" value="'.$max_qty.'">
								</p>
							</label>
							<label>
								<input type="checkbox" '.$allow_qty_disc.' class="ik_preorders_allow_discount_var" value="1"> <span>Allow Discount per Qty.</span>
								<input type="hidden" name="ik_preorders_allow_discount_var[]" class="ik_preorders_allow_discount_val" value="'.$allow_qty_discval.'">
							</label>
							<p class="ik_hnaturals_show_discount_panel" '.$allow_qty_disc_panel_show.'>
								<span>Qty for discount</span>
								<input type="number" step="1" name="ik_preorders_quantity_discount_var[]" class="ik_preorders_quantity_discount_var" value="'.$qty_discount.'">
								<span>Discount Percentage</span>
								<input type="number" step="0.01" name="ik_preorders_percentage_discount_var[]" class="ik_preorders_percentage_discount_var" value="'.$percent_qty_dic.'">
							</p>
						</div>
					</div>
				</div>';
		}
		echo '</div>';

	} else {
		echo '<div class="data_variation_fields">
			<div class="data_variation">
				<div class="data_variation_main">
					<label>
						<span>Name</span>
						<input type="text" name="ik_preorders_name_var[]" class="ik_preorders_name_var" value="">
					</label>
					<label>
						<span>Regular Price</span>
						<input type="number" step="0.01" name="ik_preorders_regular_price_var[]" class="ik_preorders_regular_price_var" value="' . esc_textarea( $regular_price )  . '">
					</label>
					<label>
						<span>Sale Price</span>
						<input type="number" step="0.01" name="ik_preorders_sale_price_var[]" class="ik_preorders_sale_price_var" value="' . esc_textarea( $sale_price )  . '">
					</label>
					<label>
						<span>Shipping Price</span>
						<input type="number" step="0.01" name="ik_preorders_shipping_price_var[]" class="ik_preorders_shipping_price_var" value="' . $shipping_price  . '">
					</label>
				</div>
				<div class="data_variation_secondary">
					<label>
						<input type="checkbox" class="ik_preorders_show_variation_options" value="1"> <span>Show additional options</span> 
					</label>
					<div class="inneroptions">
						<label> 
							<span>Weight</span> 
							<input type="number" name="ik_preorders_weight_var[]" class="ik_preorders_weight_var" value=""> 
						</label>
						<label>
							<span>Dimensions</span>
							<input type="text" placeholder="Example: 18x18x18" name="ik_preorders_dimensions_var[]" value="" class="ik_preorders_dimensions_var"> 
						</label>
						<label>
							<input type="checkbox" class="ik_preorders_enable_ups_var" value="1"> <span>Enable UPS Shipping</span><input type="hidden" name="ik_preorders_enable_ups_var[]" class="ik_preorders_enable_ups_val" value="'.$enable_ups.'">  
						</label>
						<label>
							<input type="checkbox" name="ik_preorders_allow_quantity_var[]" class="ik_preorders_allow_quantity_var" value="1"> <span>Allow Quantity Selector</span>
							<p>
								<span>Max. Qty.</span>
								<input type="number" step="1" name="ik_preorders_max_quantity_var[]" class="ik_preorders_max_quantity_var" class="widefat" value="5">
							</p>
						</label>
						<label>
							<input type="checkbox" class="ik_preorders_allow_discount_var"> <span>Allow Discount per Qty.</span>
							<input type="hidden" name="ik_preorders_allow_discount_var[]" class="ik_preorders_allow_discount_val" value="0">
						</label>
						<p class="ik_hnaturals_show_discount_panel" style="display: none">
							<span>Qty for discount</span>
							<input type="number" step="1" name="ik_preorders_quantity_discount_var[]" class="ik_preorders_quantity_discount_var" value="">
							<span>Discount Percentage</span>
							<input type="number" step="0.01" name="ik_preorders_percentage_discount_var[]" class="ik_preorders_percentage_discount_var" value="">
						</p>
					</div>
				</div>
				</div>
			</div>';
	}
	echo '<div class="add_preorder_product_button">
				<button id="add_preorder_product_var" class="button">Add variation</button>
			</div>
			<p>*Leave shipping options and UPS disabled and lift gate selector will be automatically shown on the form.</p>
		</div>
		</div>
	</div>
	<script>
		jQuery("#ik_preorders_product_variable").on("click", function(){
			if (jQuery(this).is(":checked")) {
				jQuery("#preorder_product_details .simple_product").fadeOut(500);
				jQuery("#preorder_product_details .variable_product").fadeIn(500);
			} else {
				jQuery("#preorder_product_details .variable_product").fadeOut(500);
				jQuery("#preorder_product_details .simple_product").fadeIn(500);
			}
		});
		jQuery("#preorder_product_details").on("click", "#add_preorder_product_var", function(){
						var input_fields_product_details = \'<div class="data_variation"><div class="data_variation_main"><label><span>Name of variation</span><input type="text" name="ik_preorders_name_var[]" class="ik_preorders_name_var" value=""></label><label><span>Regular Price</span><input type="number" required step="0.01" name="ik_preorders_regular_price_var[]" class="ik_preorders_regular_price_var" value=""></label><label><span>Sale Price</span><input type="number" step="0.01" name="ik_preorders_sale_price_var[]" class="ik_preorders_sale_price_var" value=""></label><label><span>Shipping Price</span><input type="number" step="0.01" name="ik_preorders_shipping_price_var[]" class="ik_preorders_shipping_price_var" value=""></label><button class="delete_preorder_product_var button-primary">Delete</button></div><div class="data_variation_secondary"><label><input type="checkbox" class="ik_preorders_show_variation_options" value="1"> <span>Show additional options</span> </label><div class="inneroptions"><label> <span>Weight</span> <input type="number" name="ik_preorders_weight_var[]" class="ik_preorders_weight_var" value=""> </label> <label> <span>Dimensions</span> <input type="text" placeholder="Example: 18x18x18" name="ik_preorders_dimensions_var[]" value=""  class="ik_preorders_dimensions_var"> </label><label><input type="checkbox" class="ik_preorders_enable_ups_var" value="1"> <span>Enable UPS Shipping</span><input type="hidden" name="ik_preorders_enable_ups_var[]" class="ik_preorders_enable_ups_val" value="0">  </label><label><input type="checkbox" name="ik_preorders_allow_quantity_var[]" class="ik_preorders_allow_quantity_var" value="1"> <span>Allow Quantity Selector</span><p><span>Max. Qty.</span><input type="number" step="1" name="ik_preorders_max_quantity_var[]" class="ik_preorders_max_quantity_var" class="widefat" value="5"></p></label><label><input type="checkbox" class="ik_preorders_allow_discount_var" value="1"> <span>Allow Discount per Qty.</span><input type="hidden" name="ik_preorders_allow_discount_var[]" class="ik_preorders_allow_discount_val" value="0"></label><p class="ik_hnaturals_show_discount_panel" style="display: none"><span>Qty for discount</span><input type="number" step="1" name="ik_preorders_quantity_discount_var[]" class="ik_preorders_quantity_discount_var" value=""><span>Discount Percentage</span><input type="number" step="0.01" name="ik_preorders_percentage_discount_var[]" class="ik_preorders_percentage_discount_var" value=""></p></div></div>\';
			jQuery("#preorder_product_details .variable_product .data_variation_fields").append(input_fields_product_details);
		});
		jQuery("#preorder_product_details").on("click", ".delete_preorder_product_var", function(){
			jQuery(this).parent().parent().remove();
		});
		jQuery("#preorder_product_details").on("click", ".ik_preorders_allow_discount_var", function(){
			if (jQuery(this).is(":checked")){
				jQuery(this).parent().find(".ik_preorders_allow_discount_val").val("1");
				jQuery(this).parent().parent().find(".ik_hnaturals_show_discount_panel").fadeIn(600);
			} else {
				jQuery(this).parent().find(".ik_preorders_allow_discount_val").val("0");
				jQuery(this).parent().parent().find(".ik_hnaturals_show_discount_panel").fadeOut(600);
			}
		});	
		jQuery("#preorder_product_details").on("click", ".ik_preorders_show_variation_options", function(){
			if (jQuery(this).is(":checked")){
				jQuery(this).parent().parent().find(".inneroptions").fadeIn(600);
			} else {
				jQuery(this).parent().parent().find(".inneroptions").fadeOut(600);
			}
		});	
		jQuery("#preorder_product_details").on("click", ".ik_preorders_allow_discount_var", function(){
			if (jQuery(this).is(":checked")){
				jQuery(this).parent().find(".ik_preorders_allow_discount_val").val("1");
				jQuery(this).parent().parent().find(".ik_hnaturals_show_discount_panel").fadeIn(600);
			} else {
				jQuery(this).parent().find(".ik_preorders_allow_discount_val").val("0");
				jQuery(this).parent().parent().find(".ik_hnaturals_show_discount_panel").fadeOut(600);
			}
		});	
		jQuery("#preorder_product_details").on("click", ".ik_hnaturals_show_discount_options", function(){
			if (jQuery(this).is(":checked")){
				jQuery(this).parent().parent().find(".ik_hnaturals_show_discount_panel").fadeIn(600);
			} else {
				jQuery(this).parent().parent().find(".ik_hnaturals_show_discount_panel").fadeOut(600);
			}
		});	
		jQuery("#preorder_product_details").on("click", ".ik_preorders_enable_ups_var", function(){
			if (jQuery(this).is(":checked")){
				jQuery(this).parent().find(".ik_preorders_enable_ups_val").val("1");
			} else {
				jQuery(this).parent().find(".ik_preorders_enable_ups_val").val("0");
			}
		});	
	</script>';
}
function ik_preorders_available() {
	global $post;
	// Nonce field to validate form request came from current site
	wp_nonce_field( basename( __FILE__ ), 'preorders_fields' );
	$databoxes = get_post_meta( $post->ID, 'ik_preorders_available', true );
	// Output the field
	if (sanitize_text_field( $databoxes ) === "yes"){
		$checked_available = "checked"; 
	} else {
		$checked_available = ""; 
	}
	echo '
	<label><input type="checkbox" name="ik_preorders_available" id="ik_preorders_available" ' . esc_textarea($checked_available)  . ' value ="yes" class="'.esc_textarea( $databoxes ).'widefat"> Offer Not Available</label>';
}

function ik_preorders_hide(){
	global $post;
	// Nonce field to validate form request came from current site
	wp_nonce_field( basename( __FILE__ ), 'preorders_fields' );
	$databoxes = get_post_meta( $post->ID, 'ik_preorders_hide', true );
	// Output the field
	if (sanitize_text_field( $databoxes ) === "yes"){
		$checked_hide = "checked"; 
	} else {
		$checked_hide = ""; 
	}
	echo '
	<label><input type="checkbox" name="ik_preorders_hide" id="ik_preorders_hide" ' . esc_textarea($checked_hide)  . ' value ="yes" class="'.esc_textarea( $databoxes ).'widefat"> Hide</label>';
}

function ik_preorders_is_certified() {
	global $post;
	// Nonce field to validate form request came from current site
	wp_nonce_field( basename( __FILE__ ), 'preorders_fields' );
	$databoxes = get_post_meta( $post->ID, 'is_certified', true );
	// Output the field
	if (sanitize_text_field( $databoxes ) === "yes"){
		$checked_available = "checked"; 
	} else {
		$checked_available = ""; 
	}
	echo '
	<label><input type="checkbox" name="ik_preorders_is_certified" id="ik_preorders_is_certified" ' . esc_textarea($checked_available)  . ' value ="yes" class="'.esc_textarea( $databoxes ).'widefat"> Show certified organic logos</label>';
}

function ik_preorders_shipment_status() {
	global $post;
	// Nonce field to validate form request came from current site
	wp_nonce_field( basename( __FILE__ ), 'preorders_fields' );
	$status_id = get_post_meta( $post->ID, 'ik_preorders_shipment_status', true );
	// Output the field

	$shipments_status_preorders = ik_hnaturals_get_shipment_status();
	echo '
	<style>
	#ik_preorders_shipment_status select{
		width: 100%;
		max-width: 180px;
		margin: 0 auto;
		text-align: center;
		display: block;
	}
	</style>
	<select required name="ik_preorders_shipment_status">
			<option value="0">No</option>';
			if (is_array($shipments_status_preorders)){
				foreach ($shipments_status_preorders as $shipment_status_preorders){
					if ($shipment_status_preorders['id'] == $status_id){
						$selectedattr = "selected";
					} else {
						$selectedattr = "";
					}

					echo '<option '.$selectedattr.' value="'.$shipment_status_preorders['id'].'">'.$shipment_status_preorders['id'].'</option>';
				}
			}
			echo '</select>';

}

function ik_preorders_pdf() {
	global $post;
	// Nonce field to validate form request came from current site
	wp_nonce_field( basename( __FILE__ ), 'preorders_fields' );
	$databoxes = get_post_meta( $post->ID, 'ik_preorders_pdf_url', true );
	// Output the field
	if ( $databoxes == NULL || $databoxes == '' || $databoxes == false){
		$databoxes = ""; 
	}
	echo '
	<label><input type="url" name="ik_preorders_pdf" id="ik_preorders_pdf" placeholder="Enter URL" value ="' . esc_url($databoxes)  . '" class="widefat"></label>';
}

// Save option for metaboxes

function ik_save_preorders_meta( $post_id, $post ) {
	// Return if the user doesn't have edit permissions.
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return $post_id;
	}
	if (isset($_POST['preorders_fields'])){
    	if ( ! wp_verify_nonce( $_POST['preorders_fields'], basename(__FILE__) ) ) {
    		return $post_id;
    	}
        
		//I check if product is variable or not
		if (isset($_POST['ik_preorders_product_variable'])){
			update_post_meta( $post_id, 'ik_preorders_product_variable', 'yes' );

			if (isset($_POST['ik_preorders_name_var'])){

				if (is_array($_POST['ik_preorders_name_var'])){

					foreach ($_POST['ik_preorders_name_var'] as $key => $name){

						$variable_data[$key]['name'] = sanitize_text_field($name);
						$variable_data[$key]['regular_price'] = (isset($_POST['ik_preorders_regular_price_var'][$key])) ? floatval( $_POST['ik_preorders_regular_price_var'][$key]) : 0;
						$variable_data[$key]['sale_price'] = (isset($_POST['ik_preorders_sale_price_var'][$key])) ? floatval( $_POST['ik_preorders_sale_price_var'][$key]) : 0;
						$variable_data[$key]['price'] = ($variable_data[$key]['sale_price'] > 0) ? $variable_data[$key]['sale_price'] : $variable_data[$key]['regular_price'];
						$variable_data[$key]['shipping_price'] = (isset($_POST['ik_preorders_shipping_price_var'][$key])) ? floatval( $_POST['ik_preorders_shipping_price_var'][$key]) : 0;
						$variable_data[$key]['enable_ups'] = (isset($_POST['ik_preorders_enable_ups_var'][$key])) ? intval( $_POST['ik_preorders_enable_ups_var'][$key]) : 0;
						$variable_data[$key]['allow_qty'] = (isset($_POST['ik_preorders_allow_quantity_var'][$key])) ? intval( $_POST['ik_preorders_allow_quantity_var'][$key]) : 0;
						$variable_data[$key]['max_qty'] = (isset($_POST['ik_preorders_max_quantity_var'][$key])) ? intval( $_POST['ik_preorders_max_quantity_var'][$key]) : 0;
						$variable_data[$key]['allow_qty_disc'] = (isset($_POST['ik_preorders_allow_discount_var'][$key])) ? intval( $_POST['ik_preorders_allow_discount_var'][$key]) : 0;
						$variable_data[$key]['qty_discount'] = (isset($_POST['ik_preorders_quantity_discount_var'][$key])) ? intval( $_POST['ik_preorders_quantity_discount_var'][$key]) : 0;
						$variable_data[$key]['percent_qty_dic'] = (isset($_POST['ik_preorders_percentage_discount_var'][$key])) ? floatval( $_POST['ik_preorders_percentage_discount_var'][$key]) : 0;
						$variable_data[$key]['weight'] = (isset($_POST['ik_preorders_weight_var'][$key])) ? floatval( $_POST['ik_preorders_weight_var'][$key]) : 0;
						$variable_data[$key]['dimensions'] = (isset($_POST['ik_preorders_dimensions_var'][$key])) ? sanitize_text_field( $_POST['ik_preorders_dimensions_var'][$key]) : '';

					}
					
					if (isset($variable_data)){
						update_post_meta( $post_id, 'ik_preorders_product_variable_data', $variable_data );
					} else {
						update_post_meta( $post_id, 'ik_preorders_product_variable_data', 3 );
					}
				} else {
					update_post_meta( $post_id, 'ik_preorders_product_variable_data', 2 );
				}
			} else {
				update_post_meta( $post_id, 'ik_preorders_product_variable_data', 1 );
			}

		} else {
			update_post_meta( $post_id, 'ik_preorders_product_variable', 'no' );
			if (isset($_POST['ik_preorders_regular_price'])){
				$preordermeta['ik_preorders_regular_price'] = floatval( $_POST['ik_preorders_regular_price'] );
			}
			if (isset($_POST['ik_preorders_sale_price'])){
				$preordermeta['ik_preorders_sale_price'] = floatval( $_POST['ik_preorders_sale_price'] );
			}
			if (isset($_POST['ik_preorders_shipping_price'])){
				$preordermeta['ik_preorders_shipping_price'] = floatval( $_POST['ik_preorders_shipping_price'] );
			}
		}
	
		if (isset($_POST['ik_preorders_pdf'])){
			$preordermeta['ik_preorders_pdf_url'] = esc_url( $_POST['ik_preorders_pdf'] );
		} else {
			delete_post_meta('ik_preorders_pdf_url');
		}

		if (isset($_POST['ik_preorders_dimensions'])){
			$preordermeta['ik_preorders_dimensions'] = sanitize_text_field( $_POST['ik_preorders_dimensions'] );
		} else {
			delete_post_meta('ik_preorders_dimensions');
		}
		if (isset($_POST['ik_preorders_weight'])){
			$preordermeta['ik_preorders_weight'] = floatval( $_POST['ik_preorders_weight'] );
		} else {
			delete_post_meta('ik_preorders_weight');
		}

		if (isset($_POST['ik_promotional_text'])){
			$ik_promotional_content = htmlentities( $_POST['ik_promotional_text'] );
			$preordermeta['ik_promotional_text'] = sanitize_textarea_field($ik_promotional_content);
		}
		if (isset($_POST['ik_preorders_available'])){
			$preordermeta['ik_preorders_available'] = 'yes';
		} else {
			delete_post_meta( $post_id, 'ik_preorders_available' );
		}
		if (isset($_POST['ik_preorders_hide'])){
			$preordermeta['ik_preorders_hide'] = 'yes';
		} else {
			delete_post_meta( $post_id, 'ik_preorders_hide' );
		}
		if (isset($_POST['ik_preorders_is_certified'])){
			$preordermeta['is_certified'] = 'yes';
		} else {
			delete_post_meta( $post_id, 'is_certified' );
		}
		
		if (isset($_POST['ik_preorders_use_woocommerce'])){
			$preordermeta['use_woocommerce'] = 'yes';
		} else {
			delete_post_meta( $post_id, 'use_woocommerce' );
		}

		if (isset($_POST['ik_preorders_shipment_status'])){
			$preordermeta['ik_preorders_shipment_status'] = absint( $_POST['ik_preorders_shipment_status'] );
		} else {
			delete_post_meta( $post_id, 'ik_preorders_shipment_status' );
		}
		if (isset($_POST['ik_preorders_allow_quantity'])){
			$preordermeta['ik_preorders_allow_quantity'] = absint( $_POST['ik_preorders_allow_quantity'] );
		} else {
			delete_post_meta( $post_id, 'ik_preorders_allow_quantity' );
		}
		if (isset($_POST['ik_preorders_max_quantity'])){
			$preordermeta['ik_preorders_max_quantity'] = absint( $_POST['ik_preorders_max_quantity'] );
		} else {
			delete_post_meta( $post_id, 'ik_preorders_max_quantity' );
		}
		if (isset($_POST['ik_preorders_enable_ups'])){
			$preordermeta['ik_preorders_enable_ups'] = absint( $_POST['ik_preorders_enable_ups'] );
		} else {
			delete_post_meta( $post_id, 'ik_preorders_enable_ups' );
		}
		if (isset($_POST['ik_preorders_allow_discount'])){
			$preordermeta['ik_preorders_allow_discount'] = absint( $_POST['ik_preorders_allow_discount'] );
		} else {
			delete_post_meta( $post_id, 'ik_preorders_allow_discount' );
		}
		if (isset($_POST['ik_preorders_quantity_discount'])){
			$preordermeta['ik_preorders_quantity_discount'] = absint( $_POST['ik_preorders_quantity_discount'] );
		} else {
			delete_post_meta( $post_id, 'ik_preorders_quantity_discount' );
		}
		if (isset($_POST['ik_preorders_percentage_discount'])){
			$preordermeta['ik_preorders_percentage_discount'] = floatval( $_POST['ik_preorders_percentage_discount'] );
		} else {
			delete_post_meta( $post_id, 'ik_preorders_percentage_discount' );
		}

		if (isset($preordermeta)){
			foreach ( $preordermeta as $key => $value ){
				// Don't store custom data twice
				if ( 'revision' === $post->post_type ) {
					return;
				}
				
				update_post_meta( $post_id, $key, $value );
				
				if ( ! $value ) {
					// Delete the meta key if there's no value
					delete_post_meta( $post_id, $key );
				}
			}
		}
    
	}
}
add_action( 'save_post', 'ik_save_preorders_meta', 1, 2 );

//ajax to refresh data about actual variation ID selected on preorders page
add_action('wp_ajax_nopriv_ik_hnaturals_ajax_variation_attr', 'ik_hnaturals_ajax_variation_attr');
add_action( 'wp_ajax_ik_hnaturals_ajax_variation_attr', 'ik_hnaturals_ajax_variation_attr');
function ik_hnaturals_ajax_variation_attr(){

	$preorder_id = (isset($_POST['preorder_id'])) ? absint($_POST['preorder_id']) : 0;
	$variation_id = (isset($_POST['variation_id'])) ? absint($_POST['variation_id']) : 0;

	$data['shipping'] = ik_hnaturals_show_shipping_data_form($preorder_id, $variation_id); 
	$data['qty'] = ik_hnaturals_show_quantity_input_selector($preorder_id, $variation_id); 

    echo json_encode( $data );
    wp_die();
}

//ajax to send customer to Melio from preorders page
add_action('wp_ajax_nopriv_ik_hnaturals_ajax_order_preorder', 'ik_hnaturals_ajax_order_preorder');
add_action( 'wp_ajax_ik_hnaturals_ajax_order_preorder', 'ik_hnaturals_ajax_order_preorder');
function ik_hnaturals_ajax_order_preorder(){
	//result redirect send
	$result = 'Error';
	$send = 'Please, contact support at '.get_option('admin_email');

	if (isset($_POST['preorder_id']) && isset($_POST['variation']) && 
	isset($_POST['liftgate']) && isset($_POST['name']) && isset($_POST['lastname']) && 
	isset($_POST['company']) && isset($_POST['country']) && isset($_POST['state']) && 
	isset($_POST['address']) && isset($_POST['city']) && isset($_POST['zip']) && 
	isset($_POST['phone']) && isset($_POST['email']) && isset($_POST['qty'])){
		
		$preorderid = absint($_POST['preorder_id']);

		$preorder = get_post($preorderid);

		if ($preorder !== NULL && $preorder !== false){

			$liftgate = ($_POST['liftgate'] ===  '0') ? '* Lift gate NOT required' : '* Requires lift gate.';
			$variation_id = absint($_POST['variation']);
			$quantity = (absint($_POST['qty']) !== 0) ? absint($_POST['qty']) : 1;
			$email = sanitize_email($_POST['email']);
			$user_firstname = sanitize_text_field($_POST['name']);
			$user_lastname = sanitize_text_field($_POST['lastname']);
			$billing_company = sanitize_text_field($_POST['company']);
			$email_customer = sanitize_text_field($_POST['email']);
			$billing_phone = sanitize_text_field($_POST['phone']);
			$billing_address = sanitize_text_field($_POST['address']);
			$billing_city = sanitize_text_field($_POST['city']);
			$billing_state = sanitize_text_field($_POST['state']);
			$billing_postcode = sanitize_text_field($_POST['zip']);
			$billing_country = ($_POST['country'] !== 'CA') ? 'US' : 'CA';


			//I get price and product name
			$variable_product = get_post_meta($preorderid, 'ik_preorders_product_variable', true);

			if ($variable_product == 'yes'){
				$title_product = $preorder->post_title;

				//Data to check discount per quantity
				$product_variable_data = get_post_meta($preorderid, 'ik_preorders_product_variable_data', true);
				$qty_allowed = (isset($product_variable_data[$variation_id]['allow_qty'])) ? absint($product_variable_data[$variation_id]['allow_qty']) : 0;
				$qty_desc_allow = (isset($product_variable_data[$variation_id]['allow_qty_disc'])) ? absint($product_variable_data[$variation_id]['allow_qty_disc']) : 0;
				$qty_desc_qty = (isset($product_variable_data[$variation_id]['qty_discount'])) ? absint($product_variable_data[$variation_id]['qty_discount']) : 0;
				$qty_desc_percent = (isset($product_variable_data[$variation_id]['percent_qty_dic'])) ? floatval($product_variable_data[$variation_id]['percent_qty_dic']) : 0;

				//I check shipping
				$shipping_price = (isset($product_variable_data[$variation_id]['shipping_price'])) ? floatval($product_variable_data[$variation_id]['shipping_price']) : 0;
				$enable_ups = (isset($product_variable_data[$variation_id]['enable_ups'])) ? absint($product_variable_data[$variation_id]['enable_ups']) : 0;	

				//I calculate total		
            	$product_variable_data = get_post_meta($preorderid, 'ik_preorders_product_variable_data', true);

				if (is_array($product_variable_data) && isset($product_variable_data[$variation_id]['price'])){
					$total = $product_variable_data[$variation_id]['price'];	
					$title_product .= ' - '.$product_variable_data[$variation_id]['name'];	
				}
 
			} else {
				$sale_price = get_post_meta($preorderid, 'ik_preorders_sale_price', true);
				$regular_price = get_post_meta($preorderid, 'ik_preorders_regular_price', true);
				$total = ($sale_price > 0) ? floatval($sale_price) : floatval($regular_price);
				$title_product = $preorder->post_title;

				//data to check discount per quantity
				$qty_desc_allow = absint(get_post_meta($preorderid, 'ik_preorders_allow_discount', true));
				$qty_desc_qty = absint(get_post_meta($preorderid, 'ik_preorders_quantity_discount', true));
				$qty_desc_percent = floatval(get_post_meta($preorderid, 'ik_preorders_percentage_discount', true));

				//I check shipping

				$shipping_price = floatval(get_post_meta($preorderid, 'ik_preorders_shipping_price', true));
				$enable_ups = get_post_meta($preorderid, 'ik_preorders_enable_ups', true);

				$shipping_price = ($shipping_price > 0) ? $shipping_price : 0;
				$enable_ups = (absint($enable_ups) == 1) ? 1 : 0;	

			}

			//I check if there is a discount per quantity
			if ($qty_desc_allow == 1 && $qty_desc_qty <= $quantity && $qty_desc_percent > 0){
				//I apply discount
				$total = $total - (($total*$qty_desc_percent)/100);
			}
			update_option('testqty', 'qa: '.$qty_desc_allow.', qdesc:'.$qty_desc_qty.', desc: '.$qty_desc_percent);

				
			//I create a temporal product
			global $wpdb;
			$data_product  = array (
					'id' => NULL,
					'post_type'=>'product', 
					'post_author'=>1, 
					'post_title'=>$title_product,
					'post_date'=>date('Y-m-d H:i:s'), 
					'post_date_gmt'=> date('Y-m-d H:i:s'), 
					'post_status'=> 'publish', 
					'comment_status'=> 'closed', 
					'ping_status'=> 'closed'
			);

			$tableInsert = $wpdb->prefix.'posts';
			$result_prod = $wpdb->insert($tableInsert,  $data_product , $format = NULL);
			$ik_prodid = $wpdb->insert_id;

			if ($ik_prodid > 0){

				// Create post meta for order
				global $woocommerce;

				$customer_data = array(
					'first_name'  => $user_firstname,
					'last_name'  => $user_lastname,
					'company'    => $billing_company,
					'email'      => $email_customer,
					'phone'      => $billing_phone,
					'address_1'  => $billing_address,
					'address_2'  => '',
					'city'       => $billing_city,
					'state'      => $billing_state,
					'postcode'   => $billing_postcode,
					'country'    => $billing_country,
				);

				// Create post meta for product
				add_post_meta($ik_prodid, '_price', $total);
				add_post_meta($ik_prodid, '_regular_price', $total);
				add_post_meta($ik_prodid, '_stock_status', 'instock');
				add_post_meta($ik_prodid, '_stock', NULL);

					
				// I create the order
				$order = wc_create_order();
				$ik_orderid = $order->get_id();

				// I add the product associated to the order
				$product_translax = wc_get_product( $ik_prodid );
				$order->add_product( $product_translax, $quantity );

				if ($shipping_price > 0){
					$item_ship = new WC_Order_Item_Shipping();

					$shipping_name = ($enable_ups == 1) ? 'UPS Shipping' : 'Shipping';

					$item_ship->set_name( $shipping_name );
					$item_ship->set_total( $shipping_price );

					// Add Shipping item to the order
					$order->add_item( $item_ship );
				}

				//Update total of order
				$order->calculate_totals();
				$order->set_address($customer_data, 'billing');
				$order->update_status( 'pending' );

				$order_key = $order->get_order_key();
				
				//Save data of order
				$order_id = $order->save();
				
				//add postmeta to disable some payment methods if preorders
				add_post_meta($order_id, 'preorder_order', 'yes');

				//if it is through Woocommerce
				$use_woocommerce = (get_post_meta($preorderid, 'use_woocommerce', true) == 'yes') ? true : false ;
				
				if ($use_woocommerce){
					$permalink = wc_get_checkout_url().'/'.get_option('woocommerce_checkout_pay_endpoint').'/'.$order_id.'/?pay_for_order=true&key='.$order_key;
					
				} else 	{
					$permalink = esc_url(get_the_permalink($preorderid)).'?key='.$order_key;
				}

			}
			
			$result = 'redirect';
			$send = $permalink;

			//I add liftgate details to the order
			add_post_meta($ik_orderid, 'liftgate', $liftgate);

			//Send email
			WC()->mailer()->get_emails()['WC_Email_New_Order']->trigger( $ik_orderid );
		}

	}

	$data['result'] = $result; 
	$data['send'] = $send; 

    echo json_encode( $data );
    wp_die();
}

// if order is preorder I disable payment method
add_filter('woocommerce_available_payment_gateways','ik_hnaturals_disable_payment_methods',1);
function ik_hnaturals_disable_payment_methods( $gateways ) {
    global $woocommerce; 
	$disable_payments_for_preorders = false;
	
	if(isset($_GET['key'])){
		
		$order_key = sanitize_key($_GET['key']);
		
		if($order_key){
		
			$order_id = wc_get_order_id_by_order_key($order_key);
			
			if($order_id){

				$preorder_order = (get_post_meta($order_id, 'preorder_order', true) == 'yes') ? true : false ;
				
				if($preorder_order){
					//Disable payment methods for preorders
					$disable_payments_for_preorders = true;
				}
			}
		}
	}

	if($disable_payments_for_preorders){
		unset($gateways['amazon_payments_advanced']);
	} else {
		unset($gateways['ik_meliopg']);		
	}
	
    return $gateways;
}

//I add lift gate that if exists on the order page
add_filter( 'woocommerce_admin_order_data_after_shipping_address' , 'ik_hnaturals_order_show_liftgate' );
function ik_hnaturals_order_show_liftgate( $order ) {
    if( $value = $order->get_meta('liftgate') ){
        echo '<p style="font-size: 20px"><strong>Liftgate:</strong> '.$order->get_meta('liftgate').'</p>';
    }
}

//I add menu options for custom code
add_action('admin_menu', 'ik_hatton_preorder_shipments');
function ik_hatton_preorder_shipments(){
    add_submenu_page('edit.php?post_type=preorders', 'Shipments Status', 'Shipments Status', 'manage_options', 'ik_hatton_shipment_status', 'ik_hatton_shipment_status');
}

//I add an option to add shipments status for preorder sales
function ik_hatton_shipment_status(){
	if ($_SERVER['REQUEST_METHOD'] == 'POST'){
		if (isset($_POST['shipment_status']) && isset($_POST['eta']) && 
		isset($_POST['status']) && isset($_POST['next_stage']) && 
		isset($_POST['fullfilment_date'])){

			$shipment_id = absint($_POST['shipment_status']);

			if ($shipment_id == 0){
				//I create a code for the shipment
				$shipmentdigits = random_int(1000, 9999);
            	$timenow_digits = strtotime(date("Y/m/d"));
            	$shipment_id = strtoupper($shipmentdigits.$timenow_digits);
			}

			$eta = date('F d, Y',strtotime($_POST['eta']));
			$fullfilment_date = date('F d, Y',strtotime($_POST['fullfilment_date']));
			$status = sanitize_text_field($_POST['status']);
			$status = str_replace("\\", "", $status);
			$next_stage = sanitize_text_field($_POST['next_stage']);
			$next_stage = str_replace("\\", "", $next_stage);

			$data_shipment_status = array(
				'id' => $shipment_id,
				'eta' => $eta,
				'fullfilment_date' => $fullfilment_date,
				'status' => $status,
				'next_stage' => $next_stage,
			);

			update_option('ik_hatton_shipment_status_'.$shipment_id, $data_shipment_status);

		} else if (isset($_POST['shipment_status_id_to_delete'])){
			$shipment_status_id = absint($_POST['shipment_status_id_to_delete']);
			delete_option('ik_hatton_shipment_status_'.$shipment_status_id);
		}
	}
wp_enqueue_style( 'select2-css', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', array(), '4.1.0-rc.0');

//Add the Select2 JavaScript file
wp_enqueue_script( 'select2-js', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', 'jquery', '4.1.0-rc.0');

?>
<style>
    #ik_hatton_panel_form_shipment_status label, #ik_hatton_panel_form_shipment_status span, #ik_hatton_panel_form_shipment_status div, #ik_hatton_panel_form_shipment_status input{
        display: block! important;
    }
    #ik_hatton_panel_form_shipment_status label{
        margin: 25px 0;
    }
    #ik_hatton_panel_form_shipment_status .select2-container, #ik_hatton_add_productid_select, #ik_hatton_panel_form_shipment_status .select2-chosen{
        margin-top: 0px;
        width: 250px! important;
        max-width: 250px! important;
    }
    #ik_hatton_panel_form_shipment_status{
        margin-bottom: 25px;
        margin-top: 30px;
    }
    #ik_hatton_panel_form_shipment_status .select2-chosen{
        min-width: 250px;
    }
	#ik_hatton_panel_form_shipment_status div {
		margin: 4px 0;
		display: block! important;
		float: left;
	}
	#ik_hatton_panel_form_shipment_status .status_preorders_form_part{
		min-width: 350px;
		width: 40%;
	}
	#ik_hatton_panel_form_shipment_status .status_preorders_table_part{
		min-width: 650px;
		width: 60%;
	}
	#ik_hatton_panel_form_shipment_status .status_preorders_table_part th, #ik_hatton_panel_form_shipment_status .status_preorders_table_part td{
		border: 1px solid #ccc;
		padding: 7px;
	}
	#ik_hatton_panel_form_shipment_status .status_preorders_table_part td:last-child{
		border-width: 0px;
	}
 	#ik_hatton_panel_form_shipment_status .status_preorders_table_part td:last-child input[type=submit]{
		border-width: 0px;
		color: red;
		cursor: pointer;
	}
    #ik_hatton_panel_form_shipment_status input[type=text], #ik_hatton_panel_form_shipment_status input[type=date]{
        max-width: 250px;
        width: 100%;
        font-size: 12px;
    }
    #ik_hatton_panel_form_shipment_status .select2-with-searchbox{
        display: none! important;
    }
    @media (max-width: 550px){
        #ik_hatton_panel_form_shipment_status .select2-chosen{
            min-width: 280px! important;
        }        
    }
</style>
<div id="ik_hatton_panel_form_shipment_status">
    <h1>Shipment Status</h1>
	<?php
	$shipments_status_preorders = ik_hnaturals_get_shipment_status();
	?>
	<div class="status_preorders_form_part">
		<form action="" method="post" enctype="multipart/form-data" autocomplete="no">
			<label for="select_status">
				<span>Shipment ID</span>
				<select required name="shipment_status">
					<option value="0">New Shipment</option>
					<?php
					if (is_array($shipments_status_preorders)){
						foreach ($shipments_status_preorders as $shipment_status_preorders){
							echo '<option value="'.$shipment_status_preorders['id'].'">'.$shipment_status_preorders['id'].'</option>';
						}
					}
					?>
				</select>
			</label>
			<label for="eta_date">
				<span>ETA</span>
				<input required type="date" name="eta" />
			</label>
			<label for="status">
				<span>Status</span>
				<input required type="text" name="status" />
			</label>
			<label for="next_stage">
				<span>Next Stage</span>
				<input required type="text" name="next_stage" />
			</label>
			<label for="fullfilment_date">
				<span>Fulfillment estimated date</span>
				<input required type="date" name="fullfilment_date" />
			</label>
			<input type="submit" class="button-primary" value="Save">
		</form>
	</div>
	<div class="status_preorders_table_part">
	<?php
	if (is_array($shipments_status_preorders)){
		echo '<table>
				<tr>
				<th>ID</th>
				<th>ETA</th>
				<th>Status</th>
				<th>Next Stage</th>
				<th>FE Date</th>
				</tr>';
		foreach ($shipments_status_preorders as $shipment_status_preorders){
			echo '
				<tr>
					<td>'.$shipment_status_preorders['id'].'</td>
					<td>'.$shipment_status_preorders['eta'].'</td>
					<td>'.$shipment_status_preorders['status'].'</td>
					<td>'.$shipment_status_preorders['next_stage'].'</td>
					<td>'.$shipment_status_preorders['fullfilment_date'].'</td>
					<td>
						<form action="" method="post" enctype="multipart/form-data">
							<input type="hidden" name="shipment_status_id_to_delete" value="'.$shipment_status_preorders['id'].'">
							<input type="submit" class="primary-btn" value="❌">
						</form>
					</td>
				</tr>';
		}
		echo '</table>';
	}
	?>
	</div>
</div>
<script>
jQuery(document).ready(function($) {
    jQuery('#ik_hatton_panel_form_shipment_status select').select2({theme: 'classic'});
});
</script>
<?php
}



//Function to show quantity hidden input or selector depending on preorder variation
function ik_hnaturals_show_quantity_input_selector($preorder_id, $variation_id){
	$preorder_id = absint($preorder_id);
	$variation_id = absint($variation_id);
	
	//I get preorder data
	$product_variable_data = get_post_meta($preorder_id, 'ik_preorders_product_variable_data', true);

	if (is_array($product_variable_data)){
		$qty_max = (isset($product_variable_data[$variation_id]['max_qty'])) ? absint($product_variable_data[$variation_id]['max_qty']) : 0;
		$qty_allowed = (isset($product_variable_data[$variation_id]['allow_qty'])) ? absint($product_variable_data[$variation_id]['allow_qty']) : 0;
		$qty_desc_allow = (isset($product_variable_data[$variation_id]['allow_qty_disc'])) ? absint($product_variable_data[$variation_id]['allow_qty_disc']) : 0;
		$qty_desc_qty = (isset($product_variable_data[$variation_id]['qty_discount'])) ? absint($product_variable_data[$variation_id]['qty_discount']) : 0;
		$qty_desc_percent = (isset($product_variable_data[$variation_id]['percent_qty_dic'])) ? floatval($product_variable_data[$variation_id]['percent_qty_dic']) : 0;

	} else {
		//is a single product without variations
		$product_simple_qty_allow = get_post_meta($preorder_id, 'ik_preorders_allow_quantity', true);
		$product_simple_qty_max = get_post_meta($preorder_id, 'ik_preorders_max_quantity', true);
		$qty_desc_allow = absint(get_post_meta($preorder_id, 'ik_preorders_allow_discount', true));
		$qty_desc_qty = absint(get_post_meta($preorder_id, 'ik_preorders_quantity_discount', true));
		$qty_desc_percent = floatval(get_post_meta($preorder_id, 'ik_preorders_percentage_discount', true));

		$qty_max = (absint($product_simple_qty_max) > 1) ? $product_simple_qty_max : 1;
		$qty_allowed = (absint($product_simple_qty_allow) == 1) ? $product_simple_qty_allow : 0;	
	}

	//If quantity is more than 1
	if ($qty_max > 1 && $qty_allowed == 1){

		//I check if there is a discount per quantity
		if ($qty_desc_allow == 1 && $qty_desc_qty > 1 && $qty_desc_percent > 0){
			$qty_discount = $qty_desc_qty;
		} else {
			$qty_discount = 0;
		}

		$qty_selector = '<select name="preorder_qty_select" id="preorder_qty" class="wpcf7-form-control wpcf7-select">';
		$qty_selector .= '<option value="1">Quantity: 1 Unit</option>';
		for ($i = 2; $i <= $qty_max; $i++) {

			//in case there's a discount per quantity
			$text_discount = ($qty_discount <= $i && $qty_discount != 0) ? ' ('.$qty_desc_percent.'% OFF)' : '';

			$qty_selector .= '<option value="'.$i.'">Quantity: '.$i.' Units'.$text_discount.'</option>';
		}
		$qty_selector .= '</select>';
	}	

	if (isset($qty_selector)){
		$qty_field = $qty_selector;
	} else {
		$qty_field = '<input type="hidden" id="preorder_qty" name="preorder_qty" value="1">';
	}

	return $qty_field;
}


//Function to show shipping details at the end of the preorders form
function ik_hnaturals_show_shipping_data_form($preorder_id, $variation_id){
	$preorder_id = absint($preorder_id);
	$variation_id = absint($variation_id);

	$shipping_data_default = '<p id="liftgate_select">Lift gate required? <label><input type="radio" class="liftgate_select_option" name="liftgate_select_option" value="1">Yes</label> <label><input type="radio" class="liftgate_select_option" name="liftgate_select_option" checked value="0">No</label></p><p class="shipping_message">Please note a shipping invoice will be sent for payment when the order is ready to ship. Order will be shipped once shipping invoice is paid.</p>';
	
	//I get preorder data
	$product_variable_data = get_post_meta($preorder_id, 'ik_preorders_product_variable_data', true);
	if (is_array($product_variable_data)){

		$shipping_price = (isset($product_variable_data[$variation_id]['shipping_price'])) ? floatval($product_variable_data[$variation_id]['shipping_price']) : 0;
		$enable_ups = (isset($product_variable_data[$variation_id]['enable_ups'])) ? absint($product_variable_data[$variation_id]['enable_ups']) : 0;

	} else {
		//is a simple product
		$shipping_price = floatval(get_post_meta($preorder_id, 'ik_preorders_shipping_price', true));
		$enable_ups = absint(get_post_meta($preorder_id, 'ik_preorders_enable_ups', true));

		$shipping_price = ($shipping_price > 0) ? $shipping_price : 0;
		$enable_ups = (absint($enable_ups) == 1) ? 1 : 0;	

	}

	if ($shipping_price == 0 && $enable_ups == 0){
		$shipping = $shipping_data_default;
	} else {
		if ($enable_ups !== 0){
			if ($shipping_price > 0){
				$shipping = '<p style="text-align: center;">UPS Shipping Price: $'.$shipping_price.'</p>';
			} else {
				$shipping = '<p>Please note a shipping invoice will be sent for payment when the order is ready to ship. Order will be shipped through UPS once shipping invoice is paid.</p>';
			}
		} else {
			$shipping = '<p>Shipping Price: $'.$shipping_price.'</p>';
		}
	}

	if (isset($shipping)){
		$shipping_data = $shipping;
	} else {
		$shipping_data = $shipping_data_default;
	}

	return $shipping_data;
}


//function to get preorders existing shipment status
function ik_hnaturals_get_shipment_status($shipment_status_id = '%'){
	if ($shipment_status_id !== '%'){
		$shipment_status_id = sanitize_text_field($shipment_status_id);
	}

	global $wpdb;
	$shipment_status_query = "SELECT * FROM ".$wpdb->prefix."options WHERE option_name LIKE 'ik_hatton_shipment_status_".$shipment_status_id."' ORDER BY option_id DESC";
	$shipments_status = $wpdb->get_results($shipment_status_query);
	
	// I assign values for comments from admin and translator
	if (isset($shipments_status[0]->option_id)){
		foreach ($shipments_status as $shipment_status){
			if (is_serialized($shipment_status->option_value)){
				$shipment_status_array[] = maybe_unserialize($shipment_status->option_value);
			}
		}
		if (isset($shipment_status_array)){
			return $shipment_status_array;
		}
	}

	return false;
}

/**
*	End of Preorders
*/

?>