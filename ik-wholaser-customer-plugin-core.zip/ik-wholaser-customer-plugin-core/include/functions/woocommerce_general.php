<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Woocommerce General Functions 
Created: 02/03/2023
Last Update: 10/04/2023
Author: Gabriel Caroprese
*/

add_filter('woocommerce_after_lost_password_form', 'hn_reset_form_passw' );
function hn_reset_form_passw() { 
	$textsupport = "<p>Remember: You can always contact us at support@hattonnaturals.com .</p>";
  	echo $textsupport; 
}

// Get search results from only products
add_action( 'pre_get_posts', 'hn_search_woocommerce_only' );

function hn_search_woocommerce_only( $query ) {
  	if( ! is_admin() && is_search() && $query->is_main_query() ) {
    	$query->set( 'post_type', 'product' );
  	}
}

add_filter ( 'woocommerce_account_menu_items', 'hn_remove_downloads_link' );
function hn_remove_downloads_link( $menu_links ){
	unset( $menu_links['dashboard'] ); // Disable Downloads
	unset( $menu_links['downloads'] ); // Disable Downloads
	return $menu_links;
}

// Display orders page instead of dashboard from My Account

add_action( 'parse_request', 'hn_redirect_to_my_account_orders' );
function hn_redirect_to_my_account_orders( $wp ) {
    // All other endpoints such as change-password will redirect to
    // my-account/orders
    $allowed_endpoints = [ 'orders', 'edit-account', 'payment-methods', 'add-payment-method', 'edit-address', 'customer-logout', 'lost-password' ];

    if (preg_match( '%^my\-account(?:/([^/]+)|)/?$%', $wp->request, $m ) &&
        ( empty( $m[1] ) || ! in_array( $m[1], $allowed_endpoints ) )) {
        wp_redirect( get_site_url().'/my-account/orders/' );
        exit;
    }
}

//Function to return options for products in stock or as backorder
function ik_hatton_list_options_products_in_stock(){

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
		'post_status' => 'publish',
    );

	$products = get_posts($args);
	$options_data_list = '';

	if( $products ){
		foreach( $products as $product ) {
			$product_name = str_replace('\"', '"', $product->post_title);
			$product_name = str_replace("\'", "'", $product_name);
			$product_name = str_replace("'", "&#39;", $product_name);
        	$options_data_list .= '<option value="'.$product_name.'">'.$product_name.'</option>';
		}
	}

    wp_reset_query();
    
    return $options_data_list;
}

//this function is to create a select that shows product categories
function hn_woo_select_product_categories( $required = false, $is_array = false, $selected_id = '0' ) {
	$required = (rest_sanitize_boolean($required) == true) ? 'required' : '';
	$is_array = (rest_sanitize_boolean($is_array) == true) ? '[]' : '';

	$selected_id = absint($selected_id);

	$args = array(
		'taxonomy' => 'product_cat',
		'hide_empty' => false,
	);
	$categories = get_terms( $args );

	$select_cats = '<select '.$required.' name="product_cat_id'.$is_array.'"><option selected disabled value="">Select Category</option>';

	foreach ( $categories as $category ) {
		$selectedMark = ($selected_id == $category->term_id) ? 'selected' : '';
		$select_cats .= '<option '.$selectedMark.' value="'.absint( $category->term_id ).'">'.strtoupper(esc_html( $category->name )).'</option>';
	}
	$select_cats .= '</select>';

	return $select_cats;

}

// Hide the variations with the meta key "hn_onlyws"
function hn_hide_ws_product_variations($is_visible, $variation_id) {

	//If product is set only for wholesale
	$disable_variation = true;
	if(is_user_logged_in()){
		$wholesale_role_slug = (get_option('HN_WHOLESALE_ROLE')) ? sanitize_text_field(get_option('HN_WHOLESALE_ROLE')) : 'default_wholesaler';
		$is_wholesale_user = in_array($wholesale_role_slug, wp_get_current_user()->roles);
		if(current_user_can('manage_options') || $is_wholesale_user){
			$disable_variation = false;
		}
	}

	if($disable_variation){
		$exclusive_for_ws = get_post_meta($variation_id, 'hn_onlyws', true);


		//Check if it's only for wholesale - admin also allowed
		if ($exclusive_for_ws === 'yes') {
			return false; // variation hidden for regular users
		}
		
	}

    return $is_visible; // we show variation if wholesale exclusivity doesn't apply
}
add_filter('woocommerce_variation_is_visible', 'hn_hide_ws_product_variations', 10, 2);

// Adjust the price range to exclude hidden variations
function hn_adjust_variation_price_range($price, $product) {
    // Get visible variations
    $visible_variations = array_filter($product->get_available_variations(), function ($variation) {
        return $variation['variation_is_visible'];
    });

    // Get prices of visible variations
    $prices = array_map(function ($variation) {
        return $variation['display_price'];
    }, $visible_variations);

    // Adjust price range based on visible variations
    if (count($prices) > 0) {
        $min_price = min($prices);
        $max_price = max($prices);
        $price = $min_price !== $max_price ? wc_format_price_range($min_price, $max_price) : wc_price($min_price);
    }

    return $price;
}
add_filter('woocommerce_variable_sale_price_html', 'hn_adjust_variation_price_range', 10, 2);
add_filter('woocommerce_variable_price_html', 'hn_adjust_variation_price_range', 10, 2);

/* 
	For Coupon X plugin when asking for coupong and leaving email 
	add email to cart session billing email
*/
function hn_add_email_for_coupon_script(){
    if ( ! is_user_logged_in() ) {
		?>
		<script>
		jQuery(document).ready(function($) {
			jQuery('.tab-box-content .coupon-email-button').on('click', function() {
				var email = jQuery('.coupon-code-email-text input[type=email]').val();
				jQuery.ajax({
					type: 'POST',
					url: '<?php echo admin_url('admin-ajax.php'); ?>',
					data: {
						action: 'hn_add_email_to_cart',
						email: email
					},
					success: function(response) {
						console.log(response);
					}
				});
			});
		});
		</script>
		<?php


	}
}
add_action('wp_footer', 'hn_add_email_for_coupon_script');
//ajax script
add_action('wp_ajax_nopriv_hn_add_email_to_cart', 'hn_add_email_to_cart');
function hn_add_email_to_cart() {
	if (class_exists('WooCommerce') && isset($_POST['email'])) {

		$email = sanitize_email($_POST['email']);

		// Verify email is correct
		if ($email) {
			// Add email too Woocommerce session
			if (!WC()->session->has_session()) {
				WC()->session->set_customer_session_cookie(true);
			}
			WC()->session->set('customer_email', $email);
			$response = 'Email added.';
			echo json_encode($response);
		}
	}
    wp_die();
}
//I add email on session to future order
add_filter('woocommerce_checkout_get_value', 'hn_check_and_set_customer_email', 10, 2);
function hn_check_and_set_customer_email($value, $input) {
	//if user not logged in and verify if customer_email was set
	if ( ! is_user_logged_in() && WC()->session->__isset('customer_email') ) {
		if ($input === 'billing_email') {
			// get the email address input
			$email_session = WC()->session->get('customer_email');

			if ($email_session) {
				$value = $email_session;
			}
		}
	}

    return $value;
}
/*
	End script for coupon X plugin
*/

//delete select 2 for plugin Advanced Shipment Tracking for WooCommerce
add_action('admin_footer', 'hn_scripts_woocommerce_order');
function hn_scripts_woocommerce_order(){
	if(isset($_GET['post']) && isset($_GET['action'])){
		?>
		<script>
		jQuery(document).ready(function($) {
			setInterval(function(){
				jQuery('#add_tracking_number_form .tracking_provider_dropdown').select2('destroy');
			}, 300);
		});
		</script>
		<?php
	}
}
?>