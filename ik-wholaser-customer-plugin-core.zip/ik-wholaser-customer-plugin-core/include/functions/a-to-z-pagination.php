<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - A to Z filter for product archives
Created: 08/02/2023
Last Update: 08/10/2023
Author: Gabriel Caroprese
*/


function custom_alphabetical_pagination_links() {
    $alphabet = range('A', 'Z');
    echo '
    <style>
    .shop-header {
        padding-bottom: 25px;
        position: relative;
    }
    #hn_az_order_filter {
        position: absolute;
        bottom: -24px;
        width: 100%;
        left: 0px;
    }
    #hn_az_order_filter a {
        padding: 5px 11px;
    }
    #hn_az_order_filter a:not(.selected_letter) {
        color: #919C93;
        background: #F2F2EE;
    }
    #hn_az_order_filter a.selected_letter{
        background: #d6df26;
        color: #fff;
    }
    @media(max-width: 990px){
        .shop-sidebar {
            margin-top: 80px;
        }
        #hn_az_order_filter {
            bottom: -80px! important;
            padding: 0 20px;
        }
        #hn_az_order_filter_cancel{
            margin-top: 40px;
        }
    }
    @media(max-width: 1130px){
        #hn_az_order_filter a {
            font-size: 13.5px;
            margin-left: 2px;
        }
    }
    @media(min-width: 1130px){
        #hn_az_order_filter a {
            font-size: 18px;
            margin-left: 4px;
        }
    }
    @media(max-width: 400px){
        .shop-header {
            padding-bottom: 5em! important;
        }
    }
    </style>';
    $letter_selected = isset($_GET['letter']) ? substr(sanitize_text_field($_GET['letter']), 0, 1) : '';

    if($letter_selected != ''){
        echo '<div id="hn_az_order_filter_cancel">
        <a class="button" href="' . remove_query_arg('letter'). '">Show All</a> 
        </div>';
    }
    echo '<div id="hn_az_order_filter">';
    foreach ($alphabet as $letter) {
        $selected = ($letter_selected == $letter) ? 'class="selected_letter"' : '';
        echo '<a '.$selected.' href="' . esc_url(add_query_arg('letter', $letter)). '">' . $letter . '</a>';
    }
    echo '</div>';
}

function custom_alphabetical_pagination_query($query) {
    $letter = isset($_GET['letter']) ? substr(sanitize_text_field($_GET['letter']), 0, 1) : '';

    if ($letter) {
        global $wpdb;
        
        $custom_query = "SELECT ID FROM ".$wpdb->prefix."posts WHERE post_type = 'product' AND post_status = 'publish' AND ((post_title LIKE '".$letter."%' AND post_title NOT LIKE 'Organic%') OR post_title LIKE 'Organic ".$letter."%')";

        $results = $wpdb->get_results($custom_query);

        if (!empty($results)) {
            $query->set('post__in', wp_list_pluck($results, 'ID'));
        } else {
            // Si no hay resultados, establece un ID inválido para no mostrar nada
            $query->set('post__in', array(-1));
        }
    }
}
add_action('woocommerce_product_query', 'custom_alphabetical_pagination_query');



// Add custom function to output alphabetical pagination links
function custom_woocommerce_pagination() {
    custom_alphabetical_pagination_links();
}
add_action('woocommerce_before_shop_loop', 'custom_woocommerce_pagination', 10);

?>
