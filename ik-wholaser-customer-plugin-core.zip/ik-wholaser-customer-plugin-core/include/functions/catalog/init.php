<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Catalog functions Init 
Created: 03/29/2023
Last Update: 03/29/2023
Author: Gabriel Caroprese
*/

define( 'IK_HATTON_CORE_CATALOG_DIR', IK_HATTON_CORE_DIR.'/include/functions/catalog/includes/' );
define( 'IK_HATTON_CORE_CATALOG_PUBLIC_DIR', IK_HATTON_CORE_PUBLIC.'/include/functions/catalog/' );

require_once(IK_HATTON_CORE_CATALOG_DIR.'/catalog.class.php');


//Initialize class HN_PDF_Catalog_Sys
function ik_hn_catalog_init() {
    $HN_PDF_Catalog_Sys = new HN_PDF_Catalog_Sys();
}
add_action('init', 'ik_hn_catalog_init');


//Menu for Catalog
function ik_hn_catalog_admin_menu(){
    add_menu_page('Catalog', 'Catalog', 'manage_options', 'ik_hn_catalog_db_menu', 'ik_hn_catalog_db_menu', IK_HATTON_CORE_CATALOG_PUBLIC_DIR.'catalog-feat-menuicon.png' );
}
add_action('admin_menu', 'ik_hn_catalog_admin_menu');

/*
    Content for Catalog menu
                                    */
function ik_hn_catalog_db_menu(){
    include(IK_HATTON_CORE_DIR.'/include/templates/catalog_config.php');
}
?>