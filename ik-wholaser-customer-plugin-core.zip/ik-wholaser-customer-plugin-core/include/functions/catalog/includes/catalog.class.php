<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - HN_PDF_Catalog_Sys Class
Created: 04/05/2023
Last Update: 01/08/2024
Author: Gabriel Caroprese
*/

class HN_PDF_Catalog_Sys {

    private $logo_img;
    private $organic_logos_img;
    private $message_header;

    public function __construct(){

        $this->logo_img = IK_HATTON_CORE_DIR.'/img/hn_logo.jpg';
        $this->organic_logos_img = IK_HATTON_CORE_DIR.'/img/logos-certificate.jpg';
        $this->message_header = sanitize_text_field(get_option('ik_hn_catalog_message_header'));
        
        //to activate catalog generation when url attribute downloadpricelist exists
        add_action('template_redirect', array( $this, 'generate_pdf_file' ));
    }

  	//Function to return options for products in stock or as backorder
	private function generate_catalog_content(){

		$catalog_content = '';

		$args = array(
			'post_type' => 'product',
			'posts_per_page' => -1,
			'orderby' => 'menu_order', // or title
			'order' => 'ASC',
			'post_status' => 'publish',
		);

		$products = get_posts($args);
		$products_to_show = false;
		if( $products ){
			foreach( $products as $product_post ) {
				$product_id = $product_post->ID;
				$product = wc_get_product( $product_id );
				$price = floatval($product->get_price());
				if(isset($buy_in_stock)){
					unset($buy_in_stock);
				}

				if($product){
					//checking if variable product in stock
					if ($product->is_type('variable')) { // Verificamos si es un producto variable
						$variations = $product->get_available_variations();
						
						foreach ($variations as $variation) {
							$variation_product = wc_get_product($variation['variation_id']);
							$variation_price = floatval($variation_product->get_price());
				
							if (($variation_product->is_in_stock() || $variation_product->get_stock_quantity() > 0) && $variation_price > 0) {
								$buy_in_stock = true;
								break;
							} else if($product->backorders_allowed() && $price > 0) {
								$buy_in_stock = false;
								break; 
							}
						}
					} else {
						if (( $product->is_in_stock() || $product->get_stock_quantity() > 0) && $price > 0) {
							$buy_in_stock = true;
						} else if($product->backorders_allowed() && $price > 0) {
							$buy_in_stock = false;
						}
					}
					
					if(isset($buy_in_stock)){
		
						global $post;
						$terms = get_the_terms( $product_id, 'product_cat' );
						if($terms){
							foreach ($terms as $term) {
								$product_cat_name = $term->name;
								$product_cat_id = $term->term_id;
								break;
							}
						}
						$product_cat_id = (isset($product_cat_id)) ? absint($product_cat_id) : 0;
						
						if($product_cat_id > 0){
							$categories_catalog[absint($product_cat_id)] = array(
								'id' => absint($product_cat_id),
								'name' => $product_cat_name,
							);
							
							$products_catalog[] = array(
								'id' => $product_id,
								'category'=> absint($product_cat_id),
								'in_stock'=> $buy_in_stock,
							);
			
							$products_to_show = true;
						}
		
					}

				}
			
			}
			
		}

		if($products_to_show){

			foreach ($products_catalog as $product_catalog){
				if($this->get_product_details($product_catalog['id']) != false){

					$categories_catalog[absint($product_catalog['category'])]['products'][] = $product_catalog;

				}
			}
			
		}

		$date_effective = date('m-d-Y');  
		$date_expire = strtotime("+12 day", strtotime($date_effective));

		//I make sure is not weekend
		if(date('D', $date_expire) == 'Sat' || date('D', $date_expire) == 'Sun'){
			$date_expire = strtotime("+2 day", $date_expire);
		}
		$date_expire = date('Y/m/d', $date_expire);
		
		$css_style_pricelist = '	
        <style>
		html, body{
			padding: 0! important;
			margin: 0! important;
			display: block! important;
		}
		table {
			border-collapse: collapse;
			border-spacing: 0;
		}
		table, td, tbody, tr, th{
			border-width: 0px;
			border: 0px solid #000;
			padding: 0;
			margin: 0;
		}
		.page-break{
			max-width: 1140px! important;
			padding: 0 20px! important;
			width: 100%! important;
			margin: 0 auto! important;
			display: block! important;
		}
		.page-break {
			page-break-after: always;
		}
		.catalog_header, .catalog_header_right, .catalog_logo{
			border: 0px solid #000! important;
		}	
		.catalog_product_details:first-child:before {
			display:none! important;
		}
		.catalog_discount_message{
			width: 100%! important;
			font-size: 18px! important;
			text-align: center! important;
			font-weight: 600! important;
			color: red! important;
		}
		</style>';
		
		$catalog_content = '<!DOCTYPE html>
		<html>
			<head>
				<title>Wholesale Customer Pricelist '.date('Y-m-d').'</title>
			</head>
		<body>
			<div id="catalog_data">';
		$catalog_header = '
			<div class="page-break">'.$css_style_pricelist.'
				<table border="0" class="catalog_header" style="width: 100%; border: 0px solid #000! important">
					<tr border="0" style="border: 0px solid #000! important">
						<td border="0" class="catalog_logo" style="border: 0px solid #000! important">
							<img src="'.$this->logo_img.'" height="130">
						</td>
						<td border="0" class="catalog_header_right" style="border: 0px solid #000! important; text-align:center;">
								In Stock Price List<br>
								Date: '.$date_effective.'<br>
								<img src="'.$this->organic_logos_img.'" width="185">
						</td>
					</tr>
					<tr border="0" style="border: 0px solid #000! important">
						<td style="text-align: center! important;font-weight: 600! important;color: #ff0000! important;">'.$this->message_header.'</td>
					</tr>
				</table>
				<div class="catalog_list">
				<p>&nbsp;</p>';
		$catalog_footer = '
				</div>
				<p>&nbsp;</p>
				<table border="0" class="catalog_footer" style="border:0px solid #000! important;width: 100%;">
					<tr border="0" style="border:0px solid #000! important">
						<td border="0" class="catalog-footer-left" style="border:0px solid #000! important;"><small>CONFIDENTIAL CUSTOM PRICE SHEET: Hatton Organics LLC</small></td>
						<td border="0" align="right" class="catalog-footer-right" style="text-align: right;border:0px solid #000! important;"><small>Pricing Subject To Change Without Notice</small></td>
					</tr>
				</table>
			</div>';

		$args_pixels = array(
			'header_pixels' => 165,
			'footer_pixels' => 80,
			'missing_pixels' => 990,
			'product_line' => 155.6,
			'wrapper_product_line' => 90,
			'category' => 45.6,
			'header_html' => $catalog_header,
			'footer_html' => $catalog_footer ,
		);


		$catalog_content .= $catalog_header;

		if(isset($products_catalog)){

			$index_cats = 9;
			foreach( $categories_catalog as $category_catalog ) {
				switch (absint($category_catalog['id'])) {
					//Botanicals first
					case 62:
						$categories[0] = $category_catalog;
						break;
					case 63:
						$categories[1] = $category_catalog;
						break;
					case 6:
						$categories[2] = $category_catalog;
						break;
					case 64:
						$categories[3] = $category_catalog;
						break;
					case 582:
						$categories[4] = $category_catalog;
						break;
					case 67:
						$categories[5] = $category_catalog;
						break;
					case 61:
						$categories[6] = $category_catalog;
						break;
					case 7:
						$categories[7] = $category_catalog;
						break;
					case 68:
						$categories[8] = $category_catalog;
						break;
					default:
						$categories[$index_cats] = $category_catalog;
				}
				$index_cats = $index_cats + 1;
			}

			ksort($categories);

			$pixels_count = 0;
			foreach( $categories as $category ) {

				if( isset($category['products'])){
					
					//Check change of page
					$pixels_count_aux = $pixels_count + floatval($args_pixels['category']) + 2*(floatval($args_pixels['product_line']));
					
					if($pixels_count_aux > floatval($args_pixels['missing_pixels'])  ){
						$spacemissing = floatval($args_pixels['missing_pixels'])  - $pixels_count - floatval($args_pixels['product_line']);

						$catalog_content .= $catalog_footer.$catalog_header;				
						$pixels_count = 0;

					} else {
						$pixels_count = $pixels_count + floatval($args_pixels['category']) + floatval($args_pixels['product_line']);
					}

					$catalog_content .= '
					<table border="0" class="catalog_category" style="border: 0px! important">
						<tr border="0" class="catalog_category_title">
							<td style="border: 0px solid #000! important;">
								<hr>
								<h2>'.$category['name'].'</h2>
								<hr>
							</td>
						</tr>
					</table>';
					foreach ($products_catalog as $product_catalog){
						if($category['id'] == $product_catalog['category']){
							$product_line = $this->get_product_details($product_catalog['id'], $args_pixels, $pixels_count);
							if(isset($product_line['html'])){
								$catalog_content .= $product_line['html'];
								$pixels_count = floatval($product_line['pixelcount']);
							}
						}
					}
				}
				
			}
		}
		
		$catalog_content .= $catalog_footer.'</div>
			</body>
		</html>';

		wp_reset_query();
		
		return $catalog_content;
	}

	//function to get product details about prices or variation prices
	private function get_product_details($product_id, $args_pixels = false, $pixels_counter = 0){
		$product_id = absint($product_id);
		$product = wc_get_product( $product_id );
		$products_details = false;
		$pixels_counter = floatval($pixels_counter);
		$output_product = '';

		if(is_object($product)){

			if($args_pixels){
				//Check change of page
				$pixels_count_aux = $pixels_counter + floatval($args_pixels['product_line']);
				
				if($pixels_count_aux > floatval($args_pixels['missing_pixels'])  ){
					$spacemissing = floatval($args_pixels['missing_pixels']) - $pixels_counter;

					$output_product .= $args_pixels['footer_html'].$args_pixels['header_html'];				
					$pixels_counter = 0;

				} else {
					$pixels_counter = $pixels_counter + floatval($args_pixels['product_line']);
				}
			}

			$output_product .= '
			<div class="catalog_product" style="margin-top:25px! important;padding-top:25px! important; border-top: 1px solid #333! important;
			padding-bottom: 0px! important;">
			<h3 class="catalog_product_title" style="margin-top:25px! important;padding-top:25px! important;text-transform: uppercase! important;font-weight: 900! important;"><strong>'.$product->get_name().'</strong></h3>
				<table border="0" style="border: 0px solid #000! important; width:100%" class="catalog_product_details_wrapper">
					<tbody border="0" style="border: 0px solid #000! important; width:100%">
						<tr border="0" style="border: 0px solid #000! important; width:100%">';

			if( $product->is_type( 'variable' ) ){
				
				foreach($product->get_available_variations() as $variation ){

					if (is_array($variation) ){
						// Attributes
						$attributes = array();
						$otherAttribute = false;
			
						foreach ($variation['attributes'] as $attribute => $term_slug ) {
							// Get the taxonomy slug
							$taxonmomy = str_replace( 'attribute_', '', $attribute );
		
							// Get the attribute label name
							$attr_label_name = wc_attribute_label( $taxonmomy );
							
							$term_name_data = get_term_by( 'slug', $term_slug, $taxonmomy );
							if(is_object($term_name_data)){
								$term_name_data_value = $term_name_data->name;
							} else {
								$term_name_data_value = '';
							}
							if (strpos($attr_label_name, 'Weight') !== false && $term_name_data_value !== '' ){
								$term_names[] = $term_name_data_value;
							} else {
								$otherAttribute = true;
							}
						}

						if (isset($variation['display_price']) ){
							// Prices
							$active_price = floatval($variation['display_price']); // Active price
							$regular_price = floatval($variation['display_regular_price']); // Regular Price
							if( $active_price != $regular_price ){
								$sale_price = $active_price; // Sale Price
							}
							$prices[] = $active_price;
						} else {
							$otherAttribute = true;
						}		
					}
				}

				if (isset($term_names) && !$otherAttribute){
					$iterms = 0;

					$products_details = true;
					
					$counter_prod_lines = 0;
					foreach ($term_names as $term_name){
						$price = $term_name;

						//price per pound
						$quantity = str_replace("LBS", "", $price);
						$quantity = str_replace("LBs", "", $quantity);
						$quantity = str_replace("LB", "", $quantity);
						$quantity = str_replace("LBs", "", $quantity);
						$quantity = str_replace("lbs", "", $quantity);
						$quantity = str_replace("lb", "", $quantity);
						$quantity = str_replace("pounds", "", $quantity);
						$quantity = str_replace("pound", "", $quantity);
						$quantity = str_replace("KGs", "", $quantity);
						$quantity = str_replace("kgs", "", $quantity);
						$quantity = str_replace("KG", "", $quantity);
						$quantity = str_replace("kg", "", $quantity);
						$quantity = str_replace(" ", "", $quantity);
						$quantity = floatval($quantity);
						if($quantity > 0){
							$price = ik_hn_numberFormatPrecision(($prices[$iterms]/$quantity), 2, '.');
						} else {
							//in case it's sample or a strange variation I will consider it's just one unit
							$price = ik_hn_numberFormatPrecision($prices[$iterms], 2, '.');
						}
						if ($args_pixels){
							if($counter_prod_lines > 4 || $pixels_count_aux > floatval($args_pixels['missing_pixels'])){

								$counter_prod_lines = 0;

								//Check change of page
								$pixels_count_aux = $pixels_counter + floatval($args_pixels['wrapper_product_line']);
								
								if($pixels_count_aux > floatval($args_pixels['missing_pixels']) ){
									$spacemissing = floatval($args_pixels['missing_pixels']) - $pixels_counter;
			
									$output_product .= $args_pixels['footer_html'].$args_pixels['header_html'];				
									$pixels_counter = 0;

								} else {
									$pixels_counter = $pixels_counter + floatval($args_pixels['wrapper_product_line']);
								}
							}	
						}

						$output_product .= '
								<td border="0" class="catalog_product_details" style="border: 0px solid #000! important; margin-right: 10px;padding: 7px 20px! important;">
									<div class="catalog_product_pack" style="margin-right: 10px;padding: 7px 10px! important;">'.$term_name.'</div>
									<span style="padding: 7px 10px! important;">'.wc_price($price).' (price / lb)</span>
								</td>';
						$iterms = $iterms + 1;
						$counter_prod_lines = $counter_prod_lines + 1;

					}
				}
				// for simple products
			} else if($product->get_type() == 'simple'){

				if(absint($product->get_price() > 0)){

					$products_details = true;

					$output_product .= '
							<td class="catalog_product_details" style="border: 0px solid #000! important;">
								<div class="catalog_product_pack">1 Bag / box each</div>
								<div class="catalog_product_price_details">
									<span class="catalog_product_price">'.$product->get_price().'</span>								
								</div>
							</td>';
				}
			}
			$output_product .= '</tr></tbody></table></div><hr>';
			
		}

		if($products_details){

			$output = array(
				'pixelcount' => $pixels_counter,
				'html' => $output_product,
			);

			return $output;
		} else {
			return false;
		}

	}


    //PDF is generated to download if the attribute downloadpricelist is added to the URL
    public function generate_pdf_file() {

		if(isset($_GET['downloadpricelist'])){

			//I create a catalog folder if doesn't exist
			$upload = wp_upload_dir();
			$upload_dir = $upload['basedir'];
			$folder_pricelist_name = 'hn_pdfcatalog';
			$uploads_catalog = $upload_dir . '/'.$folder_pricelist_name;
			if (! is_dir($uploads_catalog)) {
				mkdir( $uploads_catalog, 0755 );
			}

			//Create index file to avoid navigation
			$index_file_path = $uploads_catalog.'/index.php';

			// Verify if exists file to avoid navigation no matter what
			if ( ! file_exists( $index_file_path ) ) {
				$content_index = '<?php 
				//silence is golden 
				?>';
				file_put_contents( $index_file_path, $content_index );
			}

			// I delete files older than 2 days
			$files_old = glob($uploads_catalog . '/*');
			$two_days_ago = time() - (2 * 24 * 60 * 60);

			// I check the files to delete older than 2 days
			foreach ($files_old as $file_old) {
				if (is_file($file_old) && filemtime($file_old) < $two_days_ago) {
					unlink($file_old);
				}
			}   


			// I generate the pricelist
			$file_name_pricelist = 'pricelist_'.date('Ymd-His');
			$file_name_catalog = $file_name_pricelist.'.html';

			$catalog_file_path = $uploads_catalog.'/'.$file_name_catalog;

			// Verify if exists file to avoid creating it again
			if ( ! file_exists( $catalog_file_path ) ) {
				
				//I generate the hmtl for the pricelist
				$content_pricelist = $this->generate_catalog_content();

				//I generate the file
				file_put_contents( $catalog_file_path, $content_pricelist );
			}

			$url_pricelist = wp_upload_dir()['baseurl'].'/'.$folder_pricelist_name.'/'.$file_name_catalog;

			$response = wp_remote_get($url_pricelist);

			//I get html code from catalog html file
			if (is_array($response) && !is_wp_error($response)) {
				$html_pricelist = $response['body'];
			}

			//I generate the pdf
			if(isset($html_pricelist)){
				require_once('mpdf/vendor/autoload.php');

				$mpdf = new \Mpdf\Mpdf();
				$mpdf->useSubstitutions  = true;
				
				// Split the HTML content into pages
				$mpdf->WriteHTML($html_pricelist);
				
				$mpdf->Output($file_name_pricelist .'.pdf', 'D');
			}	
		}

	}

}
?>