<?php

namespace Mpdf\Tag;

class H2 extends BlockTag
{


}
