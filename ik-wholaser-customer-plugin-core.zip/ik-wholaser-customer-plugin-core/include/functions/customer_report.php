<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Customer Report Functions 
Created: 03/02/2023
Last Update: 24/02/2023
Author: Gabriel Caroprese
*/

// I add menus on WP-admin
add_action('admin_menu', 'ik_customerrep_menu');
function ik_customerrep_menu(){
    add_menu_page('Wholesale Report', 'Wholesale Report', 'manage_options', 'ik_customerrep_main', 'ik_customerrep_main', IK_HATTON_CORE_PUBLIC . '/img/customer-list.png' );
}

add_action('admin_head','ik_customerrep_menu_logo_position');
function ik_customerrep_menu_logo_position(){
echo '<style>#toplevel_page_ik_customerrep_main .wp-menu-image img {padding: 3px 0 0 0;}</style>';
}

// I start loading page for every submenu
function ik_customerrep_main(){
    $ik_customerrep_adminURL = get_site_url().'/wp-admin/admin.php?page=ik_customerrep_main';
    $reportShow = 1;
    include(IK_HATTON_CORE_DIR.'/include/templates/report.php');
}

//I get the total of customers
function ik_customerrep_getcount_userrole(){
    global $wpdb;
    $queryCountRole = "SELECT COUNT(user_id) FROM ".$wpdb->prefix."usermeta WHERE meta_key LIKE '".$wpdb->prefix."capabilities' AND meta_value LIKE '%customer\"%'";
    $roleCounted = $wpdb->get_results($queryCountRole);
    $countRolesVar = get_object_vars($roleCounted[0]);
    return $countRolesVar['COUNT(user_id)'];
}

//get the total number of orders from a user
function ik_customerrep_customer_total_order($usernameID) {
    $userID = intval($usernameID);
    
    if ($userID != 0 && $userID != NULL){
        $customer_orders = get_posts( array(
            'numberposts' => - 1,
            'meta_key'    => '_customer_user',
            'meta_value'  => $userID,
            'post_type'   => array( 'shop_order' ),
            'post_status' => array( 'wc-completed' )
        ) );
    
        $total = 0;
        foreach ( $customer_orders as $customer_order ) {
            $total = $total + 1;
        }
    
        return $total;
    }
}

// Get the total spent money from customer in different orders
function ik_customerrep_user_total_spent( $userSpender ) {

    $userID = intval($userSpender);

    if( $userID > 0 && $userID != NULL) {
        $customer = new WC_Customer( $userID ); // Get WC_Customer Object

        $total_spent = $customer->get_total_spent(); // Get total spent amount

        return wc_price( $total_spent ); // return formatted total spent amount
    }
}


// Function to get customer user data
function ik_customerrep_get_customer_data($userCustomer, $dataToGet){
    $userID = intval($userCustomer);
    $dataType = sanitize_text_field($dataToGet);
    if ($userID != NULL && $userID > 0 && $dataType != NULL && $dataType != ''){
        if (get_user_meta( $userID, $dataType, true )){
            if ($dataType == 'wc_last_active'){
                $customer_data = date("d-m-Y", get_user_meta( $userID, $dataType, true ));
            } else if ($dataType == 'mobile_number'){
                $customer_data = ik_customerrep_format_phone(get_user_meta( $userID, $dataType, true ));
            } else {
                $customer_data = get_user_meta( $userID, $dataType, true );
            }
        } else {
            if ($dataToGet == 'mobile_number'){
                $customer_data = get_user_meta( $userID, 'billing_phone', true );
            } else if ($dataToGet == 'company-name'){
                if (get_user_meta( $userID, 'billing_company', true )){
                    $customer_data = get_user_meta( $userID, 'billing_company', true );
                } else {
                    $customer_data = '-';
                }
            } else if ($dataToGet == 'address_15_16'){
                if (get_user_meta( $userID, 'billing_city', true )){
                    $customer_data = get_user_meta( $userID, 'billing_city', true );
                } else {
                    $customer_data = '-';
                }
            } else if ($dataToGet == 'State-Province'){
                if (get_user_meta( $userID, 'billing_state', true )){
                    $customer_data = get_user_meta( $userID, 'billing_state', true );
                } else {
                    $customer_data = '-';
                }
            } else if ($dataToGet == 'zip-code'){
                if (get_user_meta( $userID, 'billing_postcode', true )){
                    $customer_data = get_user_meta( $userID, 'billing_postcode', true );
                } else {
                    $customer_data = '-';
                }
            } else {
                $customer_data = '-';
            }
        }
        
        return $customer_data;
    }
}

//Function to format phone number
function ik_customerrep_format_phone($phoneNumber){
    $phoneFormatting = str_replace(',', '', $phoneNumber);
    $phoneFormatting = str_replace('.', '', $phoneFormatting);
    $phoneFormatting = str_replace('-', '', $phoneFormatting);
    $phoneFormatting = str_replace(')', '', $phoneFormatting);
    $phoneFormatting = str_replace('(', '', $phoneFormatting);
    $phoneFormatting = str_replace('+', '', $phoneFormatting);
    $phoneFormatting = str_replace('_', '', $phoneFormatting);
    $phoneFormatting = str_replace(' ', '', $phoneFormatting);
    $phone = intval($phoneFormatting);

    if (strlen((string)$phone) < 7 && strlen((string)$phone) > 13){
        $phone_formated = '-';
    } else {
        if (strlen((string)$phone) == 7){ //4102721
            $first3Numbers = substr($phone, 0, 3);
            $last4Numbers = substr($phone, 3, 4);
            $phone_formated = $first3Numbers.'-'.$last4Numbers; // 410-2721
        } else if (strlen((string)$phone) == 10){ // 3524102721
            $first3Numbers = substr($phone, 0, 3);
            $second3Numbers = substr($phone, 3, 3);
            $last4Numbers = substr($phone, 6, 4);
            $phone_formated = '('.$first3Numbers.') '.$second3Numbers.'-'.$last4Numbers; // (352) 410-2721
        } else if (strlen((string)$phone) == 12){ //543764616757
            $first2Numbers = substr($phone, 0, 2);
            $areCode = substr($phone, 2, 3);
            $threeNumbers = substr($phone, 5, 3);
            $lastDigits = substr($phone, 8, 4);
            $phone_formated = '+'.$first2Numbers.' ('.$areCode.') '.$threeNumbers.'-'.$lastDigits; //+54 (376) 461-6757
        } else if (strlen((string)$phone) == 13){
            $first2Numbers = substr($phone, 0, 2);
            $thirdDigit = substr($phone, 2, 1);
            $areaCode = substr($phone, 3, 3);
            $threeNumbers = substr($phone, 6, 3);
            $lastDigits = substr($phone, 9, 4);
            $phone_formated = '+'.$first2Numbers.' '.$thirdDigit.' ('.$areaCode.') '.$threeNumbers.'-'.$lastDigits; //+54 9 (376) 461-6757
        } else {
            $phone_formated = '-';
        }
    }
    return $phone_formated;
}

?>