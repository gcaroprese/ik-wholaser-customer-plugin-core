<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - On demand products
Created: 04/06/2023
Last Update: 04/10/2023
Author: Gabriel Caroprese
*/

//Menu to set product list
function ik_hn_products_ondemand_menu(){
    add_menu_page('On Demand Products', 'On Demand Products', 'manage_options', 'ik_hn_products_ondemand_admin', 'ik_hn_products_ondemand_admin' );
}
add_action('admin_menu', 'ik_hn_products_ondemand_menu');

//icon for menu item
function ik_hn_products_ondemand_menu_icons_css() {
    ?>
    <style>
        #toplevel_page_ik_hn_products_ondemand_admin div.wp-menu-image:before { content: "\f323"; }
    </style>
    <?php
}
add_action( 'admin_head', 'ik_hn_products_ondemand_menu_icons_css' );

/*
    Products On demand panel
                                    */
function ik_hn_products_ondemand_admin(){
    include(IK_HATTON_CORE_DIR.'/include/functions/ondemand_products/templates/products.php');
}

//shortcode to show list of ondemand products
function ik_hn_products_ondemand_shortcode(){
    $output = '<div id="ik_hn_ondemand_products_list">';

    $list_products = get_option('ik_hn_ondemand_products_list');

    if (is_array($list_products)){
        //I order by categories
        $index_cats = 9;
        foreach ($list_products as $product){
            if(isset($product['cat_id'])){
                switch (absint($product['cat_id'])) {
                    //Botanicals first
                    case 62:
                        $categories[0][] = $product;
                        break;
                    case 63:
                        $categories[1][] = $product;
                        break;
                    case 6:
                        $categories[2][] = $product;
                        break;
                    case 64:
                        $categories[3][] = $product;
                        break;
                    case 582:
                        $categories[4][] = $product;
                        break;
                    case 67:
                        $categories[5][] = $product;
                        break;
                    case 61:
                        $categories[6][] = $product;
                        break;
                    case 7:
                        $categories[7][] = $product;
                        break;
                    case 68:
                        $categories[8][] = $product;
                        break;
                    default:
                        $categories[$index_cats][] = $product;
                }
                
                $index_cats = $index_cats + 1;                
            }
        }

        //if content of products was loaded in categories
        if(isset($categories)){
            $output .= '<style>
            #ik_hn_ondemand_products_list h3{
                text-align: center;
                display: block;
                margin-top: 40px;
            }
            #ik_hn_ondemand_products_list .hn_table_products_od{
                display: table;
                width: 100%;
                margin: 0 auto;
            }
            #ik_hn_ondemand_products_list .hn_table_products_od_row {
                display: table-row;
            }
            #ik_hn_ondemand_products_list .hn_table_products_od_data, #ik_hn_ondemand_products_list .hn_table_products_odHead {
                border: 1px solid #7A7A7A;
                display: table-cell;
                padding: 7px 10px;
            }
            #ik_hn_ondemand_products_list .hn_table_products_odFoot {
                background-color: #EEE;
                display: table-footer-group;
                font-weight: bold;
            }
            #ik_hn_ondemand_products_list .hn_table_products_odBody {
                display: table-row-group;
            }
            #ik_hn_ondemand_products_list .hn_table_products_od{
                max-width: 600px;
                vertical-align: middle;
            }
            #ik_hn_ondemand_products_list .hn_table_products_od_data{
                vertical-align: middle;
            }
            #ik_hn_ondemand_products_list .hn_table_products_od_name{
                width: 75%;
            }
            #ik_hn_ondemand_products_list .hn_table_products_od_request{
                text-align: center;
            }
            #ik_hn_ondemand_products_list .hn_request_quote_ondemand {
                color: #fff;
                background: #d6df26;
                padding: 7px;
                border-radius: 7px;
            }
            /* Popup container */
            #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_container {
                display: none;
                position: fixed;
                z-index: 9999999;
                top: 0px;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.7);
            }

            /* Popup content */
            #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_content {
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                z-index: 9999999;
                position: relative;
                top: 60px;
                margin: auto;
                width: 80%;
                max-width: 500px;
                background-color: #fff;
                padding: 20px 20px 0;
                border-radius: 5px;
            }
            #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_content textarea{
                height: 100px;
                width: 100%;
                max-width: 460px;
            }
            #ik_hn_ondemand_products_list .wpcf7 form .wpcf7-response-output {
                margin: 0em 0.5em 2em;
            }
            /* Close button */
            #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_close_wrapper {
                background: #fff;
                display: block;
                position: absolute;
                top: -13px;
                z-index: 999999999999;
                right: -14px;
                display: inherit;
                width: 30px;
                height: 30px;
                border-radius: 50px;
            }
            #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_close {
                position: absolute;
                top: -12px;
                right: 1px;
                width: 30px;
                height: 30px;
                border: none;
                background-color: transparent;
                cursor: pointer;
            }
            #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_close::before, #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_close::after {
                content: "";
                position: absolute;
                width: 2px;
                height: 24px;
                background-color: #000;
            }

            #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_close::before {
                transform: rotate(45deg);
            }
            #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_cf7 p {
                margin: 0 0 5px;
            }
            #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_close::after {
                transform: rotate(-45deg);
            }
            #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_container.show {
                display: flex;
            }
            #ik_hn_ondemand_products_list input[type="submit"] {
                cursor: pointer;
            }
            .ik_hn_ondemand_products_quote_popup_container {
                animation: slideDown 0.5s ease-in-out;
              }
              
              @keyframes slideDown {
                0% {
                  transform: translateY(-100%);
                  opacity: 0;
                }
                100% {
                  transform: translateY(0);
                  opacity: 1;
                }
              }
            @media(max-width: 640px){
                #ik_hn_ondemand_products_list .hn_table_products_od_name {
                    width: 55%! important;
                }
                #ik_hn_ondemand_products_list .hn_request_quote_ondemand {
                    display: block;
                }
                #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_content {
                    top: 30px! important;
                }
                #ik_hn_ondemand_products_list .ik_hn_ondemand_products_quote_popup_content {
                    padding: 20px 20px 0px;
                }
                #ik_hn_ondemand_products_list .wpcf7 form .wpcf7-response-output {
                    margin: 0 0.5em 30px;
                    padding: 0 1em;
                    font-size: 15px;
                }
            }
            </style>';

            foreach ($categories as $products_data){

                $category_id = $products_data[0]['cat_id'];
                $category = get_term_by( 'id', $category_id, 'product_cat' );

                //If category exists
                if ( $category ) {

                    if(!isset($category_id_listed[$category_id])){
                        $category_name = $category->name;

                        $output .= '<h3>'.$category_name.'</h3>';
                        $category_id_listed[$category_id] = true;
                    }
                    $output .= '<div class="hn_table_products_od">
                            <div class="hn_table_products_odBody">';

                    //list the products already associated to this cat id
                    foreach ($products_data as $product_data){

                        if(isset($product_data['name'])){

                            $product_name = str_replace('\"', '"', $product_data['name']);
                            $product_name = str_replace("\'", "'", $product_name);

                            $output .= '                
                            <div class="hn_table_products_od_row">
                                <div class="hn_table_products_od_data hn_table_products_od_name">'.$product_name.'</div>
                                <div class="hn_table_products_od_data hn_table_products_od_request">
                                    <a href="#" class="hn_request_quote_ondemand">Request Quote</a>
                                </div>
                            </div>';
                        }
                    }
                    
                    $output .= '</div>
                    </div>';
                }

            }
        }
   
    }
    $cf7_form_id = absint(get_option('ik_hn_ondemand_cf7_id'));

    $output .= '
        <div class="ik_hn_ondemand_products_quote_popup_container">
            <div class="ik_hn_ondemand_products_quote_popup_content">
                <div class="ik_hn_ondemand_products_quote_popup_close_wrapper">
                    <button class="ik_hn_ondemand_products_quote_popup_close"></button>
                </div>
                <div class="ik_hn_ondemand_products_quote_popup_cf7">
                '.do_shortcode('[contact-form-7 id="'.$cf7_form_id.'"]').'
                </div>
            </div>
        </div>
        <script>
        document.addEventListener("DOMContentLoaded", function() {
            var requestQuoteButtons = document.querySelectorAll("#ik_hn_ondemand_products_list .hn_request_quote_ondemand");
            requestQuoteButtons.forEach(function(button) {
                button.addEventListener("click", function(event) {
                    event.preventDefault();
                    var productName = this.closest(".hn_table_products_od_row").querySelector(".hn_table_products_od_name").textContent;
                
                    var subject = "Request a Quote for " + productName;
                    var message = "I\'m interested in large quantities of " + productName;
                
                    var popupContainer = document.querySelector(".ik_hn_ondemand_products_quote_popup_container");
                    if (popupContainer) {
                    popupContainer.classList.add("show");
                    setTimeout(function(){
                        var subjectField = document.querySelector("input[name=\"your-subject\"]");
                        if (subjectField) {
                        subjectField.value = subject;
                        }
                        var messageField = document.querySelector("textarea[name=\"your-message\"]");
                        if (messageField) {
                        messageField.value = message;
                        }
                    }, 1000);
                    }
                });
            });
        });

        // Add click event listener to the close button
        var closeButton = document.querySelector(".ik_hn_ondemand_products_quote_popup_close");
        if (closeButton) {
          closeButton.addEventListener("click", function() {
            // Hide the popup
            var popupContainer = document.querySelector(".ik_hn_ondemand_products_quote_popup_container");
            if (popupContainer) {
              popupContainer.classList.remove("show");
            }
          });
        }
        </script>
    </div>';

    return $output;

}
    
add_shortcode('HN_SHOW_ONDEMAND_PRODUCTS', 'ik_hn_products_ondemand_shortcode');

?>