<?php
/*

Wholesale Customer Plugin - On Demand Products Config Panel
Created: 04/06/2023
Last Update: 04/06/2023
Author: Gabriel Caroprese
*/

if ( ! defined('ABSPATH')) exit('restricted access');

//Save data submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    //if saving contact form 7 ID
    if (isset($_POST['contact_form7_id']) ){
        $form_id = absint($_POST['contact_form7_id']);
        update_option('ik_hn_ondemand_cf7_id', $form_id);
    }
    if (isset($_POST['product_name']) && isset($_POST['product_cat_id'])){
        $product_names = $_POST['product_name'];
        $product_cat_id = $_POST['product_cat_id'];
            
        if (is_array($product_names) && is_array($product_cat_id)){
            
            $countData = 0;   
            
            foreach( $product_names as $product_name ) {
    
                if (isset($product_name) && isset($product_cat_id[$countData])) {
                    $product_name = sanitize_text_field($product_name);
                    $product_name = str_replace('\"', '"', $product_name);
                    $product_name = str_replace("\'", "'", $product_name);
                    $cat_id = absint($product_cat_id[$countData]);

                    $product_ondemand[] = array(
                        'name' => $product_name,
                        'cat_id' => $cat_id
                    );
              
                }
                $countData = $countData + 1;
            }
            if(isset($product_ondemand)){
                update_option('ik_hn_ondemand_products_list', $product_ondemand);
            }
        }
    } 
}
$cat_selector = hn_woo_select_product_categories(true, true);
$cf7_form_id = absint(get_option('ik_hn_ondemand_cf7_id'));


?>
<style>
    #ik_hn_ondemand_products .ik_hn_ondemand_product_fields{
        padding: 20px 20px 30px;
        background: #ddd;
        border-radius: 15px;
        max-width: 767px;
        margin: 25px 0;
    }
    #ik_hn_ondemand_products .ik_hn_ondemand_product_fields ul {
        margin-bottom: 20px;
    }
    #ik_hn_ondemand_products .ik_hn_ondemand_product_fields ul input {
        max-width: 355px;
        min-width: 200px;
    }
    #ik_hn_ondemand_products .ik_hn_ondemand_product_fields ul select {
        max-width: 325px;
        min-width: 220px;
    }
    #ik_hn_ondemand_products .ik_hn_ondemand_product_fields ul select {
        position: relative;
        top: -3px;
    }
    #ik_hn_ondemand_products .ik_hn_ondemand_product_fields .ui-draggable-handle {
        display: inline-block;
        touch-action: none;
        padding: 5px 7px;
        background: #ccc;
        border-radius: 5px;
    }
    @media(min-width: 767px){
        #ik_hn_ondemand_products .ik_hn_ondemand_product_fields ul input {
            width: 355px;
        }
        #ik_hn_ondemand_products .ik_hn_ondemand_product_fields ul select {
            width: 325px;
        }       
    }
</style>
<div id="ik_hn_ondemand_products">
    <h1>Edit On Demand Products</h1>
    <p><b>Shortcode:</b> [HN_SHOW_ONDEMAND_PRODUCTS]</p>
    <form action="" method="post" enctype="multipart/form-data" autocomplete="no">
        <label>
            <span>Contact Form 7 ID</span><br />
            <input type="number" required name="contact_form7_id" value="<?php echo $cf7_form_id; ?>" />
        </label>
        <input type="submit" class="button button-primary" value="Save Form" />
    </form>

    <form action="" method="post" enctype="multipart/form-data" autocomplete="no">
        <div class="ik_hn_ondemand_product_fields">
            <ul>
                <?php
                //Existing on demand products
                $list_products = get_option('ik_hn_ondemand_products_list');;
                if (is_array($list_products)){
                    foreach ($list_products as $product){
                        if(isset($product['name']) && isset($product['cat_id'])){
                            $product_name = sanitize_text_field($product['name']);
                            $selectedCatId = absint($product['cat_id']);
                            ?>
                            <li class="draggable-item">
                                <input type="text" required name="product_name[]" placeholder="Product Name" value="<?php echo $product_name; ?>" /><?php echo hn_woo_select_product_categories(true, true, $selectedCatId); ?><a href="#" class="ik_hn_delete_field button">Delete</a>
                            </li>
                            <?php
                        }
                    }
                } else {
    			?>
    			         <li class="draggable-item">
                            <input type="text" required name="product_name[]" placeholder="Product Name" /><?php echo $cat_selector; ?><a href="#" class="ik_hn_delete_field button">Delete</a>
                        </li>
    			<?php
    			}
                ?>
            </ul>
            <a href="#" class="button button-primary" id="ik_hn_add_fields">Add Products</a>
        </div>
        <input type="submit" class="button button-primary" value="Save" />
    </form>
</div>
<script>
jQuery(document).ready(function($){
    // Add fields
    jQuery(document).on('click', '#ik_hn_add_fields', function(){
        jQuery('#ik_hn_ondemand_products .ik_hn_ondemand_product_fields ul').append('<li class="draggable-item ui-draggable ui-draggable-handle ui-sortable-handle"><input type="text" required name="product_name[]" placeholder="Product Name" /><?php echo $cat_selector; ?><a href="#" class="ik_hn_delete_field button">Delete</a></li>');
        init_draggable(jQuery('.draggable-item'));
        return false;
    });
    
    // Delete fields
    jQuery(document).on('click', '#ik_hn_ondemand_products .ik_hn_ondemand_product_fields .ik_hn_delete_field', function(){
        jQuery(this).parent().remove();
        return false;
    });

    init_draggable(jQuery('.draggable-item'));

    jQuery('#ik_hn_ondemand_products .ik_hn_ondemand_product_fields ul').sortable({
        items: '.draggable-item',
        start: function(event, ui) {
            jQuery('#ik_hn_ondemand_products .ik_hn_ondemand_product_fields ul').sortable('enable');
        },
    });

    function init_draggable(widget) {
        widget.draggable({
            connectToSortable: '#ik_hn_ondemand_products .ik_hn_ondemand_product_fields ul',
            stack: '.draggable-item',
            revert: true,
            revertDuration: 200,
            start: function(event, ui) {
                jQuery('#ik_hn_ondemand_products .ik_hn_ondemand_product_fields ul').sortable('disable');
            }
        });
    }   
});
    
</script>