<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - After Cart Functions 
Created: 03/02/2023
Last Update: 10/04/2023
Author: Gabriel Caroprese
*/

add_action( 'woocommerce_after_add_to_cart_button', 'hn_after_cart_scripts', 10, 0 );
function hn_after_cart_scripts() { 

	$wholesale_role_slug = (get_option('HN_WHOLESALE_ROLE')) ? sanitize_text_field(get_option('HN_WHOLESALE_ROLE')) : 'default_wholesaler';
	$slug_variation_larger_qties = (get_option('HN_SLUG_VAR_QTIES')) ? sanitize_text_field(get_option('HN_SLUG_VAR_QTIES')) : 'select-package';
	$slug_variation_larger_qties_link = (get_option('HN_SLUG_VAR_QTIES_LINK')) ? esc_url(get_option('HN_SLUG_VAR_QTIES_LINK')) : get_site_url().'/request-larger-quantities/';


	//checking if user wholesale logged in
	$user = wp_get_current_user();
		
	if (is_user_logged_in() && (current_user_can($wholesale_role_slug) || current_user_can('administrator'))) {
		$user_wholesale = true;
		$after_cart_text = (get_option('HN_AFTER_CART_TEXT_WS')) ? sanitize_text_field(get_option('HN_AFTER_CART_TEXT_WS')) : 'Need more than 200 lbs or a pallet load?';
		$after_cart_text_button = (get_option('HN_AFTER_CART_TEXT_BTN_WS')) ? sanitize_text_field(get_option('HN_AFTER_CART_TEXT_BTN_WS')) : 'Request a quote';
		$after_cart_link_button = (get_option('HN_AFTER_CART_LINK_BTN_WS')) ? esc_url(get_option('HN_AFTER_CART_LINK_BTN_WS')) : get_site_url().'/request-larger-quantities/';
	} else {
		$user_wholesale = false;
		$after_cart_text = (get_option('HN_AFTER_CART_TEXT')) ? sanitize_text_field(get_option('HN_AFTER_CART_TEXT')) : 'Need larger quantities? Purchasing for a business?';
		$after_cart_text_button = (get_option('HN_AFTER_CART_TEXT_BTN')) ? sanitize_text_field(get_option('HN_AFTER_CART_TEXT_BTN')) : 'Register for a Wholesale Account';
		$after_cart_link_button = (get_option('HN_AFTER_CART_LINK_BTN')) ? esc_url(get_option('HN_AFTER_CART_LINK_BTN')) : home_url('/wholesale/register/');
	}

	$product_id = get_the_ID();
	if (get_post_meta( $product_id, 'hnamazon_productlink', true )!= NULL){
	echo '<a class="hnamazon_productlink" href="'.get_post_meta( $product_id, 'hnamazon_productlink', true ).'" target="_blank"><img src="'.get_site_url().'/wp-content/themes/jupiter-child/img/amazon-buy-link.png" alt="buy on amazon" /></a>';
	}
    echo '<div class="ik_larger_quantities_message">'.$after_cart_text.' <a class="btn-atc" href="' . esc_url( $after_cart_link_button ) .'" target="_blank">' . $after_cart_text_button  . '</a></div>';
	
	//Mark selected last product if variation not selected
	if(!isset($_GET['attribute_pa_quantity'])){
		echo "<script>
		jQuery(window).bind('load', function() {
			setTimeout(function(){ 
				var last_label_var_element = jQuery('.variations_form.cart .variations .value:last-child label');
				jQuery('.variations_form.cart .variations .value:last-child input:not(disabled)' ).click();
				jQuery('.variations_form.cart .variations .value:last-child input:not(disabled)' ).each(function() {
					if (jQuery(this).prop('disabled') == true){
						jQuery(this).parent().find('label').attr('style', 'text-decoration: line-through;' );
						jQuery(this).parent().find('label').attr('title', 'Out of stock' );

					} else {
						last_label_var_element = jQuery(this).parent().find('label');
					}
				});
				last_label_var_element.addClass('always_select');
			}, 1500);
		});
		</script>";
	}

	if($user_wholesale){
		echo "
		<style>
		#pa_quantity_larger_qtys label {
			cursor: pointer;
			text-decoration: none! important;
		}
		</style>
		<script>
			jQuery(window).bind('load', function() {
				jQuery('.variations .attribute-pa_".$slug_variation_larger_qties." .value').append(\"<div id='pa_quantity_larger_qtys'><input type='radio' name='attribute_pa_".$slug_variation_larger_qties."' value='LARGER QTYS?' id='pa_quantity_larger_qtys'><label for='pa_quantity_larger_qtys' class='always_select'>LARGER QTYS?</label></div>\");
				jQuery('.variations').on('click', '#pa_quantity_larger_qtys label', function(){
					window.location.href='".$slug_variation_larger_qties_link."';
				});
				setTimeout(function(){ 
					jQuery('#pa_quantity_larger_qtys label').removeAttr('title');
				}, 2000);
			});
		</script>";

	}

	//check if product is in stock
	$product = wc_get_product($product_id);
	if($product){
		if (!$product->is_in_stock()) {
			echo "<script>
			jQuery(window).bind('load', function() {
				setTimeout(function(){ 
					jQuery('.variations_form.cart .variations .value:last-child label:not(.always_select)').each(function() {
						jQuery(this).parent().find('input').attr('disabled', 'disabled' );
						jQuery(this).attr('style', 'text-decoration: line-through;' );
						jQuery(this).attr('title', 'Out of stock' );
					});
					jQuery('.variations .reset_variations').attr('style', 'opacity:0');
				}, 2000);
			});
			</script>";
		}
	}
}

?>