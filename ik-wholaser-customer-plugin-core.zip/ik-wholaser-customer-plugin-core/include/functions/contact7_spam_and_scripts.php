<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Contact7 Spam functions
Created: 03/02/2023
Last Update: 24/02/2023
Author: Gabriel Caroprese
*/


//Avoid spam on messages on contact CF7 messages
function is_business_email($email){
	if(preg_match('/@yahoo.co/i', $email) ||
		preg_match('/@mailinator.com/i', $email) ||
		preg_match('/ericjonesmyemail@gmail.com/i', $email) ||
		preg_match('/christinaMi@hotmail.com/i', $email) ||
		preg_match('/eric.jones.z.mail@gmail.com/i', $email) ||
		preg_match('/@gmail.co.in/i', $email) ||
		preg_match('/@yandex.com/i', $email) ||
		preg_match('/@nutricompany.com/i', $email) ||
		preg_match('/@gawab.com/i', $email) ||
		preg_match('/@inbox.com/i', $email) ||
		preg_match('/@gmx.com/i', $email) ||
		preg_match('/@rediffmail.com/i', $email) ||
		preg_match('/@in.com/i', $email) ||
		preg_match('/@hotmail.co.uk/i', $email) ||
		preg_match('/@hotmail.fr/i', $email) ||
		preg_match('/@yahoo.fr/i', $email) ||
		preg_match('/@wanadoo.fr/i', $email) ||
		preg_match('/@wanadoo.fr/i', $email) ||
		preg_match('/@yahoo.co.in/i', $email) ||
		preg_match('/@rediffmail.com/i', $email) ||
		preg_match('/@free.fr/i', $email) ||
		preg_match('/@gmx.de/i', $email) ||
		preg_match('/@gmx.de/i', $email) ||
		preg_match('/@yandex.ru/i', $email) ||
		preg_match('/@ymail.com/i', $email) ||
		preg_match('/@libero.it/i', $email) ||
		preg_match('/@uol.com.br/i', $email) ||
		preg_match('/@bol.com.br/i', $email) ||
		preg_match('/@mail.ru/i', $email) ||
		preg_match('/@cox.net/i', $email) ||
		preg_match('/@hotmail.it/i', $email) ||
		preg_match('/@sbcglobal.net/i', $email) ||
		preg_match('/@sfr.fr/i', $email) ||
		preg_match('/@live.fr/i', $email) ||
		preg_match('/@verizon.net/i', $email) ||
		preg_match('/@live.co.uk/i', $email) ||
		preg_match('/@googlemail.com/i', $email) ||
		preg_match('/@ig.com.br/i', $email) ||
		preg_match('/@live.nl/i', $email) ||
		preg_match('/@bigpond.com/i', $email) ||
		preg_match('/@terra.com.br/i', $email) ||
		preg_match('/@neuf.fr/i', $email) ||
		preg_match('/@aim.com/i', $email) ||
		preg_match('/@bigpond.net.au/i', $email)){
			return false; // spam
	}
	else{
		return true;
	}
}

function custom_email_validation_filter($result, $tag) {
	$tag = new WPCF7_Shortcode( $tag );
	if ( 'your-email' == $tag->name ) {
		$the_value = isset( $_POST['your-email'] ) ? trim( $_POST['your-email'] ) : '';
		
		if(!is_business_email($the_value)){
			$result->invalidate( $tag, 'Spam Error.' );
		}
	}
	return $result;
}
add_filter( 'wpcf7_validate_email', 'custom_email_validation_filter', 10, 2 );
add_filter( 'wpcf7_validate_email*', 'custom_email_validation_filter', 10, 2 );


//Script to add data to form like user data and products in stock or backorder
function ik_hn_contactform7_script() {

	//I get data from user if logged in
	$user = wp_get_current_user();

	if ($user){
		$customer_name = $user->first_name.' '.$user->last_name;
		$customer_email = $user->user_email;
		$customer_company = get_user_meta($user->ID, 'company-name', true);
	} else {
		$customer_name = '';
		$customer_email = '';
		$customer_company = '';
	}

	$output = "<script>
	jQuery(document).ready(function ($) {
		var customer_name = document.getElementById('ik_hn_cf7_name');
		var customer_email = document.getElementById('ik_hn_cf7_email');
		var customer_company = document.getElementById('ik_hn_company');
		var products_to_ask = document.getElementById('ik_hn_products');
		
		if(customer_name){
			customer_name.value = '".$customer_name."';
		}
		if(customer_email){
			customer_email.value = '".$customer_email."';
		}
		if(customer_company){
			customer_company.value = '".$customer_company."';
		}
		if(products_to_ask){
			products_to_ask.innerHTML = '".ik_hatton_list_options_products_in_stock()."';
		}
	});
	</script>";

	return $output;
}
add_shortcode('contactform7_hnscript', 'ik_hn_contactform7_script');