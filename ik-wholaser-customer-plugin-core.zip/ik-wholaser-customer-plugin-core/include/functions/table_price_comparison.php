<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Table Price comparison
Created: 03/02/2023
Last Update: 01/15/2024
Author: Gabriel Caroprese
*/

//To reduce number to two digits without rounding
function ik_hn_numberFormatPrecision($number, $precision = 2, $separator = '.'){
    $numberParts = explode($separator, $number);
    $response = $numberParts[0];
    if (count($numberParts)>1 && $precision > 0) {
        $response .= $separator;
        $response .= substr($numberParts[1], 0, $precision);
    }
    return $response;
}

function ik_hn_get_quantity_in_pounds($term_name){
	$quantity = str_replace("OZ", "oz", $term_name);
	$quantity = str_replace("Oz", "oz", $quantity);
	$quantity = str_replace("LB", "lb", $quantity);
	$quantity = str_replace("Lb", "lb", $quantity);

	//if ounces					
	if (!str_contains($term_name, 'oz')) {
		//if pounds
		$quantity = str_replace("lb", "", $term_name);
		$quantity = str_replace("LBS", "", $quantity);
		$quantity = str_replace("LBs", "", $quantity);
		$quantity = str_replace("LB", "", $quantity);
		$quantity = str_replace("LBs", "", $quantity);
		$quantity = str_replace("lbs", "", $quantity);
		$quantity = str_replace("pounds", "", $quantity);
		$quantity = str_replace("pound", "", $quantity);
		$quantity = str_replace("KGs", "", $quantity);
		$quantity = str_replace("kgs", "", $quantity);
		$quantity = str_replace("KG", "", $quantity);
		$quantity = str_replace("kg", "", $quantity);
		$quantity = str_replace(" ", "", $quantity);	
	} else if (str_contains($term_name, 'oz')) { 
		if (!str_contains($term_name, 'lb')) {
			$quantity = floatval(str_replace("oz", "", $term_name));
			$quantity = (is_float($quantity)) ? $quantity/16 : 0;
		} else {
			//if ounces specified with pounds
			$quantity = str_replace("lbS", "lbs", $term_name);
			$quantity = str_replace("lbs", "lb", $quantity);
			$pattern = '/(\d+(\.\d+)?|\d+\/\d+) lb/';

			// Find matches in the text
			preg_match($pattern, $quantity, $matches);

			// The matched number is at position 1 in the matches
			$pounds = isset($matches[1]) ? $matches[1] : 0;

			// If the pounds value contains a fraction, convert it to a float
			if (strpos($pounds, '/')) {
				if (strpos($pounds, '/')) {
					$fraction = explode('/', $pounds);
					$pounds = $fraction[0] / $fraction[1];
				}
			}			
			$quantity = $pounds;
		}	

	} else {
		$quantity = 0;
	}
	return $quantity;
}

//I show a product variation table with prices, prices per pound and discounts
function ik_shortcode_table_comparison(){
	$output = "";
	global  $woocommerce;
	$product = wc_get_product( get_the_ID() );
	if($product){
		if( $product->is_type( 'variable' ) ){

            $variation_label = (defined('HN_VAR_LABEL')) ? sanitize_text_field(HN_VAR_LABEL) : 'Weight';

			$output .= '<div id="ik_table_price_compare">';
			foreach($product->get_available_variations() as $variation ){
				if ($variation ){
					// Variation ID
					$variation_id = $variation['variation_id'];
					// Attributes
					$attributes = array();
					$otherAttribute = false;
					foreach ($variation['attributes'] as $attribute => $term_slug ) {
						// Get the taxonomy slug
						$taxonmomy = str_replace( 'attribute_', '', $attribute );

						// Get the attribute label name
						$attr_label_name = wc_attribute_label( $taxonmomy );
						$term_name_data = get_term_by( 'slug', $term_slug, $taxonmomy )->name;
						if (strpos($attr_label_name, $variation_label) !== false && $term_name_data != NULL){
							$label_names[] = $attr_label_name;
							$term_names[] = $term_name_data;
						} else {
							$otherAttribute = true;
						}
					}	
					// Prices
					$active_price = floatval($variation['display_price']); // Active price
					$regular_price = floatval($variation['display_regular_price']); // Regular Price
					if( $active_price != $regular_price ){
						$sale_price = $active_price; // Sale Price
					}
					$prices[] = $active_price;
				}
			}
			if (isset($term_names) && $otherAttribute == false){
				if (count($term_names) > 1){
					$iterms = 0;

					//I take the min price from variations
					$comparative_number = floatval(min($prices));

					$output .= '<table style="display: none">
					<tr class="header-table-prices">
					<th>Quantity</th>
					<th>Price</th>
					<th>Price per lb</th>
					</tr>';
					foreach ($term_names as $term_name){
						$quantity = floatval(ik_hn_get_quantity_in_pounds($term_name));

						if($quantity > 0){
							if ($comparative_number == $prices[$iterms]){
								$discount = '-';
							} else {
								$price_if_one_pound = $comparative_number * floatval($quantity);
								$percentChange = (floatval($prices[$iterms]) / floatval($price_if_one_pound) ) * 100;
								$discount = intval($percentChange).'%';   
							}
							$price_per_pound = ik_hn_numberFormatPrecision(($prices[$iterms]/$quantity), 2, '.');;               
							$data_table[strval($quantity)] = '<tr class="details-table-prices">
							<td>'.$term_name.'</td>
							<td>'.wc_price($prices[$iterms]).'</td>
							<td class="ik_table_per_pound">'.wc_price($price_per_pound).'</td>
							</tr>';
						}
						$iterms = $iterms + 1;
					}
					ksort($data_table);
					foreach ($data_table as $data_row){
						$output .= $data_row;
					}	
					$output .= '</table>
					<button id="ik_show_price_comparison">Show Price Comparison</button>';
				}
			}
				
			$output .= '</div>';
		}
	}
	return $output;
}
add_shortcode('show_table_prices', 'ik_shortcode_table_comparison');

?>