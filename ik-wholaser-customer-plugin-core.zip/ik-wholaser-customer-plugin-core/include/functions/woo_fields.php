<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Woo Fields Functions 
Created: 03/02/2023
Last Update: 30/03/2023
Author: Gabriel Caroprese
*/

// Amazon Link custom field for product pages
function hn_add_amazon_link() {
	$args = array(
	'label' => __( 'Amazon Product Link', 'woocommerce' ),
	'placeholder' => __( 'Enter your Amazon link here', 'woocommerce' ),
	'id' => 'hnamazon_productlink',
	'desc_tip' => true,
	'description' => __( 'Amazon Product link.', 'woocommerce' ),
	);
	woocommerce_wp_text_input( $args );
}
add_action( 'woocommerce_product_options_advanced', 'hn_add_amazon_link' );

// UPC code custom field for products
function hn_upc_code_field() {
	$args = array(
	'label' => __( 'UPC Code', 'woocommerce' ),
	'placeholder' => __( 'GTIN, UPC, EAN, JAN or ISBN', 'woocommerce' ),
	'id' => 'hn_upc_code',
	'desc_tip' => true,
	'description' => __( 'Add your GTIN, UPC, EAN, JAN or ISBN code', 'woocommerce' ),
	);
	woocommerce_wp_text_input( $args );
	echo '<style>
			.variable_pricing label {
				display: inline-block;
			}
		</style>';
}
add_action( 'woocommerce_product_options_advanced', 'hn_upc_code_field' );

// COA number custom field for product pages
function hn_add_coa_number() {
	$args = array(
	'label' => __( 'COA Number', 'woocommerce' ),
	'placeholder' => __( 'Enter your COA number here', 'woocommerce' ),
	'id' => 'coa_number',
	'desc_tip' => true,
	'description' => __( 'COA Number.', 'woocommerce' ),
	);
	woocommerce_wp_text_input( $args );
}
add_action( 'woocommerce_product_options_advanced', 'hn_add_coa_number' );

// Batch number custom field for product pages
function hn_add_batch_number() {
	$args = array(
	'label' => __( 'Batch Number', 'woocommerce' ),
	'placeholder' => __( 'Enter your Batch number here', 'woocommerce' ),
	'id' => 'batch_number',
	'desc_tip' => true,
	'description' => __( 'Batch Number.', 'woocommerce' ),
	);
	woocommerce_wp_text_input( $args );
}
add_action( 'woocommerce_product_options_advanced', 'hn_add_batch_number' );

//Code to add UPS code as meta product data on product page
add_filter('woocommerce_product_meta_end', 'ik_add_upc_code_attr', 1, 10);
function ik_add_upc_code_attr(){
	$html = '';
	global $product;
	//I make sure $product is an objet
	if (is_object($product)){
		$product_id = $product->get_id();

		//make sure there's a UPC code
		$upc_code = get_post_meta($product_id, 'hn_upc_code', true);

		if($upc_code){
			if($upc_code !== '' ){
				//I add the HTML code to show the UPC code attribute
				$html .= '<tr class="upc_code_attribute">
					<th class="label"><label for="upc_code">UPC:</label></th>
					<td class="value">'.$upc_code.'</td>
				</tr>';
				
			}
		}
	}
    echo $html;
}

//Save custom data from advanced fields of Woocommerce product edit page
function hn_save_wc_advanced_custom_fields( $post_id ) {
	$post = get_post($post_id);
	
	// Return if the user doesn't have edit permissions.
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return $post_id;
	}
	// Don't store custom data twice
	if ( 'revision' === $post->post_type ) {
		return;
	}
	$hnamazon_productlink = isset( $_POST[ 'hnamazon_productlink' ] ) ? sanitize_text_field( $_POST[ 'hnamazon_productlink' ] ) : '';
	$hn_upc_code = isset( $_POST[ 'hn_upc_code' ] ) ? sanitize_text_field( $_POST[ 'hn_upc_code' ] ) : '';
	$coa_number = isset( $_POST[ 'coa_number' ] ) ? sanitize_text_field( $_POST[ 'coa_number' ] ) : '';
	$batch_number = isset( $_POST[ 'batch_number' ] ) ? sanitize_text_field( $_POST[ 'batch_number' ] ) : '';
	
	$product = wc_get_product( $post_id );

	$product->update_meta_data( 'batch_number', $batch_number );
	$product->update_meta_data( 'coa_number', $coa_number );
	$product->update_meta_data( 'hnamazon_productlink', $hnamazon_productlink );
	$product->update_meta_data( 'hn_upc_code', $hn_upc_code );
	$product->save();
}
add_action( 'woocommerce_process_product_meta', 'hn_save_wc_advanced_custom_fields' );

// End of Amazon Affiliate Link custom field


//UPC codes for variations
function hn_upc_code_field_variations( $loop, $variation_data, $variation ) {
    woocommerce_wp_text_input( array(
        'id' => 'hn_upc_code[' . $loop . ']',
        'class' => 'hn_upc_code_field',
        'label' => __( 'UPC Code', 'woocommerce' ),
        'desc_tip' => true,
        'description' => __( 'Add your GTIN, UPC, EAN, JAN or ISBN code for this variation', 'woocommerce' ),
        'value' => get_post_meta( $variation->ID, 'hn_upc_code', true ),
    ) );
}
add_action( 'woocommerce_variation_options_pricing', 'hn_upc_code_field_variations', 10, 3 );

//only for wholesale user checkbox for variations
function hn_onlyws_field_variations( $loop, $variation_data, $variation ) {
    woocommerce_wp_checkbox( array(
        'id' => 'hn_onlyws[' . $loop . ']',
        'class' => 'hn_onlyws',
        'label' => __( 'Only Wholesale', 'woocommerce' ),
        'desc_tip' => true,
        'description' => __( 'This variation will be available only for Wholesale', 'woocommerce' ),
        'value' => get_post_meta( $variation->ID, 'hn_onlyws', true ),
    ) );
}
add_action( 'woocommerce_variation_options_pricing', 'hn_onlyws_field_variations', 10, 3 );

// Save custom fields for variations
function hn_save_wc_variations_custom_fields( $variation_id, $i ) {
    if( isset( $_POST['hn_upc_code'][$i] ) ) {
        update_post_meta( $variation_id, 'hn_upc_code', sanitize_text_field( $_POST['hn_upc_code'][$i] ) );
    }
	if( isset( $_POST['hn_onlyws'][$i] ) ) {
        update_post_meta( $variation_id, 'hn_onlyws', 'yes' );
    } else {
        delete_post_meta( $variation_id, 'hn_onlyws');
	}
}
add_action( 'woocommerce_save_product_variation', 'hn_save_wc_variations_custom_fields', 10, 2 );


//Assign UPC code as gtin13 to variation
function hn_add_gtin_to_variation_data( $variation_data, $variation ) {
	$variation_id = $variation->get_id();
    $upc_code = get_post_meta( $variation_id, 'hn_upc_code', true );
    if ( ! empty( $upc_code ) ) {
        $variation_data['gtin13'] = $upc_code;
    }
    return $variation_data;
}
add_filter( 'woocommerce_available_variation', 'hn_add_gtin_to_variation_data', 10, 2 );

?>