<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Certification Logos functions
Created: 03/02/2023
Last Update: 24/02/2023
Author: Gabriel Caroprese
*/


/**
* Start of certification logos codes
*/
//Function to return options for products or pages, specially in config page
function ik_hatton_list_options_id($type = 'product', $idSelected = 0){
    $type = sanitize_text_field($type);
    $idSelected = intval($idSelected);
    
    if ($type != 'product'){
        $type = 'page';
    }
    $args = array(
        'post_type' => $type,
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'ASC',
    );

    $option_data = new WP_Query( $args );
    $options_data_list = '';
    while ( $option_data->have_posts() ) : $option_data->the_post();
        global $product;
        
        if ($idSelected === intval(get_the_id())){
            $selected = 'selected';
        } else {
            $selected = '';            
        }
        
        $options_data_list .= '<option '.$selected.' value="'.get_the_id().'">'.get_the_title().'</option>';
    
    endwhile;

    wp_reset_query();
    
    return $options_data_list;
}
add_action('admin_menu', 'ik_hatton_logos_cert_menu');
function ik_hatton_logos_cert_menu(){
    add_submenu_page('woocommerce', 'Logos Certification', 'Logos Certification', 'manage_options', 'ik_hatton_logos_cert_config', 'ik_hatton_logos_cert_config');
}
function ik_hatton_logos_cert_config(){
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    if (isset($_POST['logosurl'])){
        //I take url of certification logos
        $url_logos = esc_url_raw($_POST['logosurl']);
        update_option('ik_hatton_cert_logos_url', $url_logos);
    }
    if (isset($_POST['product_id'])){
        $product_ids = $_POST['product_id'];
        
        //I make sure is an array
        if (is_array($product_ids)){
            
            foreach ($product_ids as $product_id){
                $product_id_to_avoid = intval($product_id);
                if ($product_id_to_avoid > 0){
                    $product_ids_to_avoid[] = $product_id_to_avoid;
                }
            }
            
            if (isset($product_ids_to_avoid)){
                update_option('ik_hatton_products_avoid_cert_logos', $product_ids_to_avoid);
            }
        }
    }
}

$URLlogos = get_option('ik_hatton_cert_logos_url');

$productids = get_option('ik_hatton_products_avoid_cert_logos');

if (is_array($productids)){
    $ik_hatton_avoid_cert_productids = '';
    foreach ($productids as $productid){
        $ik_hatton_avoid_cert_productids .= '<div class="ik_hatton_field_products_avoid_cert_box">
            <select required class="ik_hatton_avoid_cert_product_id" name="product_id[]">
                <option>Select Product</option>
                '.ik_hatton_list_options_id("product", $productid).'
            </select>
            <button class="remove_productid_select button">Remove</button>
        </div>';
    }
}


wp_enqueue_style( 'select2-css', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css', array(), '4.1.0-rc.0');

//Add the Select2 JavaScript file
wp_enqueue_script( 'select2-js', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', 'jquery', '4.1.0-rc.0');

?>
<style>
    #ik_hatton_panel_form_cert_logos label, #ik_hatton_panel_form_cert_logos span, #ik_hatton_panel_form_cert_logos div, #ik_hatton_panel_form_cert_logos input{
        display: block! important;
    }
    #ik_hatton_panel_form_cert_logos label{
        margin: 25px 0;
    }
    #ik_hatton_field_products_avoid_cert .select2-container, #ik_hatton_add_productid_select, #ik_hatton_panel_form_cert_logos .select2-chosen{
        margin-top: 0px;
        max-width: 400px;
    }
    #ik_hatton_add_productid_select{
        margin-bottom: 24px;
        margin-top: -16px;
    }
    .remove_productid_select {
        height: 32px;
        margin-left: 4px! important;
    }
    #ik_hatton_panel_form_cert_logos .select2-chosen{
        min-width: 400px;
    }
    #ik_hatton_field_products_avoid_cert{
        margin-bottom: 30px;
        margin-top: -25px;
    }
    #ik_hatton_field_products_avoid_cert div{
        margin: 4px 0;
        display: flex! important;
    }
    #ik_hatton_panel_form_cert_logos input[type=text], #ik_hatton_panel_form_cert_logos input[type=url]{
        max-width: 400px;
        width: 100%;
        font-size: 12px;
    }
    #ik_hatton_panel_form_cert_logos .select2-with-searchbox{
        display: none! important;
    }
    @media (max-width: 550px){
        #ik_hatton_panel_form_cert_logos .select2-chosen{
            min-width: 280px! important;
        }        
    }
</style>
<div id="ik_hatton_panel_form_cert_logos">
    <h1>Logos Certification</h1>
    <form action="" method="post" enctype="multipart/form-data" autocomplete="no">
        <label for="url_image">
            <span>Certification Logos URL</span>
            <input type="url" name="logosurl" value="<?php echo $URLlogos; ?>" />
        </label>
        <label>
            <span>Don't show certification logos for the following products:</span>
        </label>
        <div id="ik_hatton_field_products_avoid_cert">
			<?php echo $ik_hatton_avoid_cert_productids; ?>
            <div class="ik_hatton_field_products_avoid_cert_box">
    			<select required class="ik_hatton_avoid_cert_product_id" name="product_id[]">
    			    <option>Select Product</option>
    			    <?php echo ik_hatton_list_options_id(); ?>
    			</select>
			</div>
		</div>
		<a href="#" class="button button-primary" id="ik_hatton_add_productid_select">Add Products</a>
    	<input type="submit" class="button-primary" value="Save">
    </form>
</div>
<script>
jQuery(document).ready(function($) {
    jQuery('#ik_hatton_field_products_avoid_cert .ik_hatton_field_products_avoid_cert_box .ik_hatton_avoid_cert_product_id').select2({theme: 'classic'});
    jQuery('#ik_hatton_panel_form_cert_logos').on('click', '#ik_hatton_add_productid_select', function(){
        jQuery('#ik_hatton_field_products_avoid_cert').append('<div class="ik_hatton_field_products_avoid_cert_box"><select required class="ik_hatton_avoid_cert_product_id" name="product_id[]"><option>Select Product</option><?php echo ik_hatton_list_options_id(); ?></select><button class="remove_productid_select button">Remove</button></div>');
        jQuery('#ik_hatton_field_products_avoid_cert .ik_hatton_field_products_avoid_cert_box:last-child .ik_hatton_avoid_cert_product_id').select2({theme: 'classic'});
         return false;
    });
    jQuery('#ik_hatton_panel_form_cert_logos').on('click', '.remove_productid_select', function(){
         jQuery(this).parent().remove();
         return false;
    });
});
</script>
<?php
}
//I add certification logos to loop
add_action( 'woocommerce_after_shop_loop_item', 'ik_hatton_show_certification_logos_loop', 99 );
function ik_hatton_show_certification_logos_loop() {
    $logos_certification = get_option('ik_hatton_cert_logos_url');
    global $product;

    $product_id = $product->get_id();
    if ($product_id !== NULL && $logos_certification !== false && $logos_certification !== NULL && $logos_certification !== ''){
        $show_cert_logos = true;
        $productids = get_option('ik_hatton_products_avoid_cert_logos');
        if (is_array($productids)){
            if(in_array($product_id,$productids)){
                $show_cert_logos = false;           
            }
        }
        if ($show_cert_logos == true){
            echo '<div  class="shop-logo-certification"><img src="'.$logos_certification.'" alt="logos certification organic" /></div>';
        }
    }
}

//I add certification logos to product page
add_action( 'woocommerce_after_single_product_summary' , 'ik_hatton_show_certification_logos_product_page', 5 );
function ik_hatton_show_certification_logos_product_page() {
    $logos_certification = get_option('ik_hatton_cert_logos_url');
    global $product;

    $product_id = $product->get_id();
    if ($product_id !== NULL && $logos_certification !== false && $logos_certification !== NULL && $logos_certification !== ''){
        $show_cert_logos = true;
        $productids = get_option('ik_hatton_products_avoid_cert_logos');
        if (is_array($productids)){
            if(in_array($product_id,$productids)){
                $show_cert_logos = false;           
            }
        }
        if ($show_cert_logos == true){
            echo '<div class="shop-logo-certification"><img src="'.$logos_certification.'" alt="logos certification organic" /></div>
			<script>
			jQuery(".shop-logo-certification").appendTo(".woocommerce-product-gallery .woocommerce-product-gallery__wrapper");
			</script>';
        }
    }
}
/**
* End of certification logos codes
*/

?>