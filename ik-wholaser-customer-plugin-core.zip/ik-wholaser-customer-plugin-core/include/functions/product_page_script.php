<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Product page scripts functions
Created: 03/02/2023
Last Update: 08/10/2023
Author: Gabriel Caroprese
*/

//flter to remove product info tabs
add_filter( 'woocommerce_product_tabs', 'remove_infoproduct_tab', 98 );
function remove_infoproduct_tab( $tabs ) {
    unset( $tabs['additional_information'] ); 
    return $tabs;
}

add_filter( 'woocommerce_product_tabs', 'ik_woo_custom_description_tab', 98 );
function ik_woo_custom_description_tab( $tabs ) {
	$tabs['description']['callback'] = 'ik_woo_custom_description_tab_content';	// Custom description callback
	return $tabs;
}
function ik_woo_custom_description_tab_content() {
	echo the_content().'<h4 class="legal-disclaimer">Legal Disclaimer</h4>
  <p>Statements regarding dietary supplements have not been evaluated by the FDA and are not intended to diagnose, treat, cure, or prevent any disease or health condition.</p>'; 
}

// scripts to mark variations as default checked
add_action( 'wp_footer', 'ik_footer_scripts_product_page' );
function ik_footer_scripts_product_page() {
	if (is_product()){
		$datedelivery = date('Y/m/d');  
		$datedelivery = strtotime($datedelivery);
		$datedelivery = strtotime("+14 day", $datedelivery);
		//I make sure is not weekend
		if(date('D', $datedelivery) == 'Sat' || date('D', $datedelivery) == 'Sun'){
			$datedelivery = strtotime("+2 day", $datedelivery);
		}
		$datedelivery = date('M d', $datedelivery);
		echo '<div id="table_script_prices" style="display:none">'.do_shortcode('[show_table_prices]').'</div>';
		echo "<script>
		let datedelivery = '".$datedelivery."';
		if(jQuery('.woocommerce-product-details__short-description').length < 1){
			jQuery(\"<div class='woocommerce-product-details__short-description'></div>\").insertAfter('.product .grid_col.is-12.is-lg-7 .price');
		}
		if(jQuery('.woocommerce-product-details__short-description #ik_table_price_compare').length < 1){
			if(jQuery('.woocommerce-product-details__short-description').length < 1){
				jQuery(\"<div class='woocommerce-product-details__short-description'>\"+jQuery('#ik_table_price_compare').parent().html()+'</div>').insertAfter('.summary.entry-summary .price');
			} else {
				jQuery('.woocommerce-product-details__short-description').append(jQuery('#ik_table_price_compare').parent().html());
			}
		}
		if (jQuery('.ik_larger_quantities_message').length){
			jQuery('.productinfo-show-discounts').insertBefore('.ik_larger_quantities_message');
			jQuery('.productinfo-show-discounts').attr('style','display: grid;width: 100%;');
		}	
		function ik_variation_description_text_mod(datedelivery){
			if(jQuery('.single_variation_wrap .woocommerce-variation-description').length > 0){
				let notesvariation = jQuery('.single_variation_wrap .woocommerce-variation-description').html();
				
				if( notesvariation.indexOf('the order in 2 weeks') >= 0){
					notesvariation = notesvariation.replace('the order in 2 weeks', 'the order on '+datedelivery+'.');
					jQuery('.single_variation_wrap .woocommerce-variation-description').removeClass('show');
					jQuery('.single_variation_wrap .woocommerce-variation-description').html(notesvariation);
					jQuery('.single_variation_wrap .woocommerce-variation-description').addClass('show');
				} else if( notesvariation !== ''){
					jQuery('.single_variation_wrap .woocommerce-variation-description').addClass('show');
				}
			}
		}
		setInterval(function(){	
			ik_variation_description_text_mod(datedelivery);
		}, 10);
		</script>";
		?>
		<?php
		global $product;
		$product_id = $product->get_id();
		if ($product_id != NULL){
			if (get_post_meta($product_id,'_stock_status', true) == 'outofstock'){
				echo '<script>
					jQuery(".mk-single-product-badges .mk-out-of-stock").attr("style","display: inline-block! important;");
				</script>';
			}

			$shipment_id_asoc = absint(get_post_meta($product_id, 'ik_backorders_prods_shipment_status', true));

			if ($shipment_id_asoc !== 0){
				$shipments_status_backorders = ik_hnaturals_get_shipment_status($shipment_id_asoc);
				if (isset($shipments_status_backorders[0]['eta'])){
				?>
			?>
			<script>
			setInterval(function(){
        		jQuery('.stock.available-on-backorder').each(function() {
					if (!jQuery(this).hasClass('dateadded')){
						jQuery(this).addClass('dateadded');
						jQuery(this).html('<span>Available on backorder.<br />Buy now and orders will be fulfilled by <?php echo $shipments_status_backorders[0]['fullfilment_date']; ?>.</span>');
					}
				});
			}, 500);
			</script>
			<?php
				}
			}


		}
	}
	?>
	<style>
	.woocommerce-variation-description{
		display:none;
		-webkit-transition: all 2.3s linear;
		-moz-transition: all 2.3s ease;
		-ms-transition: all 2.3s ease;
		-o-transition: all 2.3s ease;
		transition: all 2.3s ease;
	}
	.woocommerce-variation-description.show{
		display:block;
	}
	#ik_table_price_compare{
		margin-top: 20px;
	}
	#ik_table_price_compare table{
		max-width: 280px;
		border: 1px solid #f1f1f1;
	}
	#ik_table_price_compare .ik_table_per_pound{
		min-width: 85px;
	}
	#ik_table_price_compare table td, #ik_table_price_compare table th {
		text-align: center;
		vertical-align: middle;
		padding: 16px 7px;
		border-right: 1px solid #fff;
	}
	#ik_table_price_compare table tr td {
		border-right: 1px solid #f1f1f1;
	}
	#ik_table_price_compare table tr:nth-child(2n+1) td, #ik_table_price_compare table th {
		border-right: 1px solid #fff;
	}
	#ik_table_price_compare table tr:nth-child td:last-child {
		border-right: 0px solid #fff! important;
	}
	#ik_table_price_compare .header-table-prices{
		background: #d6df22;
		color: #fff;
	}
	#ik_table_price_compare .details-table-prices:nth-child(2n+1){
		background: #f1f1f1;
	}
	#ik_show_price_comparison {
		cursor: pointer;
		background: #d6df22;
		color: #fff;
		padding: 12px 15px;
		margin-bottom: 20px;
		border: 1px solid #f1f1f1;
		border-radius: 7px;
		font-family: \'Montserrat\';
		font-weight: 600;
	}
	@media (max-width: 360px){
		#ik_table_price_compare table td, #ik_table_price_compare table th {
			padding: 10px 4px! important;
			font-size: 12px! important;
		}
	}
	@media (max-width: 400px){
		#ik_table_price_compare table td, #ik_table_price_compare table th {
			font-size: 13px;
		}
		#ik_table_price_compare table {
			margin: 20px auto;
		}
		#ik_show_price_comparison {
			margin: 0 auto 20px;
			display: block;
		}
	}
	</style>
	<script>
	jQuery( "body" ).on( "click", "#ik_table_price_compare #ik_show_price_comparison", function() {
		if (jQuery(this).attr("show") != "true"){
			jQuery( "#ik_table_price_compare table" ).attr("style", "display: table;");
			jQuery(this).attr("show", "true");
			jQuery(this).text("Hide Price Comparison");
		} else {
			jQuery( "#ik_table_price_compare table" ).attr("style", "display: none;");
			jQuery(this).attr("show", "false");
			jQuery(this).text("Show Price Comparison");
		}
	});
	</script>
	<?php
}

function hn_add_gtin_meta_tag() {
	$attribute_data_variation = 'pa_quantity';
	$attribute_data_variation_slug = 'attribute_'.$attribute_data_variation;

	if ( is_product() && isset($_GET[$attribute_data_variation_slug]) ) {

		global $woocommerce;

		// Get the ID of the current product
		$product_id = get_the_ID();

		// Get the value of the "$attribute_data_variation_slug" attribute
		$product_quantity = $_GET[$attribute_data_variation_slug];

		// Get the variation corresponding to the value of "$attribute_data_variation_slug"
		$product = wc_get_product( $product_id );
		if ( $product ) {
			if ( $product->is_type( 'variable' ) ) {
				$variations = $product->get_available_variations();

				foreach ( $variations as $variation ) {
					$attributes = $variation['attributes'];

					if ( $attributes[$attribute_data_variation_slug] === $product_quantity ) {

						$variation_id = $variation['variation_id'];
						$variation_obj = new WC_Product_Variation( $variation_id );

						// Get the price of the variant formatted as a float number
						$variation_price = $variation_obj->get_price();

						// Check if the variation object exists
						if ( $variation_price) {
							// Validar si el precio de la variación es mayor que cero
							if ( wc_get_price_to_display( $variation_obj ) > 0 ) {

								// Format the price of the variant using the number_format() function to show two decimals
								$variation_price_formatted = number_format( $variation_price, 2, '.', '' );

								// Get the currency code configured in WooCommerce
								$currency = get_woocommerce_currency();

								// Get the attribute name and value for the variation
								foreach ( $attributes as $attribute_slug => $attribute_value_slug ) {
									$taxonomy = str_replace( 'attribute_', '', $attribute_slug );
									$attribute_name = wc_attribute_label( $taxonomy );
									$term = get_term_by( 'slug', $attribute_value_slug, $taxonomy );
									$attribute_value = $term->name;
								}

								$gtin = $variation_obj->get_meta( 'hn_upc_code', true );
								if ( ! empty( $gtin ) ) {
									echo '<meta itemprop="gtin13" content="' . $gtin . '" />';
								} else {
									$gtin = '';
								}


								$variation_data = wc_get_product( $variation_id );
								$sku = $variation_data->get_sku();

								// Add the "price" tag with the value of the variant product's price and currency
								echo '<meta property="og:title" content="'.get_the_title().' ('.$attribute_name.': '.$attribute_value.')" />';
								echo '<meta property="og:sku" content="'.$sku.'" />';
								echo '<meta property="og:price:amount" content="' . $variation_price_formatted . '" />';
								echo '<meta property="og:price:currency" content="' . $currency . '" />';
								echo '<meta itemprop="name" content="'.get_the_title().' ('.$attribute_name.': '.$attribute_value.')" />';
								echo '<meta itemprop="price" content="' . $variation_price_formatted . '" />';
								echo '<meta itemprop="priceCurrency" content="' . $currency . '" />';
								
								echo '
								<script type="application/ld+json">
								{
								  "@context": "https://schema.org/",
								  "@type": "Product",
								  "name": "'.get_the_title().' ('.$attribute_name.': '.$attribute_value.')",
								  "image": "'.wp_get_attachment_url( $product->get_image_id() ).'",
								  "description": "'.$product->get_description().'",
								  "brand": {
									"@type": "Brand",
									"name": "Wholesale Customer"
								  },
								  "offers": [
									{
									  "@type": "Offer",
									  "priceCurrency": "' . $currency . '",
									  "price": "' . $variation_price_formatted . '",
									  "itemCondition": "https://schema.org/NewCondition",
									  "availability": "https://schema.org/InStock",
									  "gtin": "'.$gtin.'",
									  "sku": "'.$sku.'".
									  "seller": {
										"@type": "Organization",
										"name": "Wholesale Customer"
									  }
									}
								  ]
								}
							  </script>';

								break;
							}
						}
					}
				}
			}
		}
	}

}
add_action( 'wp_head', 'hn_add_gtin_meta_tag' );

// Custom tab to show COA data
function hn_add_coa_product_tab( $tabs ) {
	global $product;

	if(is_object($product) && class_exists('IK_HN_COAs')){
		$product_id = $product->get_id();
		
		$coa = new IK_HN_COAs();
		$coa_data_to_show = $coa->show_coa_info_by_woo_product_id($product_id);

		//if info available I show the tab
		if ($coa_data_to_show) {
			//if it has specs
			if (str_contains($coa_data_to_show, '/specs/')) {
				$title_tab = 'COA & Specs Sheet';
			} else {
				$title_tab = 'COA';
			}

			$tabs['COA'] = array(
				'title'    => $title_tab,
				'priority' => 25, // to show before reviews
				'callback' => function () use ($coa_data_to_show) {
                    echo $coa_data_to_show;
                },
			);
		}
	}

    return $tabs;
}
add_filter( 'woocommerce_product_tabs', 'hn_add_coa_product_tab' );

?>