<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Label Generator functions Init 
Created: 01/02/2024
Last Update: 01/12/2024
Author: Gabriel Caroprese
*/

define('IK_HATTON_LABELGEN_CORE_DIR', IK_HATTON_CORE_DIR.'/include/functions/label_generator/');
define('IK_HATTON_LABELGEN_CORE_DIR_PUBLIC', IK_HATTON_CORE_PUBLIC.'/include/functions/label_generator/');
require_once(IK_HATTON_LABELGEN_CORE_DIR.'label_generator.php');
require_once(IK_HATTON_LABELGEN_CORE_DIR.'ajax_functions.php');

//Menu for label generation
function ik_hn_labelgenerator_admin_menu(){
    add_menu_page('Labels', 'Labels', 'manage_options', 'ik_hn_label_generation', 'ik_hn_label_generation', 'dashicons-printer' );
}
add_action('admin_menu', 'ik_hn_labelgenerator_admin_menu');

/*
    Content for label generation
                                    */
function ik_hn_label_generation(){
    include(IK_HATTON_CORE_DIR.'/include/templates/labels.php');
}
?>