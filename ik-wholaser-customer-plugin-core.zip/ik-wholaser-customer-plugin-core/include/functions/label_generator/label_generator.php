<?php
/*

Wholesale Customer Plugin - HN_Labels Class 
Created: 03/02/2023
Last Update: 01/08/2024
Author: Gabriel Caroprese
*/

if ( ! defined('ABSPATH')) exit('restricted access');


class HN_Labels {

    private $templates_config;
    private $temp_folder;

    public function __construct() {
        $this->temp_folder = 'hn_label_temps/';
        $this->templates_config = array(
            0 => array(
                'name' => 'Label Basic',
                'img_filename' => 'labels-4-3.jpg',
                'barcode' => array(
                    'show' => true,
                    'x' => '0',
                    'y' => '950',              
                    'center' => true,
                    'max-height' => '150', //in pixels
                ),
                'texts_format' => array(
                    0 => array(
                        'font' => 'Arial',
                        'style' => 'normal',
                        'color' => '#000',
                        'weight' => '700',
                        'line-height' => 1.3,
                        'divide' => false, //divide into 2 columns
                        'size' => '40',
                        'location' => array(
                            'x' => '0',
                            'y' => '630',
                            'fixed_y' => false, //if true doesn't compare with text above
                            'center' => true,
                            'max_with' => '70%',
                        ),
                    ),
                    1 => array(
                        'font' => 'Arial',
                        'style' => 'italic',
                        'color' => '#000',
                        'weight' => '400',
                        'line-height' => 1.2,
                        'divide' => false, //divide into 2 columns
                        'size' => '26',
                        'location' => array(
                            'x' => '0',
                            'y' => '50',
                            'fixed_y' => false, //if true doesn't compare with text above
                            'center' => true,
                            'max_with' => '65%',
                        ),
                    ),
                    2 => array(
                        'font' => 'Arial',
                        'style' => 'normal',
                        'color' => '#000',
                        'weight' => '500',
                        'line-height' => 1.2,
                        'divide' => false, //divide into 2 columns
                        'size' => '30',
                        'location' => array(
                            'x' => '0',
                            'y' => '50',
                            'fixed_y' => false, //if true doesn't compare with text above
                            'center' => true,
                            'max_with' => '65%',
                        ),
                    ),
                    3 => array(
                        'font' => 'Arial',
                        'style' => 'normal',
                        'color' => '#000',
                        'weight' => '500',
                        'line-height' => 1,
                        'divide' => true, //divide into 2 columns
                        'size' => '27',
                        'location' => array(
                            'x' => '0',
                            'y' => '1134',
                            'fixed_y' => true, //if true doesn't compare with text above                           
                            'center' => true,
                            'max_with' => '65%',
                        ),
                    ),
                ),
            ),
            1 => array(
                'name' => 'Label Flower',
                'img_filename' => 'label-flower.jpg',
                'barcode' => array(
                    'show' => true,
                    'x' => '0',
                    'y' => '950',              
                    'center' => true,
                    'max-height' => '150', //in pixels
                ),
                'texts_format' => array(
                    0 => array(
                        'font' => 'Arial',
                        'style' => 'normal',
                        'color' => '#000',
                        'weight' => '700',
                        'line-height' => 1.3,
                        'divide' => false, //divide into 2 columns
                        'size' => '40',
                        'location' => array(
                            'x' => '0',
                            'y' => '640',
                            'fixed_y' => false, //if true doesn't compare with text above
                            'center' => true,
                            'max_with' => '70%',
                        ),
                    ),
                    1 => array(
                        'font' => 'Arial',
                        'style' => 'italic',
                        'color' => '#000',
                        'weight' => '400',
                        'line-height' => 1.2,
                        'divide' => false, //divide into 2 columns
                        'size' => '26',
                        'location' => array(
                            'x' => '0',
                            'y' => '50',
                            'fixed_y' => false, //if true doesn't compare with text above
                            'center' => true,
                            'max_with' => '65%',
                        ),
                    ),
                    2 => array(
                        'font' => 'Arial',
                        'style' => 'normal',
                        'color' => '#000',
                        'weight' => '500',
                        'line-height' => 1.2,
                        'divide' => false, //divide into 2 columns
                        'size' => '30',
                        'location' => array(
                            'x' => '0',
                            'y' => '50',
                            'fixed_y' => false, //if true doesn't compare with text above
                            'center' => true,
                            'max_with' => '65%',
                        ),
                    ),
                    3 => array(
                        'font' => 'Arial',
                        'style' => 'normal',
                        'color' => '#000',
                        'weight' => '500',
                        'line-height' => 1,
                        'divide' => true, //divide into 2 columns
                        'size' => '27',
                        'location' => array(
                            'x' => '0',
                            'y' => '1134',
                            'fixed_y' => true, //if true doesn't compare with text above                           
                            'center' => true,
                            'max_with' => '65%',
                        ),
                    ),
                ),
            ),
        );
    }

    private function processLabelImage($template_id, $texts, $barcode) {
        // clean old temp files
        $this->cleanTmpFolder();
        $template = $this->getTemplateById($template_id);
    
        if (!$template) {
            // Handle the case where the template with the given ID doesn't exist
            return false;
        }
    
        $image = imagecreatefromjpeg(IK_HATTON_LABELGEN_CORE_DIR.'/label_img/'.$template['img_filename']);
        $image_width = imagesx($image);
    
        $y_offset = 0;
    
        foreach ($texts as $indexText => $text) {
            list($x, $y_offset) = $this->addText($image, $text, $template['texts_format'][$indexText], $image_width, $y_offset);
        }
    
        // Process the barcode
        if($barcode && isset($template['barcode'])){
            // Check if image creation was successful
            $barcodeImage_data = $this->process_barcode($barcode, $template['barcode'], $image_width);
            if ($barcodeImage_data !== false) {    

                imagecopy($image, $barcodeImage_data['image'], $barcodeImage_data['x'], $barcodeImage_data['y'], 0, 0, $barcodeImage_data['width'], $barcodeImage_data['height']);

                imagedestroy($barcodeImage_data['image']);
            }
        }
    
        // Save the processed image to a temporary file
        $temp_file_name = 'processed_image_' . uniqid() . '.jpg';
        $temp_filename = $this->get_temp_folder().$temp_file_name;
        $public_temp_file_url = $this->get_temp_folder(true).$temp_file_name;
        imagejpeg($image, $temp_filename);
    
        // Return the path to the temporary image file
        return $public_temp_file_url;
    }

    private function addText($image, $text_array, $template, $image_width, $y_offset = 0) {
        // Extract text from the array
        $text = isset($text_array['text']) ? (string)$text_array['text'] : '';
        $color = isset($template['color']) ? $this->hexToRgb($template['color']) : array(0, 0, 0); // Default to black if no color is specified
        $color = imagecolorallocate($image, $color[0], $color[1], $color[2]);
    
        // Extract numeric part of the size and ensure it's an integer
        $size = (int)filter_var($template['size'], FILTER_SANITIZE_NUMBER_INT);
    
        // Set the font style based on the provided template
        // Get the font path using the provided font, style, and weight
        $font_path = $this->getFontPath($template['font'], $template['style'], $template['weight']);
    
        // Use a fallback font if the font path is empty or invalid
        if (empty($font_path) || !file_exists($font_path)) {
            // Replace this with the path to your fallback font
            $font_path = IK_HATTON_LABELGEN_CORE_DIR . 'fonts/arial.ttf';
        }
    
        // Word wrap the text based on the specified max width
        $wrapped_text = wordwrap($text, $this->calculateMaxCharsPerLine($template, $image_width), "\n", false);
    
        // Split the wrapped text into an array of lines
        $lines = explode("\n", $wrapped_text);
    
        $text_height = 0;
    
        // Extract line-height from the template
        $line_height = isset($template['line-height']) ? (float)$template['line-height'] : 1;
    
        // Iterate through each line and add it to the image
        foreach ($lines as $line) {
            $text_box = imagettfbbox($size, 0, $font_path, $line);
    
            $text_width = $text_box[2] - $text_box[0];
            $text_height = $text_box[1] - $text_box[7];
    
            $x = $template['location']['center'] ? ($image_width - $text_width) / 2 : $template['location']['x'];

            // Check if "fixed_y" is true, then set y based on the height of the image
            if (!$template['location']['fixed_y']) {
                $y = $template['location']['y'] + $y_offset;
            } else {
                $y = $template['location']['y'];
            }
            
            // Calculate the vertical spacing based on line-height
            $line_height_offset = $text_height * $line_height;
    
            imagettftext($image, $template['size'], 0, intval($x), intval($y) + intval($line_height_offset), $color, $font_path, $line);
    
            $y_offset += $line_height_offset;
        }
    
        // Check if "fixed_y" is true, then set y based on the height of the image
        if (!$template['location']['fixed_y']) {
            $y = $y + $text_height;
        } else {
            $y = $template['location']['y'];
        }

        return array($x, $y);
    }

    //method to process barcodes
    private function process_barcode($barcode, $template_data, $image_width){
        // Detect image type
        $imageType = exif_imagetype($barcode);

        // Create image resource based on detected type
        $barcodeImage = false;

        if ($imageType === IMAGETYPE_PNG) {
            $barcodeImage = imagecreatefrompng($barcode);
        } elseif ($imageType === IMAGETYPE_JPEG) {
            $barcodeImage = imagecreatefromjpeg($barcode);
        } else {
            // Handle other image types or throw an error
            // For simplicity, let's assume it's PNG if not detected as JPEG
            $barcodeImage = imagecreatefrompng($barcode);
        }

        if($barcodeImage){
            $barcodeWidth = imagesx($barcodeImage);
            $barcodeHeight = imagesy($barcodeImage);
            $barcodeCenter = isset($template_data['center']) ? rest_sanitize_boolean($template_data['center']) : false;
        
            $maxHeight = ($template_data['max-height']) ? intval($template_data['max-height']) : 200; // Adjust the max-height as needed
            $targetHeight = intval(min($barcodeHeight, $maxHeight));
            $targetWidth = intval(($targetHeight / $barcodeHeight) * $barcodeWidth);
            $barcodeX = (isset($template_data['x'])) ? intval($template_data['x']) : 0;
            $barcodeX = ($barcodeCenter) ? intval(($image_width - $targetWidth) / 2) : $barcodeX;
            $barcodeY = (isset($template_data['y'])) ? intval($template_data['y']) : 0; 
            $resizedBarcode = imagecreatetruecolor($targetWidth, $targetHeight);
            // Fill the background with white to avoid transparency issues in JPEG
            $white = imagecolorallocate($resizedBarcode, 255, 255, 255);
            imagefilledrectangle($resizedBarcode, 0, 0, $targetWidth, $targetHeight, $white);
    
            // Enable alpha blending for the resized image
            imagealphablending($resizedBarcode, true);
    
            // Save alpha channel for the resized image
            imagesavealpha($resizedBarcode, true);
            imagecopyresampled($resizedBarcode, $barcodeImage, 0, 0, 0, 0, $targetWidth, $targetHeight, $barcodeWidth, $barcodeHeight);
    
            // Convert PNG to JPEG
            imagejpeg($resizedBarcode, $barcode, 100);
    
            // Load the converted image back
            $barcodeImage = imagecreatefromjpeg($barcode);
            imagedestroy($resizedBarcode);

            //create array to send data
            $barcodeImageData = array(
                'image' => $barcodeImage,
                'x' => $barcodeX,
                'y' => $barcodeY,
                'width' => $targetWidth,
                'height' => $targetHeight,
            );

            return $barcodeImageData;
        }
        return false;
    }
    
    private function calculateMaxCharsPerLine($template, $image_width) {
        // Get the specified max width value
        $max_width_value = $template['location']['max_with'];
    
        // Check if the value is specified as a percentage or pixel value
        if (strpos($max_width_value, '%') !== false) {
            // If it's a percentage, calculate the maximum number of characters based on the percentage
            $max_width_percentage = rtrim($max_width_value, '%');
            $max_text_width = $max_width_percentage * $image_width / 100;
        } else {
            // If it's a pixel value, use it directly
            $max_text_width = (float)$max_width_value;
        }
    
        // Assume an average character width of 0.6 times the font size
        $average_char_width = 0.6;
    
        // Calculate the maximum number of characters per line
        $max_chars_per_line = $max_text_width / ($average_char_width * $template['size']);
    
        return (int)$max_chars_per_line;
    }
    
       

    private function getTemplateById($template_id) {
        // Check if the template with the given ID exists
        if (isset($this->templates_config[$template_id])) {
            // Return the template with the specified ID
            return $this->templates_config[$template_id];
        } else {
            // Return null if the template with the given ID doesn't exist
            return null;
        }
    }    
    
    private function getFontPath($font, $style, $weight) {
        // Map the style to the corresponding suffix in the font file names
        $style_suffix = '';
        if ($style === 'italic') {
            $style_suffix = 'i';
        } elseif ($style === 'normal') {
            $style_suffix = 'n';
        }
    
        // Map the weight to the corresponding suffix in the font file names
        $weight_suffix = '';
        if ($weight === '700') {
            $weight_suffix = 'b'; // Bold
        } elseif ($weight === '500') {
            if($style === 'normal'){
                $weight_suffix = ''; // Regular
            } else {
                $weight_suffix = 'm'; // Medium
            }
        } else {
            $weight_suffix = ''; // normal
        }
    
        // Build the font file name based on the provided font, style, and weight
        $font_file = "$font$style_suffix$weight_suffix.ttf";
    
        // Adjust this to the actual path on your server
        $font_path = IK_HATTON_LABELGEN_CORE_DIR . 'fonts/' . $font_file;
    
        return $font_path;
    }
    

    private function resizeImageAndOverlay($image, $barcode_path, $x, $y, $max_width) {
        $barcode_image = imagecreatefromjpeg($barcode_path);

        $barcode_width = imagesx($barcode_image);
        $barcode_height = imagesy($barcode_image);

        $new_height = ($max_width / $barcode_width) * $barcode_height;

        $resized_barcode = imagescale($barcode_image, $max_width, $new_height);

        imagecopy($image, $resized_barcode, $x, $y, 0, 0, imagesx($resized_barcode), imagesy($resized_barcode));

        imagedestroy($barcode_image);
        imagedestroy($resized_barcode);
    }
    // Function to convert hex to RGB
    private function hexToRgb($hex) {
        $hex = str_replace("#", "", $hex);
        return array(
            hexdec(substr($hex, 0, 2)),
            hexdec(substr($hex, 2, 2)),
            hexdec(substr($hex, 4, 2)),
        );
    }

    //get temp folder and validate it exists
    public function get_temp_folder($public_url = false){
        //I create a catalog folder if doesn't exist
        $upload = wp_upload_dir();
        $upload_dir = $upload['basedir'];
        $tmp_folder = $upload_dir . '/'.$this->temp_folder;
        $upload_dir_public = $upload['baseurl'].'/'.$this->temp_folder;
        if (! is_dir($tmp_folder)) {
            mkdir( $tmp_folder, 0755 );
        }

        //Create index file to avoid navigation
        $index_file_path = $tmp_folder.'/index.php';

        // Verify if exists file to avoid navigation no matter what
        if ( ! file_exists( $index_file_path ) ) {
            $content_index = '<?php 
            //silence is golden 
            ?>';
            file_put_contents( $index_file_path, $content_index );
        }

        if($public_url){
            return $upload_dir_public;          
        }
        
        return $tmp_folder;
    }

    // function to clean up JPEG temp files
    private function cleanTmpFolder() {
        $tmp_folder = $this->get_temp_folder();

        $files = glob($tmp_folder . '*.jpg');

        // search for files older than 12 hours
        $cutoff_time = time() - 43200;

        foreach ($files as $file) {
            $file_mtime = filemtime($file);

            // Verify dates
            if ($file_mtime < $cutoff_time) {
                // delete file
                unlink($file);
            }
        }

    }

    //get the form fields for the form to generate labels
    private function get_form_fields($template_id){
        $template_id = intval($template_id);

        //if template exists
        if(isset($this->templates_config[$template_id]['texts_format'])){
            $text_n = 1;
            $form_fields = '';
            foreach ($this->templates_config[$template_id]['texts_format'] as $text){
                //if it's a column text
                if($text['divide']){
                    $form_fields .= '<label>
                        <h4>Text #'.$text_n.' Left Part</h4>
                        <input required type="text" name="text'.$text_n.'_1" autocomplete="off" />
                    </label>';
                    $form_fields .= '<label>
                        <h4>Text #'.$text_n.' Right Part</h4>
                        <input required type="text" name="text'.$text_n.'_2" autocomplete="off" />
                    </label>';
                } else {
                    //if it's a line text
                    $form_fields .= '<label>
                        <h4>Text #'.$text_n.'</h4>
                        <input required type="text" name="text'.$text_n.'" autocomplete="off" />
                    </label>';
                }
                $text_n = $text_n + 1;
            }

            if(isset($this->templates_config[$template_id]['barcode'])){
                $barcode_data = $this->templates_config[$template_id]['barcode'];
                if($barcode_data['show']){
                    $form_fields .= '<label>
                        <h4>Barcode Image (optional)</h4>
                        <p id="ik_hn_barcode_file"><p>
                        <input type="hidden" name="ik_hn_barcode_image_id" id="ik_hn_barcode_image_id" class="regular-text" />
                        <button class="button-primary" style="width: 100%" id="ik_hn_barcode_upload_img">Upload Barcode</button>
                    </label>';
                }
            }

            return $form_fields;
        }
        //returns empty
        return '';
    }    

    //form to generate label
    public function get_form($template_id = 0){

        $template_id = intval($template_id);
        //dropdown to select template and run ajax to update form
        $select_template = '<div id="ik_hn_label_form_wrapper">
        <h3>Label Template</h3>
        <select id="ik_hn_label_select_template">';
        foreach ($this->templates_config as $id => $template){
            $template_selected = ($template_id == $id) ? 'selected' : '';
            $select_template .= '<option '.$template_selected.' value="'.$id.'">'.$template['name'].'</option>';
        }
        $select_template .= '</select>';

        $first_template_image_url = (isset($this->templates_config[$template_id]['img_filename'])) ? IK_HATTON_LABELGEN_CORE_DIR_PUBLIC.'/label_img/'.$this->templates_config[$template_id]['img_filename'] : false;
        $first_template_image = ($first_template_image_url) ? '<img src="'.$first_template_image_url.'" alt="label" />' : '';

        //create form for first dropdown option
        $form = '<form action="" method="post" id="ik_hn_label_form" enctype="multipart/form-data" autocomplete="no">';
        $form .= $this->get_form_fields($template_id);
        $form .= '<button class="button-primary" id="ik_hn_label_btn_generate">Generate</button>
        </form>
        </div>
        <div id="ik_hn_label_generated">
            '.$first_template_image.'
            <a class="button" id="ik_hn_label_generate_btn" href="'.$first_template_image_url.'" target="_blank">Download Label</a>
        <div>';

        $output = $select_template.$form;


        return $output;
    }

    //method to generate label processing form fields
    public function generate_label($formData, $selected_template, $barcode_img_id) {
        // Get the selected template ID from the form data
        $selected_template = isset($selected_template) ? intval($selected_template) : 0;
    
        // Check if the selected template ID exists in templates_config
        if (isset($this->templates_config[$selected_template])) {
            // Get the template data
            $template = $this->templates_config[$selected_template];
    
            // Extract relevant information from the form data
            $texts = array();

            // Check if 'texts_format' is set in templates_config
            if (isset($this->templates_config[$selected_template]['texts_format'])) {
                $textFormats = $this->templates_config[$selected_template]['texts_format'];

                foreach ($textFormats as $index => $textFormat) {
                    // Generate the input names based on the index and whether 'divide' is set
                    $inputNamePrefix = 'text' . ($index + 1);
                    $inputNames = array($inputNamePrefix);

                    // Check if 'divide' is set and true
                    if (isset($textFormat['divide']) && $textFormat['divide']) {
                        // Add an additional level of indexing for each part
                        for ($part = 1; $part <= 2; $part++) {  // Assuming it's divided into 2 parts, adjust as needed
                            $inputNames[] = $inputNamePrefix . '_' . $part;
                        }
                    }

                    // Check if the input exists in the form data
                    $textValues = array();
                    foreach ($inputNames as $inputName) {
                        foreach ($formData as $field) {
                            if ($field['name'] == $inputName) {
                                $text = sanitize_text_field($field['value']);
                                $text = str_replace("\\", "", $text);
                                $textValues[] = $text;
                            }
                        }
                    }

                    // Combine values if there are multiple parts
                    $texts[] = array('text' => implode('  |  ', $textValues));
                }
            }
    
            // Check if barcode should be processed
            $barcode = false;
            if (isset($template['barcode']['show'])){
                if(rest_sanitize_boolean($template['barcode']['show'])) {
                    // Check if a file was submitted
                    if ($barcode_img_id > 0) {
                        // Process the barcode image
                        $upload = wp_upload_dir();
                        $upload_dir = $upload['basedir'];
                        $barcode = $upload_dir.'/'.get_post_meta( $barcode_img_id, '_wp_attached_file', true);
                    }
                }
            }
    
            // Process the label image
            $label_image = $this->processLabelImage($selected_template, $texts, $barcode);
    
            // Return the label image or handle it as needed
            return $label_image;
        } else {
            // Handle the case when the selected template ID is invalid
            return false;
        }
    }
}
?>
