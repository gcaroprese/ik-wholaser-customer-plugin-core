<?php

/*
Silence is great 
*/