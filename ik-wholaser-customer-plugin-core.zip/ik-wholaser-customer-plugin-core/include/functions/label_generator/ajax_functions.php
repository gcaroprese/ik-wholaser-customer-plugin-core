<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - // Ajax Label Generation
Created: 01/15/2024
Last Update: 01/15/2024
Author: Gabriel Caroprese
*/

//ajax to upload template selection
add_action( 'wp_ajax_ik_hn_label_ajax_update_template', 'ik_hn_label_ajax_update_template'   );
function ik_hn_label_ajax_update_template() {
    if(isset($_POST['selected_template'])){
        $template_id = intval($_POST['selected_template']);
        $labels = new HN_Labels();
        $form = $labels->get_form($template_id);
        wp_send_json($form);
    }
    // Always exit to prevent extra output
    wp_die();
}


//ajax to upload barcode image file
add_action( 'wp_ajax_ik_hn_label_ajax_upload_barcode', 'ik_hn_label_ajax_upload_barcode'   );
function ik_hn_label_ajax_upload_barcode() {
    if(isset($_GET['id']) ){
        $id_file = intval($_GET['id']);
        $image_name = get_post_meta($id_file, '_wp_attached_file', true);
        wp_send_json_success( $image_name );
    } else {
        wp_send_json_error();
    }
}

//ajax to process the form to generate label
function ik_hn_label_ajax_process_form() {
    if(isset($_POST['form_data']) && isset($_POST['selected_template']) && isset($_POST['barcode_img_id'])){
        // Retrieve form data from AJAX request
        $formData = $_POST['form_data'];
        $barcode_img_id = intval($_POST['barcode_img_id']);
        $labels = new HN_Labels();
        // Process form data as needed
        $label_image = $labels->generate_label($formData, $_POST['selected_template'], $barcode_img_id);
        wp_send_json($label_image);
    }
    // Always exit to prevent extra output
    wp_die();
}
// Hook for the WordPress AJAX action
add_action('wp_ajax_ik_hn_label_ajax_process_form', 'ik_hn_label_ajax_process_form');

?>