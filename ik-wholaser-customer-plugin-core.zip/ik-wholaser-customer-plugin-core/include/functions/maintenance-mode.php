<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Maintenance mode functions and notifications
Created: 03/02/2023
Last Update: 24/02/2023
Author: Gabriel Caroprese
*/

//scripts for wp_head
add_action('wp_head', 'ik_hnaturals_head_scripts_maintenance');
function ik_hnaturals_head_scripts_maintenance(){

	$show_message = (get_option('HN_SHOW_MESSAGE') == 'yes') ? true : false;

	if ($show_message == true && !current_user_can('administrator')) {
		$message_to_show = (get_option('HN_MESSAGE_TO_SHOW')) ? html_entity_decode(get_option('HN_MESSAGE_TO_SHOW')) : '';
		$disable_orders = (get_option('HN_DISABLE_ORDERS') == 'yes') ? true : false;

		?>
		<style>
		.store-maintenance{
			background: #d6df22;
			padding: 20px 3%;
			position: relative;
			top: 0;
			z-index: 9999999999999;
			color: #fff;
			text-align: center;
			font-size: 1.2em;
			width: 100%;
		}
		.store-maintenance a{
			color: #fff;
		}	
		.ik-checkout-message{
			font-size: 21px;
		}
		.ik-get-a-quote{
			color: #fff! important;
			font-weight: bold;
			background: #d6df22!important;
			border: 1px solid #d6df22;
			padding: 10px;
			font-size: .9em!important;
			text-transform: uppercase;
			margin-top: 8px;
			position: relative;
			top: 7px;
			display: block;
			max-width: 285px;
			text-align: center;
		}
		</style>
		<div class="store-maintenance">
		<?php echo $message_to_show; ?>
		</div>
		<?php
		if($disable_orders){ 
		?>
			<script>
			setInterval(function(){ 
			jQuery('.checkout-button.button.wc-forward').removeAttr('href');
			jQuery('.product-loop-thumb .product_loop_button_text').text('Read More');
			jQuery('.mk-product-warp .button-text').text('Read More');
			jQuery('<div class="ik-checkout-message">Online Orders Disabled.Please request a quote or send any inquiries to info@hattonnaturals.com, as we will be monitoring emails. We will do our best to get back to you as soon as possible. Thank you.</div>').insertAfter('.woocommerce-checkout .checkout.woocommerce-checkout');
			jQuery('.woocommerce-checkout .checkout.woocommerce-checkout').remove();
			jQuery('.woocommerce-form-coupon-toggle').remove();
			jQuery('.single-product .attribute-select-quantity').remove();
			jQuery('.single-product .quantity.buttons_added').remove();
			jQuery('.single-product .hnamazon_productlink').remove();
			jQuery('<a class="ik-get-a-quote" href="/contact-us/">Request A Quote</a>').insertAfter('.single_add_to_cart_button.button.wc-variation-selection-needed');
			jQuery('.single_add_to_cart_button.button').remove();
			}, 1000);
			</script>
			<script>
			setInterval(function(){ 
				jQuery('.mk-header-holder').attr('style', 'margin-top: calc('+jQuery('.store-maintenance').height()+'px + 10px)');
			}, 200);
			</script>
		<?php
		}
	}
}

//Don't send emails about updates or password changed
function ik_hnaturals_stop_update_emails( $send, $type, $core_update, $result ) {
    if ( $type === 'plugin' ) {
        return false;
    }
    return true;
}
add_filter( 'auto_core_update_send_email', 'ik_hnaturals_stop_update_emails', 10, 4 );
function ik_hnaturals_disable_password_change_email( $send, $user_id, $userdata ) {
    return false;
}
add_filter( 'send_password_change_email', 'ik_hnaturals_disable_password_change_email', 10, 3 );

?>