<?php
/*

Wholesale Customer Plugin - COAs Init
Created: 03/02/2023
Last Update: 03/08/2023
Author: Gabriel Caroprese

*/

//DB for COA
function ik_hn_coa_db_creation(){
    //Create coas folder
    $upload = wp_upload_dir();
    $upload_dir = $upload['basedir'];
    $uploads_coas = $upload_dir . '/coas';
    $uploads_specs = $upload_dir . '/specs';
    if (! is_dir($uploads_coas)) {
        mkdir( $uploads_coas, 0755 );
    }
    if (! is_dir($uploads_specs)) {
        mkdir( $uploads_specs, 0755 );
    }

    //Create index file to avoid navigation
    $index_file_path = $upload_dir . '/coas/index.php';
    $index_file_specs_path = $upload_dir . '/specs/index.php';

    // Verify if exists file to avoid navigation no matter what
    if ( ! file_exists( $index_file_path ) ) {
        $content_index_coas = '<?php 
        //silence is golden 
        ?>';
        file_put_contents( $index_file_path, $content_index_coas );
    }
    if ( ! file_exists( $index_file_specs_path ) ) {
        $content_index_specs = '<?php 
        //silence is golden 
        ?>';
        file_put_contents( $index_file_specs_path, $content_index_specs );
    }

    //Create DB tables
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $ik_hn_products = $wpdb->prefix . 'ik_hn_coa_products';
    $ik_hn_products_coas = $wpdb->prefix . 'ik_hn_coa_data';

    $sql = "
    CREATE TABLE IF NOT EXISTS ".$ik_hn_products." (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        product_woo_id bigint(20) NOT NULL,
        product_name varchar(255) NOT NULL,
        botanical_name varchar(255) NOT NULL,
        basic_data longtext NOT NULL,
        sku_code varchar(17) NOT NULL,
        upc_code varchar(13) NOT NULL,
        created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        edited datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        product_details longtext NOT NULL,
        UNIQUE KEY id (id)
    ) ".$charset_collate.";
    CREATE TABLE IF NOT EXISTS ".$ik_hn_products_coas." (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        lot_number varchar(15) NOT NULL,
        product_id bigint(10) NOT NULL,
        batch_number varchar(17) NOT NULL,
        country_origin varchar(255) NOT NULL,
        cut_size varchar(20) NOT NULL,
        packaging_date date DEFAULT '0000-00-00' NOT NULL,
        shelf_life varchar(255) NOT NULL,
        compliance varchar(255) NOT NULL,
        packaging_type varchar(255) NOT NULL,
        uploaded datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        edited datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        file_name varchar(255) NOT NULL,
        spec_file varchar(255) NOT NULL,
        more_details longtext NOT NULL,
        UNIQUE KEY id (id)
    ) ".$charset_collate.";";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}

//Menu for COAs DB
function ik_hn_coa_admin_menu(){
    add_menu_page('COAs', 'COAs', 'manage_options', 'ik_hn_coa_db_menu', 'ik_hn_coa_db_menu' );
    add_submenu_page('ik_hn_coa_db_menu', 'COAs', 'COAs', 'manage_options', 'ik_hn_coa_db_menu', 'ik_hn_coa_db_menu', 1 );
    add_submenu_page('ik_hn_coa_db_menu', 'Products', 'Products', 'manage_options', 'ik_hn_coa_products', 'ik_hn_coa_products', 2 );
    add_submenu_page('ik_hn_coa_db_menu', 'Recaptcha', 'Recaptcha', 'manage_options', 'ik_hn_coa_recaptcha', 'ik_hn_coa_recaptcha', 3 );
}
add_action('admin_menu', 'ik_hn_coa_admin_menu');

/*
    Content for COAs DB menu
                                    */
function ik_hn_coa_db_menu(){
    include(IK_HATTON_CORE_COAS_DIR.'/templates/coas.php');
}
function ik_hn_coa_products(){
    include(IK_HATTON_CORE_COAS_DIR.'/templates/product.php');
}
function ik_hn_coa_recaptcha(){
    include(IK_HATTON_CORE_COAS_DIR.'/templates/recaptcha.php');
}

//Scripts and styles WP Admin
function ik_hn_coa_add_css() {
	wp_register_style( 'ik_hn_coa_admin_css_style', IK_HATTON_CORE_COAS_DIR_PUBLIC . 'css/style-admin.css', false, '1.1.15', 'all' );
	wp_enqueue_style('ik_hn_coa_admin_css_style');
}
add_action( 'admin_enqueue_scripts', 'ik_hn_coa_add_css' );

//Alow pdf files for COA upload
function ik_hn_coa_myme_types($mime_types){
    $mime_types['pdf'] = 'application/pdf';
return $mime_types;
}
add_filter('upload_mimes', 'ik_hn_coa_myme_types', 1, 1);

?>