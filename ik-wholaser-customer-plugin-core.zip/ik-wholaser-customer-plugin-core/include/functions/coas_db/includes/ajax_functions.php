<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - COAs DB Ajax Functions
Created: 03/02/2023
Last Update: 03/22/2023
Author: Gabriel Caroprese
*/

//Ajax to delete a COA
add_action( 'wp_ajax_ik_hn_coa_db_ajax_delete_coa', 'ik_hn_coa_db_ajax_delete_coa');
function ik_hn_coa_db_ajax_delete_coa(){
    if(isset($_POST['iddata'])){
        $iddata = absint($_POST['iddata']);
        
        $coa = new IK_HN_COAs;

        $coa->delete($iddata);
        echo json_encode( true );
    }
    wp_die();         
}

//Ajax to delete a COA Product
add_action( 'wp_ajax_ik_hn_coa_db_ajax_delete_coa_product', 'ik_hn_coa_db_ajax_delete_coa_product');
function ik_hn_coa_db_ajax_delete_coa_product(){
    if(isset($_POST['iddata'])){
        $iddata = absint($_POST['iddata']);
        
        $coa = new IK_HN_COA_Product;

        $coa->delete_product($iddata);
        echo json_encode( true );
    }
    wp_die();         
}

//Ajax function to search COA info
add_action('wp_ajax_nopriv_ik_hn_coa_submit_ajax_search', 'ik_hn_coa_submit_ajax_search');
add_action( 'wp_ajax_ik_hn_coa_submit_ajax_search', 'ik_hn_coa_submit_ajax_search');
function ik_hn_coa_submit_ajax_search(){
    //default response
    $result = 'Not Found';
    if(isset($_POST['searchby']) && isset($_POST['keyword'])){

        $coa = new IK_HN_COAs;
        
        //If recaptcha is active
        $recaptcha_config = $coa->get_config();

        if ($recaptcha_config['enabled']){
            if(isset($_POST['recaptcha']) || isset($_POST['g-recaptcha-response'])){
                if (isset($_POST['recaptcha'])){
                    $captcha = sanitize_text_field($_POST['recaptcha']);
                } else {
                    $captcha = sanitize_text_field($_POST['g-recaptcha-response']);
                }
            } else {
                $recapchaoptionData = $recaptcha_config['option'];
                if ($recapchaoptionData == 'v3'){
                    $captcha = false;
                } else {
                    $captcha = true;
                }
            }
            
            $secretKey = $recaptcha_config['secret'];
            $ip = $_SERVER['REMOTE_ADDR'];
            $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
            $response = file_get_contents($url);
            $responseKeys = json_decode($response,true);
            
            if ($responseKeys["success"] === true){
                $recaptchaOk = true;
            } else{
                $recaptchaOk = false;
            }

        } else {
            $recaptchaOk = true;
        }
        
        //If recaptcha disabled or recaptcha done OK
        if($recaptchaOk == true) {

            //Do search
            $qty = 15;
            $offsetList = '';
            $orderby = 'id';
            $orderDir = 'DESC';
            $search = sanitize_text_field($_POST['keyword']);
            $search = str_replace('\"', '"', $search);
            $search = str_replace("\'", "'", $search);
            $search_type = (sanitize_text_field($_POST['searchby']) == 'product_name') ? 'product_name' : 'lot_number';

            $found = $coa->get_coa_list($qty, $offsetList, $orderby, $orderDir, $search, $search_type);


            $coas_found = (isset($found['data'])) ? $found['data'] : NULL;

            if (isset($coas_found[0]->id)){
                // If data exists
                $found_info = '';
                foreach ($coas_found as $coa_found){

                    $product_name = $coa_found->product_name;
                    if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {


                        $product = wc_get_product($coa_found->product_woo_id);

                        if($product){
                            $product_name = '<a href="'.get_permalink($coa_found->product_woo_id).'" target="_blank">'.$coa_found->product_name.'</a>';
                        }
                    }

                    $uploads_folder = wp_upload_dir()['baseurl'];
                    if($coa_found->file_name !== ''){
                        $file_url = $uploads_folder.'/coas/'.$coa_found->file_name;
                        $file_data = '
                        <div class="ik_hn_coas_file_download">
                            <a target="_blank" href="'.$file_url .'">Download COA File</a>
                        </div>';
                    } else {
                        $file_data = '';
                    }

                    if($coa_found->spec_file !== ''){
                        $specs_url = $uploads_folder.'/specs/'.$coa_found->spec_file;
                        $specs_data = '
                        <div class="ik_hn_coas_file_download specsheet">
                            <a target="_blank" class="button alt" href="'.$specs_url .'">Download Spec Sheet</a>
                        </div>';
                    } else {
                        $specs_data = '';
                    }

                    $packaging_date = ($coa_found->packaging_date != '0000-00-00') ? '
                    <div class="ik_hn_coas_packaging_date">
                        <span class="ik_hn_coas_title">Packing Date:</span>
                        <span class="ik_hn_coas_data">'.$coa_found->packaging_date.'</span>
                    </div>': '';                    
                    $packaging_type = ($coa_found->packaging_type != '') ? '
                    <div class="ik_hn_coas_packaging_type">
                        <span class="ik_hn_coas_title">Packing Type:</span>
                        <span class="ik_hn_coas_data">'.$coa_found->packaging_type.'</span>
                    </div>': '';
                    $shelf_life = ($coa_found->shelf_life != '') ? '
                    <div class="ik_hn_coas_shelf_life">
                        <span class="ik_hn_coas_title">Shelf Life:</span>
                        <span class="ik_hn_coas_data">'.$coa_found->shelf_life.'</span>
                    </div>': '';
                    $compliance = ($coa_found->compliance != '') ? '
                    <div class="ik_hn_coas_compliance">
                        <span class="ik_hn_coas_title">Compliance:</span>
                        <span class="ik_hn_coas_data">'.$coa_found->compliance.'</span>
                    </div>': '';
                    $compliance = ($coa_found->compliance != '') ? '
                    <div class="ik_hn_coas_compliance">
                        <span class="ik_hn_coas_title">Compliance:</span>
                        <span class="ik_hn_coas_data">'.$coa_found->compliance.'</span>
                    </div>': '';
                    $compliance = ($coa_found->compliance != '') ? '
                    <div class="ik_hn_coas_compliance">
                        <span class="ik_hn_coas_title">Compliance:</span>
                        <span class="ik_hn_coas_data">'.$coa_found->compliance.'</span>
                    </div>': '';
                    $basic_data = ($coa_found->basic_data != '') ? '
                    <div class="ik_hn_coas_basic_data">
                        <span class="ik_hn_coas_title">Basic Data:</span>
                        <span class="ik_hn_coas_data">'.$coa_found->basic_data.'</span>
                    </div>': '';
                    $sku_code = ($coa_found->sku_code != '') ? '
                    <div class="ik_hn_coas_sku_code">
                        <span class="ik_hn_coas_title">SKU:</span>
                        <span class="ik_hn_coas_data">'.$coa_found->sku_code.'</span>
                    </div>': '';
                    $upc_code = ($coa_found->upc_code != '') ? '
                    <div class="ik_hn_coas_upc_code">
                        <span class="ik_hn_coas_title">UPC:</span>
                        <span class="ik_hn_coas_data">'.$coa_found->upc_code.'</span>
                    </div>': '';
                    $product_details = ($coa_found->product_details	 != '') ? '
                    <div class="ik_hn_coas_product_details	">
                        <span class="ik_hn_coas_title">Product Details:</span>
                        <span class="ik_hn_coas_data">'.$coa_found->product_details	.'</span>
                    </div>': '';

                    $more_details = ($coa_found->more_details != '') ? '
                    <div class="ik_hn_coas_more_details">
                        <span class="ik_hn_coas_title">More Details:</span>
                        <span class="ik_hn_coas_data">'.$coa_found->more_details.'</span>
                    </div>': '';
                    
                    $found_info .= '
                        <div class="data_coa_found">
                            <div class="ik_hn_coas_lot_number">
                                <span class="ik_hn_coas_title">Lot #:</span>
                                <span class="ik_hn_coas_data">'.$coa_found->lot_number.'</span>
                            </div>
                            <div class="ik_hn_coas_product_id">
                                <span class="ik_hn_coas_title">Product Name:</span>
                                <span class="ik_hn_coas_data">'.$product_name.'</span>
                            </div>
                            <div class="ik_hn_coas_botanical_name">
                                <span class="ik_hn_coas_title">Botanical Name:</span>
                                <span class="ik_hn_coas_data">'.$coa_found->botanical_name.'</span>
                            </div>
                            '.$sku_code.'
                            '.$upc_code.'
                            <div class="ik_hn_coas_country_origin">
                                <span class="ik_hn_coas_title">Country of origin:</span>
                                <span class="ik_hn_coas_data">'.$coa_found->country_origin.'</span>
                            </div>
                            '.$packaging_type.'
                            '.$shelf_life.'
                            '.$compliance.'
                            '.$product_details.'
                            '.$more_details.'
                            '.$file_data.'
                            '.$specs_data.'
                        </div>';

                }
                $result = $found_info;
            } else {
                $result = '<div class="data_coa_found">Not Found!</div>';
            }

        } else {
            $result = '<div class="data_coa_found">Error. Confirm you\'re not a Robot.</div>';
        }   
    }
    
    echo json_encode( $result );
    wp_die();         
}

?>