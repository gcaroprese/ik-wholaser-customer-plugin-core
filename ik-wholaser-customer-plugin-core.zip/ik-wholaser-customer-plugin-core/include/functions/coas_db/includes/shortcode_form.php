<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - COAs DB Shortcode Form
Created: 03/02/2023
Last Update: 04/06/2023
Author: Gabriel Caroprese
*/

//Form form_id
function ik_hn_coa_shortcode_search_form(){

    $coa_data = new IK_HN_COAs();
    
    $output = '
    <style>
    #ik_hn_coa_form_form{
        border: 2px solid #D6DF26;
        padding: 25px;
        border-radius: 20px;
        font-size: 16px;
    }
    #ik_hn_coa_form_form, #ik_hn_coa_form_result{
        max-width: 550px;
        margin: 0 auto;
    }    
    #ik_hn_coa_form_form input{
        font-size: 17px;
    }
    #ik_hn_coa_form_keyword_label, #ik_hn_coa_form_searchby label{
        display: block;
    }
    .hn-button {
        transition: all .35s;
        fill: #FFFFFF;
        color: #FFFFFF;
        background-color: #D6DF26;
        font-size: 16px;
        padding: 15px 40px;
        border-radius: 4px;
        border: 1px solid #fff;
        cursor: pointer;
    }
    .hn-button:hover {
        background-color: #364a15;
    }
    #ik_hn_coa_form_form_wrapper .loader {
        display: none;
        border: 5px solid #f3f3f3;
        border-top: 5px solid #fff;
        border-radius: 50%;
        width: 17px;
        position: absolute;
        margin-left: 5px;
        height: 17px;
        -webkit-animation: spin 2s linear infinite;
        animation: spin 2s linear infinite;
    }
    #ik_hn_coa_form_form_wrapper .searching_data .loader {
        display: initial! important;
    }
    @-webkit-keyframes spin {
        0% { -webkit-transform: rotate(0deg); }
        100% { -webkit-transform: rotate(360deg); }
      }
      
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    .data_coa_found {
        background: #f7f7f7;
        border-radius: 20px;
        margin: 20px 0;
        padding: 25px;
        max-width: 550px;
    }
    #ik_hn_coa_form_result .ik_hn_coas_title {
        font-weight: bold;
        padding-right: 2px;
        border: 0;
        vertical-align: baseline;
        font-size: 100%;
    }
    #ik_hn_coa_form_result .ik_hn_coas_file_download a {
        color: #fff;
        border: 1px solid #E4E4D9;
        background-color: #BABDA5;
        padding: 0 15px;
        font-size: 14px;
        display: inline-flex;
        align-items: center;
        height: 54px;
        margin-top: 20px;
        cursor: pointer;
        white-space: nowrap;
        font-weight: 400;
        -webkit-border-radius: 4px;
        -moz-border-radius: 4px;
        border-radius: 4px;
    }
    #ik_hn_coa_form_result .ik_hn_coas_file_download.specsheet a {
        margin-top: 12px;
    }
    </style>
    <div id="ik_hn_coa_form_form_wrapper">
        <form name="ik_hn_coa_form_form" id="ik_hn_coa_form_form">
            <div id="ik_hn_coa_form_searchby">
                <h4>Search by</h4>
                <label><input type="radio" checked class="ik_hn_coa_form_searchby" name="search_by" value="lot_number"> Lot Number</label>
                <label><input type="radio" class="ik_hn_coa_form_searchby" name="search_by" value="product_name"> Product Name</label>
            </div>
            <label id="ik_hn_coa_form_keyword_label">
                <input required type="text" id="ik_hn_coa_form_keyword" name="ik_hn_coa_keyword" placeholder="Search Term">
            </label>
            '.$coa_data->get_recaptcha_form().'
            <button type="submit" class="hn-button" id="ik_hn_coa_submit_search">Search<span class="loader"></span></button>
        </form>
        <div id="ik_hn_coa_form_result"></div>
    </div>
    <script>
    jQuery("#ik_hn_coa_form_result").attr("style", "display:none");

    jQuery("#ik_hn_coa_form_form").on("click", "#ik_hn_coa_submit_search", function ()
    {
        ik_submit_hn_coa_form();

        return false;
    });
    
    if (jQuery("#recaptcha_data_confirm").length){
        setInterval(function(){
            if (jQuery("#recaptcha_data_confirm").val() == "done"){
                jQuery("#recaptcha_data_confirm").val("");
                ik_submit_hn_coa_form(true);
            }
        }, 1000);
    }
    
    
    function ik_submit_hn_coa_form(recaptchaInvisible = false){
        
        var submit_button = jQuery("#ik_hn_coa_submit_search");
        var form_box_height = parseInt(jQuery("#ik_hn_coa_form_form").height())+25;
        jQuery("#ik_hn_coa_form_result").fadeOut(400);
        jQuery("#ik_hn_coa_form_result").empty();
        submit_button.prop("disabled", true);
        submit_button.addClass("searching_data");
        
        
        var searchby = jQuery(\'#ik_hn_coa_form_searchby input[name="search_by"]:checked\').val();
        var keyword = jQuery("#ik_hn_coa_form_keyword").val();
        var recaptcha = jQuery("#ik_hn_coa_form_form #g-recaptcha-response").val();
        
        
        if (searchby !== "" && keyword !== ""){
            
            if (jQuery("#ik_hn_coa_form_form .g-recaptcha").attr("data-size") === "invisible" && recaptchaInvisible !== true){
                if (!grecaptcha.getResponse()) {
                    grecaptcha.reset();
                    grecaptcha.execute();
                    submit_button.prop("disabled", false);
    			    submit_button.removeClass("searching_data");
                    return false;
                }   
            }
            
    		var data = {
    			action: "ik_hn_coa_submit_ajax_search",
    			"post_type": "post",
    			"searchby": searchby,
    			"keyword": keyword,
    			"recaptcha": recaptcha,
    		};  
    
    		jQuery.post( "'.admin_url("admin-ajax.php").'", data, function(response) {
    			if (response){	
    			    submit_button.removeClass("searching_data");
    			    if (jQuery(".g-recaptcha").length > 0) {
    			        grecaptcha.reset();
    			    }
                    jQuery("#ik_hn_coa_form_result").html(response);

                    setTimeout(function(){
                        submit_button.prop("disabled", false);
                    }, 1000);  
                    jQuery("#ik_hn_coa_form_result").fadeIn(400);
                    setTimeout(function () {
                        jQuery("html, body").animate({
                          scrollTop: jQuery(window).scrollTop() + form_box_height
                        });
                    },1000);
    			}
    		}, "json");    
        } else {
            jQuery("#ik_hn_coa_form_result").html(\'<div class="data_coa_found">Complete the required fields.</div>\');
            submit_button.prop("disabled", false);
            submit_button.removeClass("searching_data");
            jQuery("#ik_hn_coa_form_result").fadeIn(400);
        }
    }
    jQuery( document ).ajaxError(function() {
        location.reload();
    });
    </script>';

    return $output;
    
}
add_shortcode('HN_COA_SEARCH_FORM', 'ik_hn_coa_shortcode_search_form');

?>