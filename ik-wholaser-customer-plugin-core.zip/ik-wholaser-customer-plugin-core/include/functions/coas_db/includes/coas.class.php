<?php
/*

Class IK_HN_COAs
Update: 06/05/2022
Author: Gabriel Caroprese

*/

if ( ! defined( 'ABSPATH' ) ) {
    return;
}

class IK_HN_COAs extends IK_HN_COA_Product{

    private $db_table_coas;
    private $recaptcha_option;

    public function __construct(){
        global $wpdb;
        $this->db_table_coas = $wpdb->prefix . 'ik_hn_coa_data';
        $this->recaptcha_option = 'ik_hn_coa_recaptcha';
        parent::__construct();
    }

    //method to return COA data
    public function get_coa($idcoa){
        $idcoa = absint($idcoa);
        global $wpdb;
        $querycoaID = "SELECT * FROM ".$this->db_table_coas." WHERE id = ".$idcoa;
        $coa = $wpdb->get_results($querycoaID);        
       
        if(isset($coa[0])){
            return $coa[0];
        } else {
            return false;
        }      
        
    }

    //method to return COA by product ID
    public function get_coa_by_product_id($product_id){
        $product_id = absint($product_id);
        global $wpdb;
        $querycoa = "SELECT * FROM ".$this->db_table_coas." WHERE product_id = ".$product_id;
        $coa = $wpdb->get_results($querycoa);        
        
        if(isset($coa[0])){
            return $coa[0];
        } else {
            return false;
        }     
        
    }

    //method to return COA by lot #
    public function get_coa_by_lotn($lotcoa){
        $lotcoa = sanitize_text_field($lotcoa);
        global $wpdb;
        $querycoa = "SELECT * FROM ".$this->db_table_coas." WHERE lot_number = ".$lotcoa;
        $coa = $wpdb->get_results($querycoa);        
        
        if(isset($coa[0])){
            return $coa[0];
        } else {
            return false;
        }     
        
    }

    //Count the quantity of COA records
    public function qty_coa_records(){
    
        global $wpdb;
        $queryCOA = "SELECT * FROM ".$this->db_table_coas;
        $coa_records = $wpdb->get_results($queryCOA);

        if (isset($coa_records[0]->id)){ 
            
            $coa_count = count($coa_records);
            return $coa_count;
            
        } else {
            return false;
        }
    }

    //List coas
    public function get_coa_list($qty = 30, $offsetList = '', $orderby = 'id', $orderDir = 'DESC', $search = NULL, $search_type = 'all'){
        
        if (is_int($offsetList)){
            $offsetList = ' LIMIT '.$qty.' OFFSET '.$offsetList;
        } else {
            $offsetList = ' LIMIT '.absint($qty);
        }
        
        //Values to order filters CSS classes
        $empty = '';
        $idClass = $empty;
        $lot_numberClass = $empty;
        $product_idClass = $empty;
        $country_originClass = $empty;
        $packaging_dateClass = $empty;
        $shelf_lifeClass = $empty;
        
        if (strtoupper($orderDir) != 'DESC'){
            $orderDir= ' ASC';
            $ordenClass= 'sorted';
        } else {
            $orderDir = ' DESC';
            $ordenClass= 'sorted desc';
        }
        
        if ($orderby != 'id'){	
            if ($orderby == 'lot_number'){
                $orderQuery = ' ORDER BY '.$this->db_table_coas.'.lot_number '.$orderDir;
                $lot_numberClass = $ordenClass;
            } else if ($orderby == 'product_id'){
                $orderQuery = ' ORDER BY '.$this->db_table_products.'.product_name '.$orderDir;
                $product_idClass = $ordenClass;
            } else if ($orderby == 'country_origin'){
                $orderQuery = ' ORDER BY '.$this->db_table_coas.'.country_origin '.$orderDir;
                $country_originClass = $ordenClass;
            } else if ($orderby == 'shelf_life'){
                $orderQuery = ' ORDER BY '.$this->db_table_coas.'.shelf_life '.$orderDir;
                $shelf_lifeClass = $ordenClass;
            } else if ($orderby == 'packaging_date'){
                $orderQuery = ' ORDER BY '.$this->db_table_coas.'.uploaded '.$orderDir;
                $packaging_dateClass = $ordenClass;
            } else {
                $orderQuery = ' ORDER BY '.$this->db_table_coas.'.id '.$orderDir;
                $nombreClass = $ordenClass;
            }
        } else {
            $orderQuery = ' ORDER BY '.$this->db_table_coas.'.id '.$orderDir;
            $idClass = $ordenClass;
        }

        $classData = array(
            'id' => $idClass,
            'lot_number' => $lot_numberClass,
            'product_id' => $product_idClass,
            'country_origin' => $country_originClass,
            'packaging_date' => $packaging_dateClass,
            'shelf_life' => $shelf_lifeClass,
            
        );

        if ($search != NULL){
            if ($search_type != 'all'){
                $search_type = sanitize_text_field($search_type);
                $search = sanitize_text_field($search);
                $busqueda = $search;
                if($search_type == 'lot_number'){
                    $search_type = 'lot_number';
                    $where = " WHERE ".$this->db_table_coas.".lot_number LIKE '".$search."' AND ".$this->db_table_coas.".product_id = ".$this->db_table_products.".id";
                } else {
                    $search_type = 'product_name';
                    $where = " WHERE (".$this->db_table_products.".product_name LIKE '%".$search."%' OR 
                    ".$this->db_table_products.".botanical_name LIKE '%".$search."%') AND ".$this->db_table_coas.".product_id = ".$this->db_table_products.".id ";
                }
            } else {
                //Search by lot number, product name, botanical name and country of origin
                $search_type = 'all';      
                $where = " WHERE (".$this->db_table_coas.".lot_number LIKE '%".$search."%' OR ".$this->db_table_products.".product_name LIKE '%".$search."%' OR 
                ".$this->db_table_products.".botanical_name LIKE '%".$search."%' OR ".$this->db_table_coas.".country_origin LIKE '%".$search."%') AND ".$this->db_table_coas.".product_id = ".$this->db_table_products.".id ";
            }
        } else {
            $where = '';
            $search = '';
        }

        if ($orderby == 'product_id'){
            if( $search_type == 'lot_number' OR $search == NULL){
                if($where == ''){
                    $where = " WHERE ".$this->db_table_coas.".product_id = ".$this->db_table_products.".id ";
                } else {
                    $where = " AND ".$this->db_table_coas.".product_id = ".$this->db_table_products.".id ";
                }
            }
        }

        $groupby = (isset($groupby)) ? $groupby : " GROUP BY ".$this->db_table_coas.".id ";

        global $wpdb;

        $query = "SELECT ".$this->db_table_coas.".id, ".$this->db_table_coas.".product_id, 
        ".$this->db_table_coas.".lot_number,".$this->db_table_coas.".batch_number, ".$this->db_table_coas.".cut_size, 
        ".$this->db_table_coas.".compliance, ".$this->db_table_coas.".packaging_type, ".$this->db_table_coas.".more_details, 
        ".$this->db_table_coas.".packaging_date, ".$this->db_table_coas.".shelf_life, ".$this->db_table_coas.".country_origin, 
        ".$this->db_table_coas.".file_name, ".$this->db_table_coas.".spec_file, ".$this->db_table_products.".basic_data, ".$this->db_table_products.".sku_code, 
        ".$this->db_table_products.".upc_code, ".$this->db_table_products.".product_woo_id, ".$this->db_table_products.".botanical_name, 
        ".$this->db_table_products.".product_details, ".$this->db_table_products.".product_name FROM ".$this->db_table_coas.", 
        ".$this->db_table_products." ".$where.$groupby.$orderQuery.$offsetList;

        $coas = $wpdb->get_results($query);
        $coas_data = array(
            'data' => $coas,
            'class' => $classData,
            'search_type' => $search_type,        
            'search_value' => $search,        
        );

        return $coas_data;

    }
        

    //Method to show list of COAs for backend
    public function get_list_coas_wrapper_backend($qty = 30, $offsetList = '', $orderby = 'id', $orderDir = 'DESC', $search = NULL, $search_type = 'all'){

        $coas_data = $this->get_coa_list($qty, $offsetList, $orderby, $orderDir, $search);

        //Search keyword value
        $search = $coas_data['search_value'];


        //classes for columns that are filtered
        $classData = $coas_data['class'];

        $idClass = $classData['id'];
        $lot_numberClass = $classData['lot_number'];
        $product_idClass = $classData['product_id'];
        $country_originClass = $classData['country_origin'];
        $packaging_dateClass = $classData['packaging_date'];
        $shelf_lifeClass = $classData['shelf_life'];

        //I create a var for coas data
        $coas = $coas_data['data'];

        // If data exists
        if (isset($coas[0]->id)){

            $columnsheading = '<tr>
                <th><input type="checkbox" class="select_all" /></th>
                <th order="lot_number" class="worder '.$lot_numberClass.'">Lot # <span class="sorting-indicator"></span></th>
                <th order="product_id" class="worder onlydesktop '.$product_idClass.'">Product <span class="sorting-indicator"></span></th>
                <th order="country_origin" class="worder onlydesktop '.$country_originClass.'">Country <span class="sorting-indicator"></span></th>
                <th class="uploaded_file">COA</th>
                <th class="uploaded_file_specs">Specs</th>
                <th>
                    <button class="ik_hn_coas_button_delete button action">Delete</button></td>
                </th>
            </tr>';

            $searchBar = '<p class="search-box">
                <label class="screen-reader-text" for="tag-search-input">Search COAS:</label>
                <input type="search" id="tag-search-input" name="search" value="'.$search.'">
                <input type="submit" id="searchbutton_coa" class="button" value="Search">
            </p>';
            $listing = '
            <div class="tablenav-pages">Total: '.$this->qty_coa_records().' - Showing: '.count($coas).'</div>'.$searchBar;

            if ($search != NULL){
                $listing .= '<p class="show-all-button"><a href="'.IK_HATTON_CORE_COAS_COA_MENU.'" class="button button-primary">Show All</a></p>';
            }

            $listing .= '<table id="ik_hn_coa_db_existing">
                <thead>
                    '.$columnsheading.'
                </thead>
                <tbody>';
                foreach ($coas as $coa){
                    
                    $product = $this->get_coa_product($coa->product_id);

                    if($product){
                        if($product->product_woo_id != ''){
                            $product_name = (isset($product->product_name)) ? '<a target="_blank" href="'.admin_url().'post.php?post='.$product->product_woo_id.'&action=edit">'.sanitize_text_field($product->product_name): $coa->product_name.'</a>';
                            $product_name = str_replace('\\', '', $product_name);
                        } else {
                            $product_name = (isset($product->product_name)) ? sanitize_text_field($product->product_name): $coa->product_name;
                            $product_name = str_replace('\\', '', $product_name);
                        }
                    } else {
                        $product_name = $coa->product_name;
                    }



                    if($coa->file_name !== '' && $coa->file_name !== NULL){
                        $file_url = wp_upload_dir()['baseurl'].'/coas/'.$coa->file_name;
                        $file_url_class = '';
                        $target_coa = 'target="_blank"';
                    } else {
                        $file_url = '#';
                        $file_url_class = 'no-file';
                        $target_coa = 'class="btn-disabled"';
                    }

                    if($coa->spec_file !== '' && $coa->spec_file !== NULL){
                        $file_url_specs = wp_upload_dir()['baseurl'].'/specs/'.$coa->spec_file;
                        $file_url_class_specs = '';
                        $target_specs = 'target="_blank"';
                    } else {
                        $file_url_specs = '#';
                        $file_url_class_specs = 'no-file';
                        $target_specs = 'class="btn-disabled"';
                    }
                    
                    $listing .= '
                        <tr iddata="'.$coa->id.'">
                            <td><input type="checkbox" class="select_data" /></td>
                            <td class="ik_hn_coas_lot_number">'.$coa->lot_number.'</td>
                            <td class="ik_hn_coas_product_id">'.$product_name.'</td>
                            <td class="ik_hn_coas_country_origin">'.$coa->country_origin.'</td>
                            <td class="ik_hn_coas_file '.$file_url_class.'">
                                <div>
                                    <a '.$target_coa.' href="'.$file_url .'"><span class="dashicons dashicons-media-document"></span></a>
                                </div>
                            </td>
                            <td class="ik_hn_coas_file '.$file_url_class_specs.'">
                                <div>
                                <a '.$target_specs.' href="'.$file_url_specs .'"><span class="dashicons dashicons-analytics"></span></a>
                                </div>
                            </td>
                            <td iddata="'.$coa->id.'">
                                <button class="ik_hn_coas_button_edit_coa button action">Edit</button>
                                <button class="ik_hn_coas_button_delete_coa button action">Delete</button></td>
                        </tr>';
                    
                }
                $listing .= '
                </tbody>
                <tfoot>
                    '.$columnsheading.'
                </tfoot>
                <tbody>
            </table>';
            
            return $listing;
            
        } else {
            if ($search != NULL){
                $listing = $searchBar.'
            <div id="ik_hn_coa_db_existing">
                <p>Results not found</p>
                <p class="show-all-button"><a href="'.IK_HATTON_CORE_COAS_COA_MENU.'" class="button button-primary">Show All</a></p>
            </div>';
                return $listing;
            }
        }
        
        return false;
    }


    //Search coas by parameters
    public function search_coas($value, $search_type = 'lot_number'){
        $value = sanitize_text_field($value);
        $search_type = ($search_type == 'lot_number') ? 'lot_number' : 'product_name';

        $value = ($value != '') ? strtoupper($value) : '';

        $search_valid = ($value != '') ? true : false;


        //Default value for search
        $found_coas = false;

        //I check if search is doable and then search
        if ($search_valid){
            global $wpdb;
            $query_coas = "SELECT * FROM ".$this->db_table_coas." WHERE ".$search_type." = ".$value;
            $coas_found = $wpdb->get_results($query_coas);
            if (isset($coas_found[0]->id)){
                $found_coas = $coas_found;
            } else {
                $found_coas = false;
            }
        }
        
        return $found_coas;
    }

    //method to insert coa
    public function insert_coa($coa_data){

        $lot_number      = (isset($coa_data['lot_number'])) ? sanitize_text_field($coa_data['lot_number']) : '';
        $product_id      = (isset($coa_data['product_id'])) ? absint($coa_data['product_id']) : '';
        $batch_number    = (isset($coa_data['batch_number'])) ? sanitize_text_field($coa_data['batch_number']) : '';
        $country_origin  = (isset($coa_data['country_origin'])) ? sanitize_text_field($coa_data['country_origin']) : '';
        $cut_size        = (isset($coa_data['cut_size'])) ? sanitize_text_field($coa_data['cut_size']) : '';
        $packaging_date  = (isset($coa_data['packaging_date'])) ? date("Y-m-d", strtotime($coa_data['packaging_date'])) : '';
        $shelf_life      = (isset($coa_data['shelf_life'])) ? sanitize_text_field($coa_data['shelf_life']) : '';
        $compliance      = (isset($coa_data['compliance'])) ? sanitize_text_field($coa_data['compliance']) : '';
        $packaging_type  = (isset($coa_data['packaging_type'])) ? sanitize_text_field($coa_data['packaging_type']) : '';
        $file_name	     = (isset($coa_data['file_name'])) ? sanitize_text_field($coa_data['file_name']) : '';
        $spec_file	     = (isset($coa_data['spec_file'])) ? sanitize_text_field($coa_data['spec_file']) : '';
        $more_details	 = (isset($coa_data['more_details'])) ? sanitize_textarea_field($coa_data['more_details']) : '';

        //Make sure COA with Lot # not repeated
        if($this->get_coa_by_lotn($lot_number) == false){

            global $wpdb;
            $data_fields  = array (
                'lot_number'	 => $lot_number,
                'product_id'     => $product_id,
                'batch_number'   => $batch_number,
                'country_origin' => $country_origin,
                'cut_size'       => $cut_size,
                'packaging_date' => $packaging_date,
                'shelf_life'     => $shelf_life,
                'compliance'     => $compliance,
                'packaging_type' => $packaging_type,
                'uploaded'	     => current_time('mysql'),
                'edited'	     => current_time('mysql'),
                'file_name'	     => $file_name,
                'spec_file'	     => $spec_file,
                'more_details'	 => $more_details,
            );

            $rowResult = $wpdb->insert($this->db_table_coas,  $data_fields , $format = NULL);

            if($wpdb->insert_id){
                //success
                return 'Saved!';
            } else {
                //something failed
                return 'Something went wrong.';
            }
        } else {
            //repeated lot #
            return 'Lot Number already exists!';
        }
    }

    //method to edit coa
    public function edit_coa($idCOA, $coa_data){
        $idCOA = absint($idCOA);

        $lot_number      = (isset($coa_data['lot_number'])) ? sanitize_text_field($coa_data['lot_number']) : false;
        $product_id      = (isset($coa_data['product_id'])) ? absint($coa_data['product_id']) : false;
        $batch_number    = (isset($coa_data['batch_number'])) ? sanitize_text_field($coa_data['batch_number']) : false;
        $country_origin  = (isset($coa_data['country_origin'])) ? sanitize_text_field($coa_data['country_origin']) : false;
        $cut_size        = (isset($coa_data['cut_size'])) ? sanitize_text_field($coa_data['cut_size']) : false;
        $packaging_date  = (isset($coa_data['packaging_date'])) ? date("Y-m-d", strtotime($coa_data['packaging_date'])) : false;
        $shelf_life      = (isset($coa_data['shelf_life'])) ? sanitize_text_field($coa_data['shelf_life']) : false;
        $compliance      = (isset($coa_data['compliance'])) ? sanitize_text_field($coa_data['compliance']) : false;
        $packaging_type  = (isset($coa_data['packaging_type'])) ? sanitize_text_field($coa_data['packaging_type']) : false;
        $file_name	     = (isset($coa_data['file_name'])) ? sanitize_text_field($coa_data['file_name']) : false;
        $spec_file	     = (isset($coa_data['spec_file'])) ? sanitize_text_field($coa_data['spec_file']) : false;
        $more_details	 = (isset($coa_data['more_details'])) ? sanitize_textarea_field($coa_data['more_details']) : false;

        global $wpdb;
        $where = [ 'id' => $idCOA ];

        if($lot_number){$args_update['lot_number'] = $lot_number;}
        if($product_id){$args_update['product_id'] = $product_id;}
        if($batch_number){$args_update['batch_number'] = $batch_number;}
        if($country_origin){$args_update['country_origin'] = $country_origin;}
        if($cut_size){$args_update['cut_size'] = $cut_size;}
        if($packaging_date){$args_update['packaging_date'] = $packaging_date;}
        if($shelf_life){$args_update['shelf_life'] = $shelf_life;}
        if($compliance){$args_update['compliance'] = $compliance;}
        if($packaging_type){$args_update['packaging_type'] = $packaging_type;}
        if($file_name){$args_update['file_name'] = $file_name;}
        if($spec_file){$args_update['spec_file'] = $spec_file;}
        if($more_details){$args_update['more_details'] = $more_details;}


        //If anything to update
        if(isset($args_update)){
            $args_update['edited'] = current_time('mysql');
            $rowResult = $wpdb->update($this->db_table_coas, $args_update, $where);
            return 'COA updated';
        } else {
            return 'Nothing to update';
        }
            
    }

    //method to delete coa    
    public function delete($idCoa){
        $idCoa = absint($idCoa);
        global $wpdb;
        $rowResult = $wpdb->delete($this->db_table_coas , array( 'id' => $idCoa ) );
        
        return true;
    }

    //get recaptcha or other possible config
    public function get_config(){

        $recapchaConfig = get_option($this->recaptcha_option);

        $recapchaEnabled = (isset($recapchaConfig['enabled'])) ? rest_sanitize_boolean($recapchaConfig['enabled']) : false;
        $recaptchakey = (isset($recapchaConfig['key'])) ? sanitize_text_field($recapchaConfig['key']) : false;
        $recaptchasecret = (isset($recapchaConfig['secret'])) ? sanitize_text_field($recapchaConfig['secret']) : false;
        $recaptchoption = (isset($recapchaConfig['option'])) ? sanitize_text_field($recapchaConfig['option']) : 'v2';

        $config = array(
            'enabled' => $recapchaEnabled,
            'key'     => $recaptchakey,
            'secret'  => $recaptchasecret,
            'option'  => $recaptchoption,        
        );

        return $config;
    }

    //get recaptcha or other possible config
    public function update_config($update_data){

        $recaptcha_k = (isset($update_data['key'])) ? sanitize_text_field($update_data['key']) : false;
        $recaptcha_s = (isset($update_data['secret'])) ? sanitize_text_field($update_data['secret']) : false;    
        $recapchaEnabled = (isset($update_data['enabled'])) ? rest_sanitize_boolean($update_data['enabled']) : false;
        $recaptcha_option = (isset($update_data['option'])) ? sanitize_text_field($update_data['option']) : 'v2';
        
        $configData = array(
            'enabled' => $recapchaEnabled,
            'key'     => $recaptcha_k,
            'secret'  => $recaptcha_s,
            'option'  => $recaptcha_option,
        );

        update_option($this->recaptcha_option, $configData);
    }

    //Show recaptcha form field if enabled
    public function get_recaptcha_form($ifactive = false){
            
        $recapchaConfig = $this->get_config();


        if($recapchaConfig['enabled']){
            
            if ($recapchaConfig['key'] == false || $recapchaConfig['key'] == NULL || 
            $recapchaConfig['secret'] == false || $recapchaConfig['secret'] == NULL){
                //No keys
                return;
            } 
            
            //I check if it's "I'm not a robot" or "invisible" recaptcha
            if ($recapchaConfig['option'] == 'v3'){
                $recaptcha = '<script src="https://www.google.com/recaptcha/api.js" async defer></script>
                <div class="g-recaptcha"
                    data-sitekey="'.$recapchaConfig['key'].'"
                    data-callback="recaptchaOnSubmit"
                    data-size="invisible">
                </div>
                <input type="hidden" name="recaptcha_data_confirm" id="recaptcha_data_confirm" value="">
                <script>
                    function recaptchaOnSubmit() {
                        jQuery("#recaptcha_data_confirm").val("done");
                    }
                </script>';
                
            } else {
            
                $recaptcha = "<script src='https://www.google.com/recaptcha/api.js' async defer></script>
                <p>
                    <div class='g-recaptcha' data='robot' data-sitekey='".$recapchaConfig['key']."'></div>
                </p>";
            }

            return $recaptcha;
        } else{
            //recaptcha disabled
            return;
        }
    }

    //method to show product tab COA info by Woocommerce product ID
    public function show_coa_info_by_woo_product_id($woo_product_id = 0){
        $woo_product_id = absint($woo_product_id);
        $coa_info = '';

        $coa_product = $this->get_coa_by_woo_prod_id($woo_product_id);
        $coa_product_id = ($coa_product !==  false) ? $coa_product->id : 0;
		$coa_data = $this->get_coa_by_product_id($coa_product_id);

        // If data exists
        if ($coa_data){

            $uploads_folder = wp_upload_dir()['baseurl'];

            if($coa_data->file_name !== ''){
                $file_url = $uploads_folder.'/coas/'.$coa_data->file_name;
                $file_data = '
                <br />
                <div class="ik_hn_coas_file_download">
                    <a target="_blank" class="button alt" href="'.$file_url .'">Download COA File</a>
                </div>';
            } else {
                $file_data = '';
            }

            if($coa_data->spec_file !== ''){
                $specs_url = $uploads_folder.'/specs/'.$coa_data->spec_file;
                $specs_data = '
                <br />
                <div class="ik_hn_coas_file_download specsheet">
                    <a target="_blank" class="button alt" href="'.$specs_url .'">Download Spec Sheet</a>
                </div>';
            } else {
                $specs_data = '';
            }

            $packaging_date = ($coa_data->packaging_date != '0000-00-00') ? '
            <div class="ik_hn_coas_packaging_date">
                <span class="ik_hn_coas_title">Packing Date:</span>
                <span class="ik_hn_coas_data">'.$coa_data->packaging_date.'</span>
            </div>': '';                    
            $packaging_type = ($coa_data->packaging_type != '') ? '
            <div class="ik_hn_coas_packaging_type">
                <span class="ik_hn_coas_title">Packing Type:</span>
                <span class="ik_hn_coas_data">'.$coa_data->packaging_type.'</span>
            </div>': '';
            $shelf_life = ($coa_data->shelf_life != '') ? '
            <div class="ik_hn_coas_shelf_life">
                <span class="ik_hn_coas_title">Shelf Life:</span>
                <span class="ik_hn_coas_data">'.$coa_data->shelf_life.'</span>
            </div>': '';
            $compliance = ($coa_data->compliance != '') ? '
            <div class="ik_hn_coas_compliance">
                <span class="ik_hn_coas_title">Compliance:</span>
                <span class="ik_hn_coas_data">'.$coa_data->compliance.'</span>
            </div>': '';
            $compliance = ($coa_data->compliance != '') ? '
            <div class="ik_hn_coas_compliance">
                <span class="ik_hn_coas_title">Compliance:</span>
                <span class="ik_hn_coas_data">'.$coa_data->compliance.'</span>
            </div>': '';
            $compliance = ($coa_data->compliance != '') ? '
            <div class="ik_hn_coas_compliance">
                <span class="ik_hn_coas_title">Compliance:</span>
                <span class="ik_hn_coas_data">'.$coa_data->compliance.'</span>
            </div>': '';
            $basic_data = ($coa_product->basic_data != '') ? '
            <div class="ik_hn_coas_basic_data">
                <span class="ik_hn_coas_title">Basic Data:</span>
                <span class="ik_hn_coas_data">'.$coa_product->basic_data.'</span>
            </div>': '';
            $sku_code = ($coa_product->sku_code != '') ? '
            <div class="ik_hn_coas_sku_code">
                <span class="ik_hn_coas_title">SKU:</span>
                <span class="ik_hn_coas_data">'.$coa_product->sku_code.'</span>
            </div>': '';
            $upc_code = ($coa_product->upc_code != '') ? '
            <div class="ik_hn_coas_upc_code">
                <span class="ik_hn_coas_title">UPC:</span>
                <span class="ik_hn_coas_data">'.$coa_product->upc_code.'</span>
            </div>': '';
            $product_details = ($coa_product->product_details	 != '') ? '
            <div class="ik_hn_coas_product_details	">
                <span class="ik_hn_coas_title">Product Details:</span>
                <span class="ik_hn_coas_data">'.$coa_product->product_details	.'</span>
            </div>': '';

            $more_details = ($coa_data->more_details != '') ? '
            <div class="ik_hn_coas_more_details">
                <span class="ik_hn_coas_title">More Details:</span>
                <span class="ik_hn_coas_data">'.$coa_data->more_details.'</span>
            </div>': '';
            
            $coa_info .= '
                <div class="data_coa">
                    <div class="ik_hn_coas_lot_number">
                        <span class="ik_hn_coas_title">Lot #:</span>
                        <span class="ik_hn_coas_data">'.$coa_data->lot_number.'</span>
                    </div>
                    <div class="ik_hn_coas_botanical_name">
                        <span class="ik_hn_coas_title">Botanical Name:</span>
                        <span class="ik_hn_coas_data">'.$coa_product->botanical_name.'</span>
                    </div>
                    '.$sku_code.'
                    '.$upc_code.'
                    <div class="ik_hn_coas_country_origin">
                        <span class="ik_hn_coas_title">Country of origin:</span>
                        <span class="ik_hn_coas_data">'.$coa_data->country_origin.'</span>
                    </div>
                    '.$packaging_type.'
                    '.$shelf_life.'
                    '.$compliance.'
                    '.$product_details.'
                    '.$more_details.'
                    '.$file_data.'
                    '.$specs_data.'
                </div>';
        }
        return $coa_info;
    }
}

?>