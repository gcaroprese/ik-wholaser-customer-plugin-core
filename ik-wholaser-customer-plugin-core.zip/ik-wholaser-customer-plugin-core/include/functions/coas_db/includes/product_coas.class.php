<?php
/*

Class IK_HN_COA_Product
Update: 08/10/2022
Author: Gabriel Caroprese

*/

if ( ! defined( 'ABSPATH' ) ) {
    return;
}

class IK_HN_COA_Product{

    protected $db_table_products;

    public function __construct(){
        global $wpdb;
        $this->db_table_products = $wpdb->prefix . 'ik_hn_coa_products';
    }

    //method to return COA product data
    public function get_coa_product($id_product){
        $id_product = absint($id_product);
        global $wpdb;
        $query_product = "SELECT * FROM ".$this->db_table_products." WHERE id = ".$id_product;
        $product = $wpdb->get_results($query_product);
        
        if(isset($product[0])){
            return $product[0];
        } else {
            return false;
        }
        
    }

    //Method to list COA products selector
    public function get_coa_product_selector($idSelected = 0){
        $idSelected = absint($idSelected);

        $options_data_list = '';

        global $wpdb;
        $queryprods = "SELECT * FROM ".$this->db_table_products;
        echo $queryprods;
        $products = $wpdb->get_results($queryprods);        
        
        if(isset($products[0])){
            
            foreach( $products as $product ) {
                $selected = ($idSelected == $product->id) ? 'selected' : '';
            
                $product_name = str_replace('\"', '"', $product->product_name);
                $product_name = str_replace("\'", "'", $product_name);
                $options_data_list .= '<option '.$selected.' value="'.$product->id.'">'.$product_name.'</option>';
            }
        
        }
        
        
        return $options_data_list;
    }

    //Method to list Woocommerce products selector
    public function get_woo_product_selector($idSelected = 0){
        $idSelected = absint($idSelected);

        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
            'post_status' => 'publish',
        );
    
        $products = get_posts($args);
        $options_data_list = '';
    
        if( $products ){
            foreach( $products as $product ) {
                $selected = ($idSelected == $product->ID) ? 'selected' : '';
            
                $product_name = str_replace('\"', '"', $product->post_title);
                $product_name = str_replace("\'", "'", $product_name);
                $options_data_list .= '<option '.$selected.' value="'.$product->ID.'">'.$product_name.'</option>';
            }
        }
    
        wp_reset_query();
        
        return $options_data_list;
    }

    //method to return COA product data by woocommerce associated product ID
    public function get_coa_by_woo_prod_id($woo_prod_id, $IDtoAvoid = 0){
        $woo_prod_id = absint($woo_prod_id);
        $IDtoAvoid = absint($IDtoAvoid);

        global $wpdb;
        $queryprod = "SELECT * FROM ".$this->db_table_products." WHERE product_woo_id = ".$woo_prod_id." AND id != ".$IDtoAvoid;
        $product = $wpdb->get_results($queryprod);        
        
        if(isset($product[0])){
            return $product[0];
        } else {
            return false;
        }     
        
    }

    //Count the quantity of COA products records
    public function qty_coa_products_records(){
    
        global $wpdb;
        $queryProducts = "SELECT * FROM ".$this->db_table_products;
        $products_records = $wpdb->get_results($queryProducts);

        if (isset($products_records[0]->id)){ 
            
            $products_count = count($products_records);
            return $products_count;
            
        } else {
            return false;
        }
    }

    //List coas products
    public function get_coa_products_list($qty = 30, $offsetList = '', $orderby = 'id', $orderDir = 'DESC', $search = NULL){
        
        if (is_int($offsetList)){
            $offsetList = ' LIMIT '.$qty.' OFFSET '.$offsetList;
        } else {
            $offsetList = ' LIMIT '.absint($qty);
        }

        //Values to order filters CSS classes
        $empty = '';
        $idClass = $empty;
        $product_nameClass = $empty;
        $botanical_nameClass = $empty;
        
        if (strtoupper($orderDir) != 'DESC'){
            $orderDir= ' ASC';
            $ordenClass= 'sorted';
        } else {
            $orderDir = ' DESC';
            $ordenClass= 'sorted desc';
        }
        
        if ($orderby != 'id'){	
            if ($orderby == 'product_name'){
                $orderQuery = ' ORDER BY product_name '.$orderDir;
                $product_nameClass = $ordenClass;
            } else if ($orderby == 'botanical_name'){
                $orderQuery = ' ORDER BY botanical_name '.$orderDir;
                $botanical_nameClass = $ordenClass;
            }else {
                $orderQuery = ' ORDER BY id '.$orderDir;
                $idClass = $ordenClass;
            }
        } else {
            $orderQuery = ' ORDER BY id '.$orderDir;
            $idClass = $ordenClass;
        }

        $classData = array(
            'id' => $idClass,
            'product_name' => $product_nameClass,
            'botanical_name' => $botanical_nameClass,
        );

        if ($search != NULL){
            $search = sanitize_text_field($search);
            $busqueda = $search;
            $where = " WHERE product_name LIKE '%".$search."%' OR botanical_name LIKE '%".$search."%'";
        } else {
            $where = '';
            $search = '';
        }
        
        global $wpdb;
        $query = "SELECT * FROM ".$this->db_table_products." ".$where.$orderQuery.$offsetList;
        $coas = $wpdb->get_results($query);

        $coa_product_data = array(
            'data' => $coas,
            'class' => $classData,
            'search_value' => $search,        
        );

        return $coa_product_data;

    }
        

    //Method to show list of COAs products for backend
    public function get_list_coas_products_wrapper_backend($qty = 30, $offsetList = '', $orderby = 'id', $orderDir = 'DESC', $search = NULL){

        $coa_product_data = $this->get_coa_products_list($qty, $offsetList, $orderby, $orderDir, $search);

        //Search keyword value
        $search = $coa_product_data['search_value'];


        //classes for columns that are filtered
        $classData = $coa_product_data['class'];
        $idClass = $classData['id'];
        $product_nameClass = $classData['product_name'];
        $botanical_nameClass = $classData['botanical_name'];

        //I create a var for coas data
        $coa_products = $coa_product_data['data'];

        // If data exists
        if (isset($coa_products[0]->id)){

            $columnsheading = '<tr>
                <th><input type="checkbox" class="select_all" /></th>
                <th order="id" class="worder '.$idClass.'">ID<span class="sorting-indicator"></span></th>
                <th order="product_name" class="worder '.$product_nameClass.'">Product Name<span class="sorting-indicator"></span></th>
                <th order="botanical_name" class="worder '.$botanical_nameClass.'">Botanical Name <span class="sorting-indicator"></span></th>
                <th>
                    <button class="ik_hn_coas_button_delete button action">Delete</button></td>
                </th>
            </tr>';
            
            $searchBar = '<p class="search-box">
                <label class="screen-reader-text" for="tag-search-input">Search COAS:</label>
                <input type="search" id="tag-search-input" name="search" value="'.$search.'">
                <input type="submit" id="searchbutton_coa" class="button" value="Search">
            </p>';

            $listing = '
            <div class="tablenav-pages">Total: '.$this->qty_coa_products_records().' - Showing: '.count($coa_products).'</div>
            '.$searchBar;

            if ($search != NULL){
                $listing .= '<p class="show-all-button"><a href="'.IK_HATTON_CORE_COAS_COA_MENU.'" class="button button-primary">Show All</a></p>';
            }

            $listing .= '<table id="ik_hn_coa_db_existing">
                <thead>
                    '.$columnsheading.'
                </thead>
                <tbody>';
                foreach ($coa_products as $coa_product){
                    
                    //Check product associated to Woocommerce
                    $product_name = $coa_product->product_name;
                    if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

                        $woo_product_id = absint($coa_product->product_woo_id);
                        $product =wc_get_product($woo_product_id);

                        if($product){
                            $product_name = $product->get_name();
                        }
                    }
                    
                    $listing .= '
                        <tr iddata="'.$coa_product->id.'">
                            <td><input type="checkbox" class="select_data" /></td>
                            <td class="ik_hn_coas_id">'.$coa_product->id.'</td>
                            <td class="ik_hn_coas_product_name">'.$coa_product->product_name.'</td>
                            <td class="ik_hn_coas_botanical_name">'.$coa_product->botanical_name.'</td>
                            <td iddata="'.$coa_product->id.'">
                                <button class="ik_hn_coas_button_edit_coa button action">Edit</button>
                                <button class="ik_hn_coas_button_delete_coa button action">Delete</button></td>
                        </tr>';
                    
                }
                $listing .= '
                </tbody>
                <tfoot>
                    '.$columnsheading.'
                </tfoot>
                <tbody>
            </table>';
            
            return $listing;
            
        } else {
            if ($search != NULL){
                $listing = $searchBar.'
            <div id="ik_hn_coa_db_existing">
            <p>Results not found</p>
            <p class="show-all-button"><a href="'.$url_coas.'" class="button button-primary">Show All</a></p></div>';
                return $listing;
            }
        }
        
        return false;
    }


    //Search coas by parameters
    public function search_coas_products($value){
        $value = sanitize_text_field($value);

        $value = ($value != '') ? strtoupper($value) : '';

        $search_valid = ($value != '') ? true : false;


        //Default value for search
        $found_coas = false;

        global $wpdb;
        $query_product = "SELECT * FROM ".$this->db_table_products." WHERE product_name LIKE '%".$value."%'";
        $product = $wpdb->get_results($query_product);
        if (isset($product[0]->id)){
            $value = $product[0]->id;
        } else {
            $search_valid = false;
        }

        //I check if search is doable and then search
        if ($search_valid){
            global $wpdb;
            $query_coas = "SELECT * FROM ".$this->db_table_products." WHERE product_name LIKE ".$value." OR botanical_name LIKE ".$value;
            $coas_found = $wpdb->get_results($query_coas);
            if (isset($coas_found[0]->id)){
                $found_coas = $coas_found;
            } else {
                $found_coas = false;
            }
        } 
        
        return $found_coas;
    }

    //method to insert coa
    public function insert_coa_product($coa_data){

        $product_name = (isset($coa_data['product_name'])) ? sanitize_textarea_field($coa_data['product_name']) : '';
        $botanical_name = (isset($coa_data['botanical_name'])) ? sanitize_textarea_field($coa_data['botanical_name']) : '';
        $product_woo_id = (isset($coa_data['product_woo_id'])) ? absint($coa_data['product_woo_id']) : '';
        $basic_data = (isset($coa_data['basic_data'])) ? sanitize_textarea_field($coa_data['basic_data']) : '';
        $sku_code = (isset($coa_data['sku_code'])) ? sanitize_text_field($coa_data['sku_code']) : '';
        $upc_code = (isset($_Pcoa_dataOST['upc_code'])) ? sanitize_text_field($coa_data['upc_code']) : '';
        $product_details = (isset($coa_data['product_details'])) ? sanitize_textarea_field($coa_data['product_details']) : '';
        
        //Make sure the Woocommerce product wasn't associated before
        $wc_product_assoc = $this->get_coa_by_woo_prod_id($product_woo_id);

        if ($wc_product_assoc == false){
            global $wpdb;
            $data_fields = array (
                'product_name'	 => $product_name,
                'botanical_name' => $botanical_name,
                'product_woo_id' => $product_woo_id,
                'basic_data'     => $basic_data,
                'sku_code'       => $sku_code,
                'upc_code'       => $upc_code,
                'product_details'   => $product_details,
                'created'	     => current_time('mysql'),
                'edited'	     => current_time('mysql'),
            );

            $rowResult = $wpdb->insert($this->db_table_products,  $data_fields , $format = NULL);

            if($wpdb->insert_id){
                //success
                return 'Saved!';
            } else {
                //something failed
                return 'Something went wrong.';
            }
        } else {
            //Woocommerce product already associated
            return 'You already associated this Woocommerce product to "'.$wc_product_assoc->product_name.'"';
        }

    }

    //method to edit coa
    public function edit_coa_product($idCOAProd, $coa_data){
        $idCOAProd = absint($idCOAProd);

        $product_name    = (isset($coa_data['product_name'])) ? sanitize_text_field($coa_data['product_name']) : false;
        $botanical_name  = (isset($coa_data['botanical_name'])) ? sanitize_text_field($coa_data['botanical_name']) : false;
        $product_woo_id  = (isset($coa_data['product_woo_id'])) ? absint($coa_data['product_woo_id']) : false;
        $basic_data      = (isset($coa_data['basic_data'])) ? sanitize_textarea_field($coa_data['basic_data']) : false;
        $sku_code        = (isset($coa_data['sku_code'])) ? sanitize_text_field($coa_data['sku_code']) : false;
        $upc_code        = (isset($coa_data['upc_code'])) ? sanitize_text_field($coa_data['upc_code']) : false;
        $product_details  = (isset($coa_data['product_details'])) ? sanitize_text_field($coa_data['product_details']) : false;

        //Make sure the Woocommerce product wasn't associated before
        $wc_product_assoc = $this->get_coa_by_woo_prod_id($product_woo_id, $idCOAProd);

        if ($wc_product_assoc == false){
            global $wpdb;
            $where = [ 'id' => $idCOAProd ];

            if($product_name){$args_update['product_name'] = $product_name;}
            if($botanical_name){$args_update['botanical_name'] = $botanical_name;}
            if($product_woo_id){$args_update['product_woo_id'] = $product_woo_id;}
            if($basic_data){$args_update['basic_data'] = $basic_data;}
            if($sku_code){$args_update['sku_code'] = $sku_code;}
            if($upc_code){$args_update['upc_code'] = $upc_code;}
            if($product_details){$args_update['product_details'] = $product_details;}


            //If anything to update
            if(isset($args_update)){
                $args_update['edited'] = current_time('mysql');
                $rowResult = $wpdb->update($this->db_table_products, $args_update, $where);
                return 'Product updated';
            } else {
                return 'Nothing to update';
            }
        } else {
            //Woocommerce product already associated
            return 'You already associated this Woocommerce product to "'.$wc_product_assoc->product_name.'"';           
        }
    }

    //method to delete coa    
    public function delete_product($idCOAProd){
        $idCOAProd = absint($idCOAProd);
        global $wpdb;
        $rowResult = $wpdb->delete($this->db_table_products , array( 'id' => $idCOAProd ) );
        
        return true;
    }

}

?>