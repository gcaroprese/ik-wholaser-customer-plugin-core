<?php
/*

CSS Admin COAs DB View and Edit - Wholesale Customer Core
Created: 03/10/2023
Update:  03/15/2021
Author: Gabriel Caroprese

*/
if ( ! defined('ABSPATH')) exit('restricted access');

$coa_data = new IK_HN_COAs();

if ($_SERVER['REQUEST_METHOD'] == 'POST'){

    if (isset($_POST['recapkey']) && isset($_POST['recapseckey'])){
        $recaptcha_k = sanitize_text_field($_POST['recapkey']);
        $recaptcha_s = sanitize_text_field($_POST['recapseckey']);
    
        $recapchaEnabled = (isset($_POST['userecaptcha'])) ? true : false;
        $recaptcha_option = (isset($_POST['userecaptcha_option'])) ? sanitize_text_field($_POST['userecaptcha_option']) : 'v2';
        
        
        $configData = array(
            'enabled' => $recapchaEnabled,
            'key'     => $recaptcha_k,
            'secret'  => $recaptcha_s,
            'option'  => $recaptcha_option,
        );

        $coa_data->update_config($configData);
    }

}


//variables

$recaptcha_config = $coa_data->get_config();
$recaptchakey = ($recaptcha_config['key'] == true) ? $recaptcha_config['key'] : '';
$recaptchasecret = ($recaptcha_config['secret'] == true) ? $recaptcha_config['secret'] : '';
$recapchaEnabled = $recaptcha_config['enabled'];
$recapchaoptionData = $recaptcha_config['option'];

if ($recaptchakey == false || $recaptchakey == NULL){
    $recaptchakey = '';
}
if ($recaptchasecret == false || $recaptchasecret == NULL){
    $recaptchasecret = '';
}
if ($recapchaEnabled){
    $recapchacheck = 'checked';
} else {
    $recapchacheck = '';
}

$robotchecked = 'checked';
$invisiblechecked = '';
if ($recapchaoptionData == 'v3'){
    $robotchecked = '';
    $invisiblechecked = 'checked';
}

?>

<style>
.error, .updated, #setting-error-tgmpa{display: none! important;}
</style>
<div id="ik_hn_coa_db_config">
    <h1>Recaptcha Config / COA Form</h1>
    <form action="" method="post" id="ik_hn_coa_db_config_form" enctype="multipart/form-data" autocomplete="no">
        <p>Create keys at <a href="https://www.google.com/recaptcha/admin" target="_blank">Google Recaptcha</a></p>
        <p>
            <label for="recaptcha-key">
                <span>Key</span><br />
                <input type="text" name="recapkey" value="<?php echo $recaptchakey; ?>" />
            </label>
        </p>
        <p>
            <label for="recaptcha-secret-key">
                <span>Secret Key</span><br />
                <input type="password" readonly="readonly" onfocus="this.removeAttribute('readonly');" name="recapseckey" value="<?php echo $recaptchasecret; ?>" />
            </label>
        </p>
        <p class="ik_recaptcha_radio_options">
            <label for="recaptcha-option-robot">
                <input type="radio" name="userecaptcha_option" value="v2" <?php echo $robotchecked; ?> /> V2 - I'm not a Robot
            </label>
            <label for="recaptcha-option-invisible">
                <input type="radio" name="userecaptcha_option" value="v3" <?php echo $invisiblechecked; ?> /> V3 - Invisible
            </label>
        </p>
        <p>
            <label>
                <input type="checkbox" name="userecaptcha" <?php echo $recapchacheck; ?> value="1">
                <span>Enable Recaptcha.</span>
            </label>
        </p>
        <p>
            <input type="submit" value="Save" class="button-primary">
        </p>
    </form>
</div>