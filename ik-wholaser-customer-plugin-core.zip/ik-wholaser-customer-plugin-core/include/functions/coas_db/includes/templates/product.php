<?php
/*

COAs DB View and Edit Product - Wholesale Customer Core
Created: 03/10/2023
Update:  03/15/2021
Author: Gabriel Caroprese

*/
if ( ! defined('ABSPATH')) exit('restricted access');

$coa_product_data = new IK_HN_COA_Product();


if (isset($_GET['search'])){
    $search = sanitize_text_field($_GET['search']);
} else {
    $search = NULL;
}


//If form was submited
$result = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    if (isset($_POST['id_product']) && isset($_GET['edit'])){
        $coa_product_id = absint($_GET['edit']);
        $product_id_form = absint($_POST['id_product']);
        $coa_product = $coa_product_data->get_coa_product($coa_product_id);

        if($coa_product && $coa_product_id == $product_id_form){
            if (isset($_POST['product_name']) && isset($_POST['botanical_name'])){

                $product_name = sanitize_text_field($_POST['product_name']);
                $product_name = str_replace('\\', '', $product_name);
                $botanical_name = sanitize_text_field($_POST['botanical_name']);
                $botanical_name = str_replace('\\', '', $botanical_name);
                
                //Not required fiels
                $product_woo_id = (isset($_POST['product_woo_id'])) ? absint($_POST['product_woo_id']) : $coa_product->product_woo_id;
                $basic_data = (isset($_POST['basic_data'])) ? sanitize_textarea_field($_POST['basic_data']) : $coa_product->basic_data;
                $sku_code = (isset($_POST['sku_code'])) ? sanitize_text_field($_POST['sku_code']) : $coa_product->sku_code;
                $upc_code = (isset($_POST['upc_code'])) ? sanitize_text_field($_POST['upc_code']) : $coa_product->upc_code;
                $product_details = (isset($_POST['product_details'])) ? sanitize_textarea_field($_POST['product_details']) : $coa_product->product_details;
            
                global $wpdb;
                $data_fields = array (
                    'product_name'	 => $product_name,
                    'botanical_name' => $botanical_name,
                    'product_woo_id' => $product_woo_id,
                    'basic_data'     => $basic_data,
                    'sku_code'       => $sku_code,
                    'upc_code'       => $upc_code,
                    'product_details'   => $product_details,
                    'uploaded'	     => current_time('mysql'),
                    'edited'	     => current_time('mysql'),
                );
        
                $result = $coa_product_data->edit_coa_product($product_id_form, $data_fields);       
            } else {
                $result = 'Data Incomplete';
            }
        } else {
            $result = "Something's wrong. Contact support.";
        }   
    } else {
        if (isset($_POST['product_name']) && isset($_POST['botanical_name'])){

            $product_name = sanitize_text_field($_POST['product_name']);
            $product_name = str_replace('\\', '', $product_name);
            $botanical_name = sanitize_text_field($_POST['botanical_name']);
            $botanical_name = str_replace('\\', '', $botanical_name);
            
            //Not required fiels
            $product_woo_id = (isset($_POST['product_woo_id'])) ? absint($_POST['product_woo_id']) : '';
            $basic_data = (isset($_POST['basic_data'])) ? sanitize_textarea_field($_POST['basic_data']) : '';
            $sku_code = (isset($_POST['sku_code'])) ? sanitize_text_field($_POST['sku_code']) : '';
            $upc_code = (isset($_POST['upc_code'])) ? sanitize_text_field($_POST['upc_code']) : '';
            $product_details = (isset($_POST['product_details'])) ? sanitize_textarea_field($_POST['product_details']) : '';
        
            global $wpdb;
            $data_fields = array (
                'product_name'	 => $product_name,
                'botanical_name' => $botanical_name,
                'product_woo_id' => $product_woo_id,
                'basic_data'     => $basic_data,
                'sku_code'       => $sku_code,
                'upc_code'       => $upc_code,
                'product_details'   => $product_details,
                'uploaded'	     => current_time('mysql'),
                'edited'	     => current_time('mysql'),
            );
    
            $result = $coa_product_data->insert_coa_product($data_fields);
            
        } else {
            $result = 'Data Incomplete';
        }
    }
}


if (isset($_GET['edit'])){
    $coa_product_id = absint($_GET['edit']);
    $coa_product = $coa_product_data->get_coa_product($coa_product_id);
    if($coa_product){
    ?>
        <div id="ik_hn_coa_db_edit_records">
            <h1>Edit COA Product ID #<?php echo $coa_product_id; ?></h1>
            <form action="" method="post" enctype="multipart/form-data" autocomplete="no">
                <div class="ik_hn_coa_db_fields">
                    <input type="hidden" required name="id_product" value="<?php echo $coa_product_id; ?>" /> 
                    <p>
                        <h4>Product Associated (Store) *</h4>
                        <select name="product_woo_id">
                            <option selected>Select Product</option>
                            <?php echo $coa_product_data->get_woo_product_selector($coa_product->product_woo_id); ?>
                        </select>
                    </p>
                    <p>
                        <h4>Product Name *</h4>
                        <input type="text" required name="product_name" value="<?php echo $coa_product->product_name; ?>" /> 
                    </p>
                    <p>
                        <h4>Botanical_name *</h4>
                        <input type="text" required name="botanical_name" value="<?php echo $coa_product->botanical_name; ?>"  /> 
                    </p>
                    <p>
                        <h4>Basic Data</h4>
                        <textarea name="basic_data"><?php echo $coa_product->basic_data; ?></textarea>
                    </p>
                    <p>
                        <h4>SKU Code</h4>
                        <input type="text" name="sku_code" value="<?php echo $coa_product->sku_code; ?>"  /> 
                    </p>
                    <p>
                        <h4>UPC code</h4>
                        <input type="text" name="upc_code" value="<?php echo $coa_product->upc_code; ?>"  /> 
                    </p>
                    <p>
                        <h4>Details</h4>
                        <textarea name="product_details"><?php echo $coa_product->product_details; ?></textarea> 
                    </p>
                </div>
                <input type="submit" class="button button-primary" value="Edit Product" />
                <p id="ik_data_saved"><?php echo $result; ?></p>
            </form>

            <a href="<?php echo IK_HATTON_CORE_COAS_PRODUCTS_MENU; ?>" class="button">Back to List</a>
        </div>    
    <?php
    } else {
        ?>
        <h1>Wrong Link - Return to List</h1>
        <a href="<?php echo IK_HATTON_CORE_COAS_PRODUCTS_MENU; ?>" class="button button-primary">Back to List</a>
        <?php
    }
} else {
    $qtyList = 25;

    if (isset($_GET["list"])){
        // I check if value is integer to avoid errors
        if (strval($_GET["list"]) == strval(intval($_GET["list"])) && $_GET["list"] > 0){
            $page = intval($_GET["list"]);
        } else {
            $page = 1;
        }
    } else {
         $page = 1;
    }
    
    // Chechking order
    if (isset($_GET["orderby"]) && isset($_GET["orderdir"])){
        $orderby = sanitize_text_field($_GET["orderby"]);
        $orderdir = sanitize_text_field($_GET["orderdir"]);  
    } else {
        $orderby = 'id';
        $orderdir = 'DESC';
    } 

    
    $offset = ($page - 1) * $qtyList;
    ?>
    <div id="ik_hn_coa_db_add_records">
        <h1>COAs Products</h1>
        <form action="" method="post" enctype="multipart/form-data" autocomplete="no">
            <div class="ik_hn_coa_db_fields">
                <h3>Add COA Product</h3>
                <p>
                    <h4>Product Associated (Store) *</h4>
                    <select name="product_woo_id">
                        <option selected>Select Product</option>
                        <?php echo $coa_product_data->get_woo_product_selector(); ?>
                    </select>
                </p>
                <p>
                    <h4>Product Name *</h4>
                    <input type="text" required name="product_name" /> 
                </p>
                <p>
                    <h4>Botanical_name *</h4>
                    <input type="text" required name="botanical_name" /> 
                </p>
                <p>
                    <h4>Basic Data</h4>
                    <textarea name="basic_data"></textarea>
                </p>
                <p>
                    <h4>SKU Code</h4>
                    <input type="text" name="sku_code" /> 
                </p>
                <p>
                    <h4>UPC code</h4>
                    <input type="text" name="upc_code" /> 
                </p>
                <p>
                    <h4>Details</h4>
                    <textarea name="product_details"></textarea> 
                </p>
            </div>
            <input type="submit" class="button button-primary" value="Add Product" />
            <p id="ik_data_saved"><?php echo $result; ?></p>
        </form>
    </div>
    <div id ="ik_hn_coa_db_records_existing">
    <?php
        //List of existing COA Products
                    
        $list_coas = $coa_product_data->get_list_coas_products_wrapper_backend($qtyList, $offset, $orderby, $orderdir, $search);

        if ($list_coas != false){
            $list_coas_all = $coa_product_data->qty_coa_products_records();
                $coa_product_dataSubstr = $list_coas_all / $qtyList;
                $total_pages = intval($coa_product_dataSubstr);
                
                if (is_float($coa_product_dataSubstr)){
                    $total_pages = $total_pages + 1;
                }
            echo $list_coas;
    
            
            if ($list_coas_all > $qtyList){
                
                if ($page <= $total_pages){
                    echo '<div class="ik_hn_coa_db_pages">';
                    
                    //Enable certain page ids to show
                    $mitadlist = intval($total_pages/2);
                    
                    $pagesToShow[] = 1;
                    $pagesToShow[] = 2;
                    $pagesToShow[] = 3;
                    $pagesToShow[] = $total_pages;
                    $pagesToShow[] = $total_pages - 1;
                    $pagesToShow[] = $total_pages - 2;
                    $pagesToShow[] = $mitadlist - 2;
                    $pagesToShow[] = $mitadlist - 1;
                    $pagesToShow[] = $mitadlist;
                    $pagesToShow[] = $mitadlist + 1;
                    $pagesToShow[] = $mitadlist + 2;
                    $pagesToShow[] = $page+3;
                    $pagesToShow[] = $page+2;
                    $pagesToShow[] = $page+1;
                    $pagesToShow[] = $page;
                    $pagesToShow[] = $page-1;
                    $pagesToShow[] = $page-2;
                    
                    for ($i = 1; $i <= $total_pages; $i++) {
                        $show_page = false;
                        
                        //Showing enabled pages
                        if (in_array($i, $pagesToShow)) {
                            $show_page = true;
                        }
                        
                        if ($show_page == true){
                            if ($page== $i){
                                $PageNActual = 'actual_page';
                            } else {
                                $PageNActual = "";
                            }
                            echo '<a class="ik_listar_page_coas '.$PageNActual.'" href="'.IK_HATTON_CORE_COAS_PRODUCTS_MENU.'&list='.$i.'">'.$i.'</a>';
                        }
                    }
                    echo '</div>';
                } else {
                            echo 'no';
                        }
            }    	
        
            
            
            
        } else if (isset($_GET['list'])){
            echo "<script>
            window.location.href='".IK_HATTON_CORE_COAS_PRODUCTS_MENU."';
            </script>";
        }else {
            echo '<p class="search-box">
                    <label class="screen-reader-text" for="tag-search-input">Search:</label>
                    <input type="search" id="tag-search-input" name="s" value="">
                    <input type="submit" id="ik_hn_coa_db_search_coas" class="button" value="Search">
                </p>';
                
        }
    ?>
    </div>
    <?php
}
?>
<script>
jQuery(document).ready(function ($) {
    jQuery('#ik_hn_coa_db_add_records select').select2();
    jQuery('#ik_hn_coa_db_edit_records select').select2();

    jQuery("#ik_hn_coa_db_existing th .select_all").on( "click", function() {
        if (jQuery(this).attr('selected') != 'yes'){
            jQuery('#ik_hn_coa_db_existing th .select_all').prop('checked', true);
            jQuery('#ik_hn_coa_db_existing th .select_all').attr('checked', 'checked');
            jQuery('#ik_hn_coa_db_existing tbody tr').each(function() {
                jQuery(this).find('.select_data').prop('checked', true);
                jQuery(this).find('.select_data').attr('checked', 'checked');
            });        
            jQuery(this).attr('selected', 'yes');
        } else {
            jQuery('#ik_hn_coa_db_existing th .select_all').prop('checked', false);
            jQuery('#ik_hn_coa_db_existing th .select_all').removeAttr('checked');
            jQuery('#ik_hn_coa_db_existing tbody tr').each(function() {
                jQuery(this).find('.select_data').prop('checked', false);
                jQuery(this).find('.select_data').removeAttr('checked');
            });   
            jQuery(this).attr('selected', 'no');
            
        }
    });
    jQuery("#ik_hn_coa_db_existing td .select_data").on( "click", function() {
        jQuery('#ik_hn_coa_db_existing th .select_all').prop('checked', false);
        jQuery('#ik_hn_coa_db_existing th .select_all').removeAttr('checked');
        jQuery(this).attr('selected', 'no');
    });
    
    jQuery("#ik_hn_coa_db_existing .ik_hn_coas_button_delete").on( "click", function() {
        var confirmar = confirm('Are you sure to delete this COAs?');
        if (confirmar == true) {
            jQuery('#ik_hn_coa_db_existing tbody tr').each(function() {
            var elemento_borrar = jQuery(this).parent();
                if (jQuery(this).find('.select_data').prop('checked') == true){
                    
                    var registro_tr = jQuery(this);
                    var iddata = registro_tr.attr('iddata');
                    
                    var data = {
                        action: "ik_hn_coa_db_ajax_delete_coa_product",
                        "post_type": "post",
                        "iddata": iddata,
                    };  
        
                    jQuery.post( ajaxurl, data, function(response) {
                        if (response){
                            registro_tr.fadeOut(700);
                            registro_tr.remove();
                        }        
                    });
                }
            });
        }
        jQuery('#ik_hn_coa_db_existing th .select_all').attr('selected', 'no');
        jQuery('#ik_hn_coa_db_existing th .select_all').prop('checked', false);
        jQuery('#ik_hn_coa_db_existing th .select_all').removeAttr('checked');
        return false;
    });
    
    jQuery('#ik_hn_coa_db_existing').on('click','td .ik_hn_coas_button_delete_coa', function(e){
        e.preventDefault();
        var confirmar =confirm('Are you sure to delete?');
        if (confirmar == true) {
            var iddata = jQuery(this).parent().attr('iddata');
            var registro_tr = jQuery('#ik_hn_coa_db_existing tbody').find('tr[iddata='+iddata+']');
            
            var data = {
                action: "ik_hn_coa_db_ajax_delete_coa_product",
                "post_type": "post",
                "iddata": iddata,
            };  
    
            jQuery.post( ajaxurl, data, function(response) {
                if (response){
                    registro_tr.fadeOut(700);
                    registro_tr.remove();
                }        
            });
        }
    });

    jQuery('#ik_hn_coa_db_records_existing').on('click','#searchbutton_coa', function(e){
            e.preventDefault();

            var search = jQuery('#tag-search-input').val();
            var urlnow = window.location.href;
            
            window.location.href = urlnow+'&search='+search;

        });

    jQuery('#ik_hn_coa_db_existing').on('click','.ik_hn_coas_button_edit_coa', function(e){
        e.preventDefault();

        var iddata = parseInt(jQuery(this).parent().attr('iddata'));
        var urlnow = window.location.href;
        
        window.location.href = urlnow+'&edit='+iddata;

    });

    jQuery('#ik_hn_coa_db_existing').on('click','th.worder', function(e){
        e.preventDefault();

        var order = jQuery(this).attr('order');
        var urlnow = window.location.href;
        
        if (order != undefined){
            if (jQuery(this).hasClass('desc')){
                var direc = 'asc';
            } else {
                var direc = 'desc';
            }
            if (order == 'product_name'){
                var orderby = '&orderby=product_name&orderdir='+direc;
                window.location.href = urlnow+orderby;
            } else if (order == 'botanical_name'){
                var orderby = '&orderby=botanical_name&orderdir='+direc;
                window.location.href = urlnow+orderby;
            } else {
                var orderby = '&orderby=id&orderdir='+direc;
                window.location.href = urlnow+orderby;
            }
        }

    });
    
});
</script>