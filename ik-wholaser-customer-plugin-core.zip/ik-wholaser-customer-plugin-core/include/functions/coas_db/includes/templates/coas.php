<?php
/*

COAs DB View and Edit - Wholesale Customer Core
Created: 03/10/2023
Update:  03/15/2021
Author: Gabriel Caroprese

*/
if ( ! defined('ABSPATH')) exit('restricted access');

$coa_data = new IK_HN_COAs();


if (isset($_GET['search'])){
    $search = sanitize_text_field($_GET['search']);
} else {
    $search = NULL;
}


//If form was submited
$result = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST'){

    if (isset($_POST['id_coa']) && isset($_GET['edit'])){
        $coaid = absint($_GET['edit']);
        $coaid_form = absint($_POST['id_coa']);
        $coa = $coa_data->get_coa($coaid);

        if($coa && $coaid == $coaid_form){
            if (isset($_POST['lot_number']) && isset($_POST['product_id']) && isset($_POST['country_origin'])){
                $lot_number = sanitize_text_field($_POST['lot_number']);
                $product_id = absint($_POST['product_id']);
                $country_origin = sanitize_text_field($_POST['country_origin']);
                $country_origin = str_replace('\\', '', $country_origin);
                $maxFileNameLength = 210;
                
                //if file uploaded
                if (isset($_FILES['file'])){
        
                    //Formats accepted
                    $files_supported = array('application/pdf', 'image/jpeg, image/pjpeg', 'image/jpeg, image/pjpeg');
                    
                    if (in_array($_FILES['file']['type'], $files_supported)) {
            
                        $upload = wp_upload_dir();
                        $upload_dir = $upload['basedir'];
                        $target_dir = $upload_dir . '/coas/';
                    
                        $upload_file_name = preg_replace('/\s+/', '', basename($_FILES["file"]["name"]));
                        
                        // Evito nombres repetidos
                        $filecode = substr(md5(uniqid(rand(), true)), 4, 4); // 4 caracteres
                        $filenowDate = date("Y/m/d");
                        $filenumberedDate = strtotime($filenowDate);
                        $filecodigoInv = strtoupper($filecode.$filenumberedDate);
                        
                        $file_name_input = substr(sanitize_file_name($upload_file_name), 0, $maxFileNameLength);
                        $file_name = rand().$filecodigoInv. $file_name_input;
                        $target_file = $target_dir . $file_name;
                        move_uploaded_file($_FILES['file']['tmp_name'], $target_file);
                        
                    } 
                }

                //if spec file uploaded
                if (isset($_FILES['filespecs'])){

                    //Formats accepted
                    $files_supported = array('application/pdf', 'image/jpeg, image/pjpeg', 'image/jpeg, image/pjpeg');
                    
                    if (in_array($_FILES['filespecs']['type'], $files_supported)) {
                        $file_size_specs = $_FILES['filespecs']['size'];
            
                        $upload = wp_upload_dir();
                        $upload_dir = $upload['basedir'];
                        $target_dir = $upload_dir . '/specs/';
                    
                        $upload_file_name = preg_replace('/\s+/', '', basename($_FILES["filespecs"]["name"]));
                        
                        // Evito nombres repetidos
                        $filecode = substr(md5(uniqid(rand(), true)), 4, 4); // 4 caracteres
                        $filenowDate = date("Y/m/d");
                        $filenumberedDate = strtotime($filenowDate);
                        $filecodigoInv = strtoupper($filecode.$filenumberedDate);
                        
                        $spec_file_name = substr(sanitize_file_name($upload_file_name), 0, $maxFileNameLength);
                        $file_name_specs = rand().$filecodigoInv. $spec_file_name;
                        $target_file = $target_dir . $file_name_specs;
                        move_uploaded_file($_FILES['filespecs']['tmp_name'], $target_file);
                        
                    } 
                }

                //Not required fiels
                $packaging_date = (isset($_POST['packaging_date'])) ? date("Y-m-d", strtotime(sanitize_text_field($_POST['packaging_date']))) : '0000-00-00';
                $batch_number = (isset($_POST['batch_number'])) ? sanitize_text_field($_POST['batch_number']) : $coa->batch_number;
                $cut_size = (isset($_POST['cut_size'])) ? sanitize_text_field($_POST['cut_size']) : $coa->cut_size;
                $shelf_life = (isset($_POST['shelf_life'])) ? sanitize_text_field($_POST['shelf_life']) : $coa->shelf_life;
                $compliance = (isset($_POST['compliance'])) ? sanitize_text_field($_POST['compliance']) : $coa->compliance;
                $packaging_type = (isset($_POST['packaging_type'])) ? sanitize_text_field($_POST['packaging_type']) : $coa->packaging_type;
                $file_name = (isset($file_name)) ? $file_name : $coa->file_name;
                $spec_file_name = (isset($file_name_specs)) ? $file_name_specs : $coa->spec_file;
                $more_details = (isset($_POST['more_details'])) ? sanitize_textarea_field($_POST['more_details']) : $coa->more_details;
                $more_details = str_replace('\\', '', $more_details);
            
                global $wpdb;
                $data_fields = array (
                    'lot_number'	 => $lot_number,
                    'product_id'     => $product_id,
                    'batch_number'   => $batch_number,
                    'country_origin' => $country_origin,
                    'cut_size'       => $cut_size,
                    'packaging_date' => $packaging_date,
                    'shelf_life'     => $shelf_life,
                    'compliance'     => $compliance,
                    'packaging_type' => $packaging_type,
                    'uploaded'	     => current_time('mysql'),
                    'edited'	     => current_time('mysql'),
                    'file_name'	     => $file_name,
                    'spec_file'	     => $spec_file_name,
                    'more_details'	 => $more_details,
                );
        
                $result = $coa_data->edit_coa($coaid_form, $data_fields);       
            } else {
                $result = 'Data Incomplete';
            }
        } else {
            $result = "Something's wrong. Contact support.";
        }   
    } else {
        if (isset($_POST['lot_number']) && isset($_POST['product_id']) && isset($_POST['country_origin'])){
            $lot_number = sanitize_text_field($_POST['lot_number']);
            $product_id = absint($_POST['product_id']);
            $country_origin = sanitize_text_field($_POST['country_origin']);
            $country_origin = str_replace('\\', '', $country_origin);
            
            //if file uploaded
            if (isset($_FILES['file'])){
    
                //Formats accepted
                $files_supported = array('application/pdf', 'image/jpeg, image/pjpeg', 'image/jpeg, image/pjpeg');
                
                if (in_array($_FILES['file']['type'], $files_supported)) {
                        $file_size = $_FILES['file']['size'];
        
                    $file = $_FILES['file'];
                    $upload = wp_upload_dir();
                    $upload_dir = $upload['basedir'];
                    $target_dir = $upload_dir . '/coas/';
                
                    $upload_file_name = preg_replace('/\s+/', '', basename($_FILES["file"]["name"]));
                    
                    // Evito nombres repetidos
                    $filecode = substr(md5(uniqid(rand(), true)), 4, 4); // 4 caracteres
                    $filenowDate = date("Y/m/d");
                    $filenumberedDate = strtotime($filenowDate);
                    $filecodigoInv = strtoupper($filecode.$filenumberedDate);
                    
                    $file_name_input = substr(sanitize_file_name($upload_file_name), 0, $maxFileNameLength);
                    $file_name = rand().$filecodigoInv. $file_name_input;
                    $target_file = $target_dir . $file_name;
                    move_uploaded_file($_FILES['file']['tmp_name'], $target_file);
                } 
            }

            //if spec file uploaded
            if (isset($_FILES['filespecs'])){

                //Formats accepted
                $files_supported = array('application/pdf', 'image/jpeg, image/pjpeg', 'image/jpeg, image/pjpeg');
                
                if (in_array($_FILES['filespecs']['type'], $files_supported)) {
                    $file_size_specs = $_FILES['filespecs']['size'];
        
                    $upload = wp_upload_dir();
                    $upload_dir = $upload['basedir'];
                    $target_dir = $upload_dir . '/specs/';
                
                    $upload_file_name = preg_replace('/\s+/', '', basename($_FILES["filespecs"]["name"]));
                    
                    // Evito nombres repetidos
                    $filecode = substr(md5(uniqid(rand(), true)), 4, 4); // 4 caracteres
                    $filenowDate = date("Y/m/d");
                    $filenumberedDate = strtotime($filenowDate);
                    $filecodigoInv = strtoupper($filecode.$filenumberedDate);
                    
                    $spec_file_name = substr(sanitize_file_name($upload_file_name), 0, $maxFileNameLength);
                    $file_name_specs = rand().$filecodigoInv. $spec_file_name;
                    $target_file = $target_dir . $file_name_specs;
                    move_uploaded_file($_FILES['filespecs']['tmp_name'], $target_file);
                    
                } 
            }

            //Not required fiels
            $packaging_date = (isset($_POST['packaging_date'])) ? date("Y-m-d", strtotime(sanitize_text_field($_POST['packaging_date']))) : '0000-00-00';
            $batch_number = (isset($_POST['batch_number'])) ? sanitize_text_field($_POST['batch_number']) : '';
            $cut_size = (isset($_POST['cut_size'])) ? sanitize_text_field($_POST['cut_size']) : '';
            $shelf_life = (isset($_POST['shelf_life'])) ? sanitize_text_field($_POST['shelf_life']) : '';
            $compliance = (isset($_POST['compliance'])) ? sanitize_text_field($_POST['compliance']) : '';
            $packaging_type = (isset($_POST['packaging_type'])) ? sanitize_text_field($_POST['packaging_type']) : '';
            $file_name = (isset($file_name)) ? $file_name : '';
            $file_name_specs = (isset($file_name_specs)) ? $file_name_specs : '';
            $more_details = (isset($_POST['more_details'])) ? sanitize_textarea_field($_POST['more_details']) : '';
            $more_details = str_replace('\\', '', $more_details);
        
            global $wpdb;
            $data_fields = array (
                'lot_number'	 => $lot_number,
                'product_id'     => $product_id,
                'batch_number'   => $batch_number,
                'country_origin' => $country_origin,
                'cut_size'       => $cut_size,
                'packaging_date' => $packaging_date,
                'shelf_life'     => $shelf_life,
                'compliance'     => $compliance,
                'packaging_type' => $packaging_type,
                'uploaded'	     => current_time('mysql'),
                'edited'	     => current_time('mysql'),
                'file_name'	     => $file_name,
                'spec_file'	     => $file_name_specs,
                'more_details'	 => $more_details,
            );
    
            $result = $coa_data->insert_coa($data_fields);
            
        } else {
            $result = 'Data Incomplete';
        }
    }
}


if (isset($_GET['edit'])){
    $coaid = absint($_GET['edit']);
    $coa = $coa_data->get_coa($coaid);
    if($coa){
    ?>
        <div id="ik_hn_coa_db_edit_records">
            <h1>Edit COA #<?php echo $coaid; ?></h1>
            <form action="" method="post" enctype="multipart/form-data" autocomplete="no">
                <div class="ik_hn_coa_db_fields">
                    <input type="hidden" required name="id_coa" value="<?php echo $coaid; ?>" /> 
                    <p>
                        <h4>Product *</h4>
                        <select required name="product_id">
                            <option selected>Select Product</option>
                            <?php echo $coa_data->get_coa_product_selector($coa->product_id); ?>
                        </select>
                    </p>
                    <p>
                        <h4>Lot # *</h4>
                        <input type="text" required name="lot_number" value="<?php echo $coa->lot_number; ?>" /> 
                    </p>
                    <p>
                        <h4>Country of Origin *</h4>
                        <input type="text" required name="country_origin" value="<?php echo $coa->country_origin; ?>" /> 
                    </p>
                    <p>
                        <h4>Cut Size</h4>
                        <input type="text" name="cut_size" value="<?php echo $coa->cut_size; ?>" /> 
                    </p>
                    <p>
                        <h4>Packaging Date</h4>
                        <input type="date" name="packaging_date" value="<?php echo $coa->packaging_date; ?>" /> 
                    </p>
                    <p>
                        <h4>Shelf Life</h4>
                        <input type="text" name="shelf_life" value="<?php echo $coa->shelf_life; ?>" /> 
                    </p>
                    <p>
                        <h4>Compliance</h4>
                        <input type="text" name="compliance" value="<?php echo $coa->compliance; ?>" /> 
                    </p>
                    <p>
                        <h4>Packaging Type</h4>
                        <input type="text" name="packaging_type" value="<?php echo $coa->packaging_type; ?>" /> 
                    </p>
                    <p>
                        <h4>PDF - COA File (replace)</h4>
                        <input type="file" name="file" /> <br /> 
                        <?php if($coa->file_name != ''){?>
                            <a href="<?php echo wp_upload_dir()['baseurl'].'/coas/'.$coa->file_name; ?>" class="button" target="_blank">View</a>  
                        <?php } ?>
                        </p>
                    <p>
                    <p>
                        <h4>Spec Sheet File (replace)</h4>
                        <input type="file" name="filespecs" /> <br /> 
                        <?php if($coa->spec_file != '' && $coa->spec_file != NULL){?>
                            <a href="<?php echo wp_upload_dir()['baseurl'].'/specs/'.$coa->spec_file; ?>" class="button" target="_blank">View</a>  
                        <?php } ?>
                    </p>
                    <p> 
                        <h4>Details</h4>
                        <textarea name="more_details"><?php echo $coa->more_details; ?></textarea> 
                    </p>
                </div>
                <input type="submit" class="button button-primary" value="Edit COA" />
                <p id="ik_data_saved"><?php echo $result; ?></p>
            </form>

            <a href="<?php echo IK_HATTON_CORE_COAS_COA_MENU; ?>" class="button">Back to List</a>
        </div>    
    <?php
    } else {
        ?>
        <h1>Wrong Link - Return to List</h1>
        <a href="<?php echo IK_HATTON_CORE_COAS_COA_MENU; ?>" class="button button-primary">Back to List</a>
        <?php
    }
} else {
    $qtyList = 25;

    if (isset($_GET["list"])){
        // I check if value is integer to avoid errors
        if (strval($_GET["list"]) == strval(intval($_GET["list"])) && $_GET["list"] > 0){
            $page = intval($_GET["list"]);
        } else {
            $page = 1;
        }
    } else {
         $page = 1;
    }
    
    // Chechking order
    if (isset($_GET["orderby"]) && isset($_GET["orderdir"])){
        $orderby = sanitize_text_field($_GET["orderby"]);
        $orderdir = sanitize_text_field($_GET["orderdir"]);  
    } else {
        $orderby = 'id';
        $orderdir = 'DESC';
    } 

    
    $offset = ($page - 1) * $qtyList;
    ?>
    <div id="ik_hn_coa_db_add_records">
        <h1>COAs</h1>
        <form action="" method="post" enctype="multipart/form-data" autocomplete="no">
            <div class="ik_hn_coa_db_fields">
                <h3>Add COA</h3>
                <p>
                    <h4>Product *</h4>
                    <select required name="product_id">
                        <option selected>Select Product</option>
                        <?php echo $coa_data->get_coa_product_selector(); ?>
                    </select><br />
                    <span class="product_id_subfield subfield">Product can't be found? <a target="_blank" href="<?php echo IK_HATTON_CORE_COAS_PRODUCTS_MENU; ?>">Add products here.</a></span>
                </p>
                <p>
                    <h4>Lot # *</h4>
                    <input type="text" required name="lot_number" /> 
                </p>
                <p>
                    <h4>Country of Origin *</h4>
                    <input type="text" required name="country_origin" /> 
                </p>
                <p>
                    <h4>Cut Size</h4>
                    <input type="text" name="cut_size" /> 
                </p>
                <p>
                    <h4>Packaging Date</h4>
                    <input type="date" name="packaging_date" /> 
                </p>
                <p>
                    <h4>Shelf Life</h4>
                    <input type="text" name="shelf_life" /> 
                </p>
                <p>
                    <h4>Compliance</h4>
                    <input type="text" name="compliance" /> 
                </p>
                <p>
                    <h4>Packaging Type</h4>
                    <input type="text" name="packaging_type" /> 
                </p>
                <p>
                    <h4>PDF - COA File</h4>
                    <input type="file" name="file" /> 
                </p>
                <p>
                    <h4>Spec Sheet File</h4>
                    <input type="file" name="filespecs" /> 
                </p>
                <p>
                    <h4>Details</h4>
                    <textarea name="more_details"></textarea> 
                </p>
            </div>
            <input type="submit" class="button button-primary" value="Add COA" />
            <p id="ik_data_saved"><?php echo $result; ?></p>
        </form>
    </div>
    <div id ="ik_hn_coa_db_records_existing">
    <?php
        //List of existing COAs
                    
        $list_coas = $coa_data->get_list_coas_wrapper_backend($qtyList, $offset, $orderby, $orderdir, $search);

        if ($list_coas != false){
            $list_coas_all = $coa_data->qty_coa_records();
                $coa_dataSubstr = $list_coas_all / $qtyList;
                $total_pages = intval($coa_dataSubstr);
                
                if (is_float($coa_dataSubstr)){
                    $total_pages = $total_pages + 1;
                }
            echo $list_coas;
    
            
            if ($list_coas_all > $qtyList){
                
                if ($page <= $total_pages){
                    echo '<div class="ik_hn_coa_db_pages">';
                    
                    //Enable certain page ids to show
                    $mitadlist = intval($total_pages/2);
                    
                    $pagesToShow[] = 1;
                    $pagesToShow[] = 2;
                    $pagesToShow[] = 3;
                    $pagesToShow[] = $total_pages;
                    $pagesToShow[] = $total_pages - 1;
                    $pagesToShow[] = $total_pages - 2;
                    $pagesToShow[] = $mitadlist - 2;
                    $pagesToShow[] = $mitadlist - 1;
                    $pagesToShow[] = $mitadlist;
                    $pagesToShow[] = $mitadlist + 1;
                    $pagesToShow[] = $mitadlist + 2;
                    $pagesToShow[] = $page+3;
                    $pagesToShow[] = $page+2;
                    $pagesToShow[] = $page+1;
                    $pagesToShow[] = $page;
                    $pagesToShow[] = $page-1;
                    $pagesToShow[] = $page-2;
                    
                    for ($i = 1; $i <= $total_pages; $i++) {
                        $show_page = false;
                        
                        //Showing enabled pages
                        if (in_array($i, $pagesToShow)) {
                            $show_page = true;
                        }
                        
                        if ($show_page == true){
                            if ($page== $i){
                                $PageNActual = 'actual_page';
                            } else {
                                $PageNActual = "";
                            }
                            echo '<a class="ik_listar_page_coas '.$PageNActual.'" href="'.IK_HATTON_CORE_COAS_COA_MENU.'&list='.$i.'">'.$i.'</a>';
                        }
                    }
                    echo '</div>';
                } else {
                            echo 'no';
                        }
            }    	
        
            
            
            
        } else if (isset($_GET['list'])){
            echo "<script>
            window.location.href='".IK_HATTON_CORE_COAS_COA_MENU."';
            </script>";
        }else {
            echo '<p class="search-box">
                    <label class="screen-reader-text" for="tag-search-input">Search:</label>
                    <input type="search" id="tag-search-input" name="s" value="">
                    <input type="submit" id="ik_hn_coa_db_search_coas" class="button" value="Search">
                </p>';
                
        }
    ?>
    </div>
    <?php
}

?>
  <script>
    jQuery(document).ready(function ($) {
        jQuery('#ik_hn_coa_db_add_records select').select2();
        jQuery('#ik_hn_coa_db_edit_records select').select2();

        jQuery("#ik_hn_coa_db_existing th .select_all").on( "click", function() {
            if (jQuery(this).attr('selected') != 'yes'){
                jQuery('#ik_hn_coa_db_existing th .select_all').prop('checked', true);
                jQuery('#ik_hn_coa_db_existing th .select_all').attr('checked', 'checked');
                jQuery('#ik_hn_coa_db_existing tbody tr').each(function() {
                    jQuery(this).find('.select_data').prop('checked', true);
                    jQuery(this).find('.select_data').attr('checked', 'checked');
                });        
                jQuery(this).attr('selected', 'yes');
            } else {
                jQuery('#ik_hn_coa_db_existing th .select_all').prop('checked', false);
                jQuery('#ik_hn_coa_db_existing th .select_all').removeAttr('checked');
                jQuery('#ik_hn_coa_db_existing tbody tr').each(function() {
                    jQuery(this).find('.select_data').prop('checked', false);
                    jQuery(this).find('.select_data').removeAttr('checked');
                });   
                jQuery(this).attr('selected', 'no');
                
            }
        });
        jQuery("#ik_hn_coa_db_existing td .select_data").on( "click", function() {
            jQuery('#ik_hn_coa_db_existing th .select_all').prop('checked', false);
            jQuery('#ik_hn_coa_db_existing th .select_all').removeAttr('checked');
            jQuery(this).attr('selected', 'no');
        });
        
        jQuery("#ik_hn_coa_db_existing .ik_hn_coas_button_delete").on( "click", function() {
            var confirmar = confirm('Are you sure to delete this COAs?');
            if (confirmar == true) {
                jQuery('#ik_hn_coa_db_existing tbody tr').each(function() {
                var elemento_borrar = jQuery(this).parent();
                    if (jQuery(this).find('.select_data').prop('checked') == true){
                        
                        var registro_tr = jQuery(this);
                        var iddata = registro_tr.attr('iddata');
                        
                        var data = {
                            action: "ik_hn_coa_db_ajax_delete_coa",
                            "post_type": "post",
                            "iddata": iddata,
                        };  
            
                        jQuery.post( ajaxurl, data, function(response) {
                            if (response){
                                registro_tr.fadeOut(700);
                                registro_tr.remove();
                            }        
                        });
                    }
                });
            }
            jQuery('#ik_hn_coa_db_existing th .select_all').attr('selected', 'no');
            jQuery('#ik_hn_coa_db_existing th .select_all').prop('checked', false);
            jQuery('#ik_hn_coa_db_existing th .select_all').removeAttr('checked');
            return false;
        });
        
        jQuery('#ik_hn_coa_db_existing').on('click','td .ik_hn_coas_button_delete_coa', function(e){
            e.preventDefault();
            var confirmar =confirm('Are you sure to delete?');
            if (confirmar == true) {
                var iddata = jQuery(this).parent().attr('iddata');
                var registro_tr = jQuery('#ik_hn_coa_db_existing tbody').find('tr[iddata='+iddata+']');
                
                var data = {
                    action: "ik_hn_coa_db_ajax_delete_coa",
                    "post_type": "post",
                    "iddata": iddata,
                };  
        
                jQuery.post( ajaxurl, data, function(response) {
                    if (response){
                        registro_tr.fadeOut(700);
                        registro_tr.remove();
                    }        
                });
            }
        });

        jQuery('#ik_hn_coa_db_existing').on('click','.ik_hn_coas_button_edit_coa', function(e){
            e.preventDefault();

            var iddata = parseInt(jQuery(this).parent().attr('iddata'));
            var urlnow = window.location.href;
            
            window.location.href = urlnow+'&edit='+iddata;

        });

        jQuery('#ik_hn_coa_db_records_existing').on('click','#searchbutton_coa', function(e){
            e.preventDefault();

            var search = jQuery('#tag-search-input').val();
            var urlnow = window.location.href;
            
            window.location.href = urlnow+'&search='+search;

        });

        jQuery('#ik_hn_coa_db_existing').on('click','th.worder', function(e){
            e.preventDefault();

            var order = jQuery(this).attr('order');
            var urlnow = window.location.href;
            
            if (order != undefined){
                if (jQuery(this).hasClass('desc')){
                    var direc = 'asc';
                } else {
                    var direc = 'desc';
                }
                if (order == 'lot_number'){
                    var orderby = '&orderby=lot_number&orderdir='+direc;
                    window.location.href = urlnow+orderby;
                } else if (order == 'packaging_date'){
                    var orderby = '&orderby=packaging_date&orderdir='+direc;
                    window.location.href = urlnow+orderby;
                } else if (order == 'product_id'){
                    var orderby = '&orderby=product_id&orderdir='+direc;
                    window.location.href = urlnow+orderby;
                } else if (order == 'country_origin'){
                    var orderby = '&orderby=country_origin&orderdir='+direc;
                    window.location.href = urlnow+orderby;
                } else {
                    var orderby = '&orderby=id&orderdir='+direc;
                    window.location.href = urlnow+orderby;
                }
            }

        });
        
    });
</script>