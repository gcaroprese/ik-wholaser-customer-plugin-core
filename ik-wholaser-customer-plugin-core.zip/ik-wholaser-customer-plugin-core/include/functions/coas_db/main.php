<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - COAs DB
Created: 03/02/2023
Last Update: 03/08/2023
Author: Gabriel Caroprese
*/

$hn_coa_enabled = (defined('HN_COA_DATA_ENABLED')) ? rest_sanitize_boolean(HN_COA_DATA_ENABLED) : false;

if($hn_coa_enabled){

    define( 'IK_HATTON_CORE_COAS_DIR', IK_HATTON_CORE_DIR.'/include/functions/coas_db/includes/' );
    define( 'IK_HATTON_CORE_COAS_DIR_PUBLIC', IK_HATTON_CORE_PUBLIC.'include/functions/coas_db/includes/' );
    
    //URL for COA Menu page
    define( 'IK_HATTON_CORE_COAS_COA_MENU', get_site_url().'/wp-admin/admin.php?page=ik_hn_coa_db_menu' );
    define( 'IK_HATTON_CORE_COAS_PRODUCTS_MENU', get_site_url().'/wp-admin/admin.php?page=ik_hn_coa_products' );

    require_once(IK_HATTON_CORE_COAS_DIR.'product_coas.class.php');
    require_once(IK_HATTON_CORE_COAS_DIR.'coas.class.php');
    require_once(IK_HATTON_CORE_COAS_DIR.'init.php');
    require_once(IK_HATTON_CORE_COAS_DIR.'ajax_functions.php');
    require_once(IK_HATTON_CORE_COAS_DIR.'shortcode_form.php');

}

?>