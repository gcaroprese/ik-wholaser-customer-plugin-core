<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/* 
Wholesale Customer Plugin - Google Scripts functions
Created: 03/02/2023
Last Update: 24/02/2023
Author: Gabriel Caroprese
*/

//scripts for wp_head
add_action('wp_head', 'ik_hnaturals_head_scripts_google');
function ik_hnaturals_head_scripts_google(){
?>
	<!-- Global site tag (gtag.js) - Google Analytics & Conversion Tracking -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-115155783-1"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-115155783-1');
	  gtag('config', 'AW-718346273');
	</script>
	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-KPJL7JV');</script>
	<!-- End Google Tag Manager -->
	<!-- Facebook Pixel Code -->
	<script>
	  !function(f,b,e,v,n,t,s)
	  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
	  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
	  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
	  n.queue=[];t=b.createElement(e);t.async=!0;
	  t.src=v;s=b.getElementsByTagName(e)[0];
	  s.parentNode.insertBefore(t,s)}(window, document,'script',
	  'https://connect.facebook.net/en_US/fbevents.js');
	  fbq('init', '841244636253899');
	  fbq('track', 'PageView');
	</script>
	<noscript><img height="1" width="1" style="display:none"
	  src="https://www.facebook.com/tr?id=841244636253899&ev=PageView&noscript=1"
	/></noscript>
	<!-- End Facebook Pixel Code -->
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KPJL7JV"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->
	<?php
}


// scripts for Google Analytics
add_action( 'wp_footer', 'ik_footer_scripts_analytics_conversions' );
function ik_footer_scripts_analytics_conversions() {
	$google_ads_id = (defined('HN_GOOGLE_ADS_ID')) ? sanitize_text_field(HN_GOOGLE_ADS_ID) : 'AW-718346273';
	$google_tag_id = (defined('HN_GOOGLE_TAG_ID')) ? sanitize_text_field(HN_GOOGLE_TAG_ID) : 'G-ML47YS9LRF';
	$facebook_pixel_id = (defined('HN_FB_PIXEL_ID')) ? sanitize_text_field(HN_FB_PIXEL_ID) : '841244636253899';

?>
	<!-- Global site tag (gtag.js) - Google Ads: 718346273 -->
	<script ddi async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $google_ads_id; ?>"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', '<?php echo $google_ads_id; ?>');
	</script>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $google_tag_id; ?>"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', '<?php echo $google_tag_id; ?>');
	</script>
	<!-- Facebook Pixel Code -->
	<script>
	  !function(f,b,e,v,n,t,s)
	  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
	  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
	  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
	  n.queue=[];t=b.createElement(e);t.async=!0;
	  t.src=v;s=b.getElementsByTagName(e)[0];
	  s.parentNode.insertBefore(t,s)}(window, document,'script',
	  'https://connect.facebook.net/en_US/fbevents.js');
	  fbq('init', '<?php echo $facebook_pixel_id; ?>');
	  fbq('track', 'PageView');
	</script>
	<noscript><img height="1" width="1" style="display:none"
	  src="https://www.facebook.com/tr?id=<?php echo $facebook_pixel_id; ?>&ev=PageView&noscript=1"
	/></noscript>
	<!-- End Facebook Pixel Code -->
<?php
	//to save order data for conversions
    if ( is_order_received_page() ) {
        ?>
		<!-- Event snippet for Wholesale Customer Purchase conversion page -->
		<script>
		gtag('event', 'conversion', {
			'send_to': '<?php echo $google_ads_id; ?>/FBzgCN6wla4BEKGwxNYC',
			'transaction_id': ''
		});
		</script>
		<script async src="https://tag.clearbitscripts.com/v1/pk_e91291eb23ae46e98fcd00dd0ad1fcb9/tags.js" referrerpolicy="strict-origin-when-cross-origin"></script>
        <?php
    }
}
?>