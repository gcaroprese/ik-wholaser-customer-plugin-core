<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
Wholesale Customer Plugin - Init 
Created: 03/02/2023
Last Update: 24/02/2023
Author: Gabriel Caroprese
*/

$dir_include_functions = IK_HATTON_CORE_DIR.'/include/functions/';

require_once(IK_HATTON_CORE_DIR.'/include/templates/config-options-texts.php');
require_once($dir_include_functions.'/label_generator/init.php');
require_once($dir_include_functions.'/catalog/init.php');
require_once($dir_include_functions.'table_price_comparison.php');
require_once($dir_include_functions.'certification_logos.php');
require_once($dir_include_functions.'woocommerce_general.php');
require_once($dir_include_functions.'contact7_spam_and_scripts.php');
require_once($dir_include_functions.'google-and-rel-scripts.php');
require_once($dir_include_functions.'after_cart.php');
require_once($dir_include_functions.'maintenance-mode.php');
require_once($dir_include_functions.'preorders-functions.php');
require_once($dir_include_functions.'woo_fields.php');
require_once($dir_include_functions.'product_page_script.php');
require_once($dir_include_functions.'coas_db/main.php');
require_once($dir_include_functions.'ondemand_products/main.php');
require_once($dir_include_functions.'customer_report.php');
require_once($dir_include_functions.'a-to-z-pagination.php');


//function to create tables in DB
function ik_hatton_core_create_tables_folders() {

	$hn_coa_enabled = (defined('HN_COA_DATA_ENABLED')) ? rest_sanitize_boolean(HN_COA_DATA_ENABLED) : false;

	if($hn_coa_enabled){
		ik_hn_coa_db_creation();
	}
}

//Add scripts for backend
function ik_hatton_core_add_js_scripts() {
    wp_register_script( 'ik_hatton_core_select2', IK_HATTON_CORE_PUBLIC . 'include/js/select2.js', '', '', true );
	wp_enqueue_script( 'ik_hatton_core_select2' );
}
add_action( 'admin_enqueue_scripts', 'ik_hatton_core_add_js_scripts' );

?>